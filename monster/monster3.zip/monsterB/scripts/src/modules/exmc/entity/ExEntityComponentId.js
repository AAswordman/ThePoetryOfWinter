export default class ExEntityComponentId {
}
ExEntityComponentId.health = "minecraft:health";
ExEntityComponentId.inventory = "minecraft:inventory";
//# sourceMappingURL=ExEntityComponentId.js.map