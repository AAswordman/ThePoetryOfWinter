
export default class ExItem{
	constructor(){
	}
}