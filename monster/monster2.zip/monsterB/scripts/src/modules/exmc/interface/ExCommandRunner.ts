
export default interface ExCommandRunner{
	runCommand(str:string): any;
}