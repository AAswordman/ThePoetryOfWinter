import PomServer from "./main/PomServer.js";

let server=new PomServer();