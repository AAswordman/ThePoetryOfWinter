

export default class ExBlock{
	constructor(){
	}
}