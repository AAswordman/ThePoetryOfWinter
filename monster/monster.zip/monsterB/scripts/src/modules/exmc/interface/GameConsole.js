export {};
//# sourceMappingURL=GameConsole.js.map