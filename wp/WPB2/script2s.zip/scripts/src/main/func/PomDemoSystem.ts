import GameController from "./GameController.js";

export default class PomDemoSystem extends GameController{
    
    onJoin(): void {

    }

    onLoaded(): void {

    }

    onLeave(): void {

    }

}