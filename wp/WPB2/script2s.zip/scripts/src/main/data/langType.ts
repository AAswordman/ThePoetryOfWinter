import lang from "./lang.js";

export type langType = typeof lang.zh;