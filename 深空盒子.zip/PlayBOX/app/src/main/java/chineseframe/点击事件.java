package chineseframe;
import android.view.View.*;
import android.view.View;

public  interface 点击事件 extends View.OnClickListener
{

	
}
