package bms.helper.android;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import android.widget.EditText;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;
import chineseframe.文件;
import java.util.ArrayList;
import android.text.Editable;
import android.text.Spanned;
import android.os.Handler;
import android.os.Message;
import bms.helper.http.DownloadUtil;
import bms.helper.zip.ZipUtils;
import android.os.Looper;
import com.play.common.LOG;
import bms.helper.http.SendMain;

public class FaceUtil {
    public static JSONObject loadfrom=new JSONObject();
    //id+图片
	public static JSONObject bitmapload=new JSONObject();
    //id
	public static ArrayList<String> bitmapkey=new ArrayList<String>();
	private static Iterator<String> it;
	private static String Pathx;
	private static Handler getImageOne;

	public static SpannableString getFaceWordFromSP(Context act, Spanned fromHtml) {
		return getFaceWordFromSPS(act,new SpannableString(fromHtml));
	}
    public static void appendFace(Context con, int resourceId, EditText editText) {
		Bitmap bitmap = BitmapFactory.decodeResource(con.getResources(), resourceId);
		ImageSpan imageSpan = new ImageSpan(con, bitmap);
		SpannableString spannableString = new SpannableString("face");
		spannableString.setSpan(imageSpan, 0, 4, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		editText.append(spannableString);
	}
	public static SpannableString getFaceWordFromSPS(Context con, SpannableString s) {  
        //SpannableString s = new SpannableString(text);  
        Pattern p = Pattern.compile("\\{:([0-9]*_[0-9]*):\\}");  
        Matcher m = p.matcher(s);
        while (m.find()) {
            int start = m.start();  
            int end = m.end();  
			ImageSpan imageSpan = new ImageSpan(con, getFaceImage(m.group(1)));
			//saveBitmap(getFaceImage(m.group(1)),"/sdcard/playbox/test.png");
            s.setSpan(imageSpan, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);  
        }  
        return s;
    }
	public static void AddEditText(Context con,EditText mEditText,String id) {
		//EditText对象
		int index = mEditText.getSelectionStart();//获取光标所在位置
		SpannableString text=getFaceWord(con,"{:"+id+":}");
		Editable edit = mEditText.getEditableText();//获取EditText的文字
		if (index < 0 || index >= edit.length()) {
			edit.append(text);
		} else {
			edit.insert(index, text);//光标所在位置插入文字
		}
	}

	public static SpannableString getFaceWord(Context con, String id) {
		return getFaceWordFromSPS(con,new SpannableString(id));
	}
	public static Bitmap getFaceImage(String group) {
		if (bitmapload.has(group)) {
			return (Bitmap)bitmapload.opt(group);
		}
		return null;
	}
	public static void saveBitmap(Bitmap bitmap, String path) {
		String savePath=path;
		File filePic;

		try {
			filePic = new File(savePath);
			if (!filePic.exists()) {
				filePic.getParentFile().mkdirs();
				filePic.createNewFile();
			}
			FileOutputStream fos = new FileOutputStream(filePic);
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.flush();
			fos.close();
		} catch (IOException e) {
			//Log.e("tag", "saveBitmap: " + e.getMessage());
			return;
		}
		//Log.i("tag", "saveBitmap success: " + filePic.getAbsolutePath());
	}
	public static void init(Context x, String json) {
		Pathx=x.getFilesDir() + "/expression";
        //Pathx="/sdcard/expression";
        Pathx="/sdcard/expression";
		new File(Pathx).mkdirs();
		try {
			loadfrom = new JSONObject(json);
		} catch (JSONException e) {}
		it = loadfrom.keys();
        while (it.hasNext()) {
            final String key = it.next();
            final String urlx=loadfrom.optString(key);
            final String path=Pathx + "/" + key + ".png";
            //LOG.print("加载",path);
            bitmapkey.add(key);
            //LOG.print("加载",new File(path).exists()+"");
            if (new File(path).exists()) {
                BitmapFactory.Options options  = new BitmapFactory.Options();
                Bitmap resource = BitmapFactory.decodeFile(path, options);
                try {
                    bitmapload.put(key, resource);
                } catch (JSONException e) {}
            }else{
                new SendMain(loadfrom.optString(key), null, new SendMain.Function(){

                        @Override
                        public void OnReturn(String result) {
                        }

                        @Override
                        public void MainThread(Message msg) {
                        }
                    }).getImage(new SendMain.GetImage(){

                        @Override
                        public void OnReturn(Bitmap result) {
                            saveBitmap(result,path);
                        }
                    });
            }
        }
	}
    public static void create(){
        
        getImageOne=new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if(msg.what==0){
                    if (it.hasNext()) {
                        final String key = it.next();
                        final String urlx=loadfrom.optString(key);
                        final String path=Pathx + "/" + key + ".png";
                        bitmapkey.add(key);
                        if (new File(path).exists()) {
                            BitmapFactory.Options options  = new BitmapFactory.Options();
                            Bitmap resource = BitmapFactory.decodeFile(path, options);
                            try {
                                bitmapload.put(key, resource);
                            } catch (JSONException e) {}
                            Message msgx=new Message();
                            msgx.what=0;
                            getImageOne.sendMessageDelayed(msgx, 1);
                        } else {
                            new Thread() {
                                @Override
                                public void run() {
                                    try {
                                        //把传过来的路径转成URL
                                        URL url = new URL(urlx);
                                        //获取连接
                                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                                        //使用GET方法访问网络
                                        connection.setRequestMethod("GET");
                                        //超时时间为10秒
                                        connection.setConnectTimeout(10000);
                                        //获取返回码
                                        int code = connection.getResponseCode();
                                        if (code == 200) {
                                            InputStream inputStream = connection.getInputStream();
                                            //使用工厂把网络的输入流生产Bitmap
                                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                                            //利用Message把图片发给Handler
                                            saveBitmap(bitmap, path);
                                            try {
                                                bitmapload.put(key, bitmap);
                                            } catch (JSONException e) {}
                                            inputStream.close();
                                        } else {
                                            //服务启发生错误

                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                        //网络连接错误
                                    }
                                }
                            }.start();
                            Message msgx=new Message();
                            msgx.what=0;
                            getImageOne.sendMessageDelayed(msgx, 300);
                        }
                    }
                }
            }
        };
        
    }
    public static void init(Context x, String json,final String zip) {
        
        Pathx=x.getFilesDir() + "/expression";
        Pathx="/sdcard/expression";
        new File(Pathx).mkdirs();
        try {
            loadfrom = new JSONObject(json);
        } catch (JSONException e) {}
        it = loadfrom.keys();
        //LOG.print("d",Pathx+"/"+DownloadUtil.getNameFromUrl(zip));
        if(!new File(Pathx+"/"+DownloadUtil.getNameFromUrl(zip)).exists()){
            new Thread(new Runnable(){
                    @Override
                    public void run() {
                        DownloadUtil.get().download(zip, "expression", DownloadUtil.getNameFromUrl(zip), new DownloadUtil.OnDownloadListener(){
                                @Override
                                public void onDownloadFailed() {
                                }

                                @Override
                                public void onDownloadSuccess() {
                                    try {
                                        ZipUtils.UnZipFolder(Pathx + "/" + DownloadUtil.getNameFromUrl(zip),
                                                             Pathx);
                                    } catch (Exception e) {}
                                    load(Pathx);
                                }

                                @Override
                                public void onDownloading(int p1) {
                                }
                            });
                    }
                }).start();
            
                
        }else{
            load(Pathx);
        }
       // create();
	}
    public static void load(String Pathx){
        while (it.hasNext()) {
            final String key = it.next();
            final String urlx=loadfrom.optString(key);
            final String path=Pathx + "/" + key + ".png";
            //LOG.print("加载",path);
            bitmapkey.add(key);
            //LOG.print("加载",new File(path).exists()+"");
            if (new File(path).exists()) {
                BitmapFactory.Options options  = new BitmapFactory.Options();
                Bitmap resource = BitmapFactory.decodeFile(path, options);
                try {
                    bitmapload.put(key, resource);
                } catch (JSONException e) {}
            }
         }
    }
}
