package bms.helper.script.json;

import org.json.JSONException;
import org.json.JSONObject;

public class JSONTools {
    public static JSONObject parse(String var0) {
        JSONObject var1 = (JSONObject)null;

        JSONObject var2;
        JSONObject var4;
        try {
            var2 = new JSONObject(var0);
        } catch (JSONException var3) {
            var4 = var1;
            return var4;
        }

        var4 = var2;
        return var4;
    }
}


