package bms.helper.script;

import java.io.FileReader;
import java.io.IOException;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class JavaScriptTools {
    Context cx;
    Function fct;
    ScriptableObject scope;
    Scriptable that;

    public JavaScriptTools() {
    }

    public JavaScriptTools(String var1) {
        this.loadjs(var1);
    }

    public Object eval(String var1) {
        return this.cx.evaluateString(this.scope, var1, "script", 0, (Object)null);
    }

    public Object get(String var1) {
        return this.scope.get(var1, this.scope);
    }

    public JavaScriptFunction getFunction(String var1) {
        return new JavaScriptFunction(this, (Function)this.get(var1));
    }

    public JavaScriptObject getObject(String var1) {
        return new JavaScriptObject(this, (NativeObject)this.get(var1));
    }

    public boolean has(String var1) {
        return this.scope.has(var1, this.scope);
    }

    public boolean hasFunction(String var1) {
        return this.get(var1) instanceof Function;
    }

    public boolean hasObject(String var1) {
        return this.get(var1) instanceof NativeObject;
    }

    public void kill() {
        Context.exit();
    }

    public void loadjs(String var1) {
        this.cx = Context.enter();

        try {
            this.scope = this.cx.initStandardObjects();
            this.cx.setOptimizationLevel(-1);
            this.that = this.cx.newObject(this.scope);
            this.cx.setLanguageVersion(180);

            try {
                Context var3 = this.cx;
                ScriptableObject var4 = this.scope;
                StringBuffer var5 = new StringBuffer();
                FileReader var2 = new FileReader(var5.append("/sdcard/").append(var1).toString());
                var3.evaluateReader(var4, var2, "script", 0, (Object)null);
            } catch (IOException var8) {
            }

        } finally {
            ;
        }
    }
}

