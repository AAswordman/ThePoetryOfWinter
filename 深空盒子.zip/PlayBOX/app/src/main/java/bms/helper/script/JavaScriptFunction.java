package bms.helper.script;

import org.mozilla.javascript.Function;

public class JavaScriptFunction {
    private Function obj;
    private JavaScriptTools tool;

    public JavaScriptFunction(JavaScriptTools javaScriptTools, Function function) {
        this.tool = javaScriptTools;
        this.obj = function;
    }

    public Object call(Object[] objArr) {
        return this.obj.call(this.tool.cx, this.tool.scope, this.tool.that, objArr);
    }
}

