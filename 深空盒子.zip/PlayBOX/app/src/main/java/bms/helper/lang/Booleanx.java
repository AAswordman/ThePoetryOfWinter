package bms.helper.lang;

public class Booleanx {
	public boolean x=false;
    public Booleanx(boolean s){
		x=s;
	}
    public void set(boolean s){
		x=s;
	}
    
}
