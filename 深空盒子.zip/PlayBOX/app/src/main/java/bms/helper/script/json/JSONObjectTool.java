package bms.helper.script.json;

//
// Decompiled by FernFlower - 744ms
//
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONObjectTool {
    private JSONObject json;

    public JSONObjectTool(JSONObject var1) {
        this.json = var1;
    }

    public Object g(String var1) {
        return this.json.opt(var1);
    }

    public JSONArray ga(String var1) {
        return this.json.optJSONArray(var1);
    }

    public double gd(String var1) {
        return this.json.optDouble(var1);
    }

    public float gf(String var1) {
        return (float)this.json.optDouble(var1);
    }

    public JSONObjectTool gj(String var1) {
        return new JSONObjectTool(this.json.optJSONObject(var1));
    }

    public long gl(String var1) {
        return this.json.optLong(var1);
    }

    public String gs(String var1) {
        return this.json.optString(var1);
    }

    public JSONObjectTool p(String var1, String var2) {
        try {
            this.json.put(var1, var2);
        } catch (JSONException var3) {
        }

        return this;
    }

    public JSONObject toJSON() {
        return this.json;
    }
}


