package bms.helper.lang;

public class Stringx {
	public String x;
	public Stringx(String x) {
		this.x = x;
	}
	public void set(String x) {
		this.x = x;
	}
}
