package com.play.box.core.flt;

import com.play.common.LOG;
import java.util.UUID;
import org.java_websocket.WebSocket;
import org.json.JSONException;
import org.json.JSONObject;
import com.play.box.core.ServerManager;

public class Command {
    private static JSONObject findResult=new JSONObject();
    private static ServerManager serverManager=null;
    public static void Init(ServerManager serverManager) {
        Command.serverManager = serverManager;
    }
    public static void OnResult(JSONObject json) {
        String key=json.optJSONObject("header").optString("requestId");
        int code =json.optJSONObject("body").optInt("statusCode");
        if (code == -2147418109) {
            SendCommand((UseFindResult)findResult.opt(key), key);
        } else {
            if (findResult.has(key)) {
                UseFindResult uft=(UseFindResult)findResult.opt(key);
                if (uft.afr != null) {
                    uft.afr.OnResult(json);
                }
                findResult.remove(key);
            }
        }
    }



    public static void UnSubscribeEvent(WebSocket conn, String str) {
        JSONObject json=new JSONObject();
        try {
            json.put("body", new JSONObject()
                     .put("eventName", str))
                .put("header", new JSONObject()
                     .put("requestId", UUID.randomUUID())
                     .put("messagePurpose", "unsubscribe")
                     .put("messageType", "commandRequest")
                     .put("version", 1));
        } catch (JSONException e) {}
        serverManager.SendMessageToUser(conn, json.toString());
    }
    public static void UnSubscribeEvent(String str) {
        JSONObject json=new JSONObject();
        try {
            json.put("body", new JSONObject()
                     .put("eventName", str))
                .put("header", new JSONObject()
                     .put("requestId", UUID.randomUUID())
                     .put("messagePurpose", "unsubscribe")
                     .put("messageType", "commandRequest")
                     .put("version", 1));
        } catch (JSONException e) {}
        serverManager.SendMessageToAll(json.toString());
    }
    public static void SubscribeEvent(WebSocket conn, String str) {
        JSONObject json=new JSONObject();
        try {
            json.put("body", new JSONObject()
                     .put("eventName", str))
                .put("header", new JSONObject()
                     .put("requestId", UUID.randomUUID())
                     .put("messagePurpose", "subscribe")
                     .put("messageType", "commandRequest")
                     .put("version", 1));
        } catch (JSONException e) {}
        serverManager.SendMessageToUser(conn, json.toString());
    }
    public static void SubscribeEvent(String str) {
        JSONObject json=new JSONObject();
        try {
            json.put("body", new JSONObject()
                     .put("eventName", str))
                .put("header", new JSONObject()
                     .put("requestId", UUID.randomUUID())
                     .put("messagePurpose", "subscribe")
                     .put("messageType", "commandRequest")
                     .put("version", 1));
        } catch (JSONException e) {}
        serverManager.SendMessageToAll(json.toString());
    }

    public static void Clone(float x, float y, float z, float xx, float yy, float zz) {
        String uuid=UUID.randomUUID().toString();
        SendCommand("/clone " + x + " " + y + " " + z + " " + x + " " + y + " " + z + " " + xx + " " + yy + " " + zz + " masked", uuid);
    }
    public static void SetBlock(float x, float y, float z, String useblock) {
        String uuid=UUID.randomUUID().toString();
        SendCommand("/setblock " + x + " " + y + " " + z + " " + useblock, uuid);
    }
    public static void Fill(float x, float y, float z, float xx, float yy, float zz, String useblock) {
        String uuid=UUID.randomUUID().toString();
        SendCommand("/fill " + x + " " + y + " " + z + " " + xx + " " + yy + " " + zz + " " + useblock, uuid);
	}
    public static void SendCommand(String use) {
        SendCommand(new UseFindResult(use), UUID.randomUUID().toString());
    }
    public static void SendCommand(String use, String uuid) {
        SendCommand(new UseFindResult(use), uuid);
    }
    public static void SendCommand(UseFindResult use, String uuid) {
        JSONObject header=new JSONObject();
        JSONObject send=new JSONObject();
        try {
            header.put("requestId", uuid)
                .put("messageType", "commandRequest")
                .put("version", 1)
                .put("messagePurpose", "commandRequest");
            send.put("header", header);
            JSONObject body=new JSONObject()
                .put("version", 1)
                .put("origin", new JSONObject().put("type", "player"))
                .put("commandLine", use.command);
            send.put("body", body);
        } catch (JSONException e) {}

        try {
            findResult.put(uuid, use);
        } catch (JSONException e) {}

        serverManager.SendMessageToAll(send.toString());
        //LOG.print("服务器", send.toString());
    }
    public static class UseFindResult {
        public String command;
        public AfterFindResult afr;
        public UseFindResult(String com, AfterFindResult afr) {
            command = com;
            this.afr = afr;
        }
        public UseFindResult(String com) {
            command = com;
            this.afr = null;
        }
    }
    public static abstract class AfterFindResult {
        public abstract void OnResult(JSONObject message);
    }


}
