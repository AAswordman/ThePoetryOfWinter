package com.play.common.enumdata;
import org.json.JSONObject;
import bms.helper.io.AssetsUtil;
import android.content.Context;
import bms.helper.script.json.JSONTools;
import android.graphics.Bitmap;
import java.util.Iterator;
import org.json.JSONException;

public class Block {
    public int data;
    public int id;
    public String namespace;
    public Bitmap texture;
    
    private static Context c;
    public static JSONObject json;
    public static JSONObject idtoname;
    
    public static void init(Context c) {
        Block.c=c;
        json = JSONTools.parse(
            AssetsUtil.getFromAssets(c, "core/ldb/blocks/id.json"));
        Iterator it=json.keys();
        while(it.hasNext()){
            String key=(String) it.next();
            try {
                idtoname.put(key.split(":")[0], json.optJSONObject(key).optString("name"));
            } catch (JSONException e) {}
        }
    }
    
    public static Block getBlock(int id,int data){
        JSONObject j= json.optJSONObject(id+":"+data);
        return new Block(id,data,j.optString("name"),j.optString("texture"));
    }
    public static Block getBlock(String id,int data){
        return getBlock(idtoname.optString(id),data);
    }
    public static Block getBlock(String id){
        return getBlock(id,0);
    }
    public static Block getBlock(int id){
        return getBlock(id,0);
    }
    public Block(int id,int data,String name,String b){
        this.data=data;this.id=id;this.namespace=name;
        this.texture=AssetsUtil.getImageFromAssetsFile(c,"core/ldb/blocks/"+b);
    }
}
