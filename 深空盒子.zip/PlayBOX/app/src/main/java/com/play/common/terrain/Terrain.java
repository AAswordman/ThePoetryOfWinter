package com.play.common.terrain;
import com.play.common.ldb.Ldb;
import java.io.File;
import java.nio.ByteBuffer;

public abstract class Terrain {
    public Ldb db;
    public volatile ByteBuffer terrainData,data2D;
    public Terrain(String path) {
        db = new Ldb(new File(path));
    }
    public Terrain(Ldb path) {
        db = path;
    }
    public void loadTerrain(byte[] key){
        terrainData=ByteBuffer.wrap(db.get(key));
    };
    public void load2DData(byte[] key){
        data2D=ByteBuffer.wrap(db.get(key));
    };
    
    public abstract byte getBlockTypeId(int x, int y, int z)
    public abstract byte getBlockData(int x, int y, int z)
    public abstract int getHeightMapValue(int x, int z)
}
