package com.play.box;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import bms.helper.android.FaceUtil;
import bms.helper.android.TextureVideoViewOutlineProvider;
import bms.helper.android.ViewHelper;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.encryption.MD5Helper;
import bms.helper.http.DownloadUtil;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import bms.helper.lang.Stringx;
import chineseframe.屏幕工具;
import com.play.android.MyImageView;
import com.play.box.activity.MostActivityUse;
import com.play.box.upload.NewEditResource;
import com.play.common.Config;
import com.play.common.Global;
import com.play.common.ImportGameContent;
import com.play.common.LOG;
import com.play.scene.helper.CreateSkinPreView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import android.os.Build;
import bms.helper.android.v4.ViewPagerHelper;
import android.support.design.widget.TabLayout;


public class NewResDownload extends MostActivityUse {
    WebView wv;
    NewResDownload act = this;
    JSONObject json = new JSONObject();
    View lastPButton;
    boolean isSkin,isPreView;
    Bitmap skindata;
    RecyclerAdapter adp;
    private ViewPager viewPager;
    private ViewPagerHelper pageview;
    String fid="0";
    

    Handler hander=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 3) {
                RecyclerView recycler_view =pageview.get(1). findViewById(R.id.rescommentRecyclerView1);
                LinearLayoutManager mLayoutManager = new LinearLayoutManager(act);
                recycler_view.setLayoutManager(mLayoutManager);
                recycler_view.setHasFixedSize(true);
                recycler_view.setAdapter(adp);
				recycler_view.setNestedScrollingEnabled(false);
            }
        }

    };

    private void initJson() {
        try {
            json.put("png", new JSONArray());
            json.put("name", new JSONArray());
            json.put("time", new JSONArray());
            json.put("message", new JSONArray());
            json.put("floor", new JSONArray());
            json.put("reply", new JSONArray());
            json.put("images", new JSONArray());
            json.put("homepage", new JSONArray());
        } catch (JSONException e) {}
	}
    private void InitView() {

        ImportGameContent.con = this;

        //this.lastPButton = (View)this.findViewById(R.id.resdownloadLinearLayout1);
        //float var1 = (float)(屏幕工具.获取屏幕宽度(this) / 3);
        //ViewHelper.setViewSize((View)this.findViewById(R.id.resdownloadLinearLayout1), (int)var1, 8);
        
        (new SendMain(Config.Http.Client, Config.Http.Context, this.getIntent().getStringExtra("url"), (JSONObject)null, new SendMain.Function(){
                @Override
                public void MainThread(Message var1) {
                }

                @Override
                public void OnReturn(String var1) {

                    //缓存路径
                    final String[] reshc=new String[]{"none"};

                    final ArrayList<String> var4 = new ArrayList<>();
                    Document var3 = Jsoup.parse(var1);
                    loadingPL(var3, true);

                    if (!getIntent().hasExtra("fid")) {
                        String pattern = "&fid=([0-9]*)&";
                        Pattern r = Pattern.compile(pattern);
                        Matcher mt = r.matcher(var1);
                        if (mt.find()) fid = mt.group(1);
                    } else {
                        fid = getIntent().getStringExtra("fid");
                    }


                    JSONObject var11 = null;
                    final String[] var5 = new String[]{"标题", "标签", "作者", "头像", "pid0000"};
                    boolean var2 = false;
                    Iterator var6 = ((Collection)var3.getElementsByClass("comiis_bodybox")).iterator();

                    while (var6.hasNext()) {
                        Element var13 = (Element)var6.next();
                        Element var7 = (Element)var13.getElementsByClass("comiis_postli comiis_list_readimgs comiis_postli_v1 zpbe").get(0);
                        var5[4] = var7.attr("id");
                        Iterator var8 = ((Collection)var13.getElementsByClass("comiis_viewtit bg_f cl")).iterator();

                        String[] var9;
                        Iterator var14;
                        while (var8.hasNext()) {
                            for (var14 = ((Collection)((Element)var8.next()).getElementsByTag("h2")).iterator(); var14.hasNext(); var5[1] = var9[1]) {
                                var9 = ((Element)var14.next()).text().split("\\$");
                                var5[0] = var9[0];
                            }
                        }

                        var8 = ((Collection)var7.getElementsByClass("comiis_img_list cl")).iterator();

                        Element var19;
                        while (var8.hasNext()) {
                            var14 = ((Collection)((Element)var8.next()).getElementsByTag("img")).iterator();

                            while (var14.hasNext()) {
                                var19 = (Element)var14.next();
                                var4.add(Config.MAIN_URL + "/" + var19.attr("comiis_loadimages"));
                            }
                        }

                        var8 = ((Collection)var7.getElementsByClass("comiis_a comiis_message_table cl")).iterator();


                        while (var8.hasNext()) {
                            var19 = (Element)var8.next();

                            try {
                                var11 = new JSONObject(MachiningHTMLString.ToString(var19.ownText()));
                            } catch (JSONException var10) {
                                //LOG.print("测试", var10.toString());
                                continue;
                            }


                        }

                        for (Iterator var12 = ((Collection)var7.getElementsByClass("top_user f_b")).iterator(); var12.hasNext(); var5[2] = ((Element)var12.next()).text()) {
                        }

                        Iterator var18 = ((Collection)var7.getElementsByClass("top_tximg")).iterator();

                        while (true) {

                            if (!var18.hasNext()) {
                                break;
                            }

                            var5[3] = ((Element)var18.next()).attr("src");
                            var2 = (new UrlStringFactory(var5[3])).GetParameter("uid").equals(Global.uid);
                        }
                    }
                    final JSONObject var15 = var11;
                    if (var2) {
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    findViewById(R.id.Administration).setVisibility(0);
                                    findViewById(R.id.Administration).setOnClickListener(new View.OnClickListener(){

                                            @Override
                                            public void onClick(View p1) {
                                                String var3 = new UrlStringFactory(ImportGameContent.getUrlPath(var15.optString("type"))).GetParameter("fid");
                                                String var7 = new UrlStringFactory(getIntent().getStringExtra("url")).GetParameter("tid");
                                                String var2 = var5[4].replace("pid", "");

                                                Intent var8 = new Intent(act, NewEditResource.class);
                                                var8.putExtra("fid", var3);
                                                var8.putExtra("tid", var7);
                                                var8.putExtra("pid", var2);
                                                var8.putExtra("page", "1");
                                                startActivity(var8);

                                            }
                                        });

                                }
                            });

                    }
                    //判断特殊分类
                    isSkin = var15.optString("type").equals("Skin");

                    if (isSkin) {
                        new SendMain(Config.Resources.GetSkin + "?tid=" + var15.optString("download"), null, null).getImage(new SendMain.GetImage(){
                                @Override
                                public void OnReturn(final Bitmap result) {
                                    skindata = result;

                                    runOnUiThread(new Runnable(){
                                            @Override
                                            public void run() {
                                                wv = new WebView(act);
                                                ((LinearLayout)findViewById(R.id.skinview)).addView(wv);
                                                wv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                                                //findViewById(R.id.skinview).setVisibility(0);
                                                findViewById(R.id.preview).setVisibility(0);
                                                wv.setBackgroundColor(Color.parseColor("#000000"));
                                                //CreateSkinPreView.create(act, wv, "def", result);
                                                String path=Config.File.BASE + "download/" + (new MD5Helper(var5[0])).getMD5String() + ".png";
                                                FaceUtil.saveBitmap(result, path);
                                                reshc[0] = path;
                                                findViewById(R.id.preview).setOnClickListener(new View.OnClickListener() {
                                                        boolean pd;
                                                        @Override
                                                        public void onClick(View view) {
                                                            findViewById(R.id.skinview).setVisibility(0);
                                                            if (!pd && var15.has("skinType")) {
                                                                CreateSkinPreView.create(act, wv, "defx", result);
                                                                pd = true;
                                                            } else {
                                                                CreateSkinPreView.create(act, wv, "def", result);
                                                                pd = true;
                                                            }

                                                            isPreView = true;
                                                        }
                                                    });
                                            }
                                        });


                                }
                            });
                    }

                    final RecyclerAdapter var17 = new RecyclerAdapter() {

                        @Override
                        public int getItemCount() {
                            return var4.size() - 1;
                        }

                        @Override
                        public void onBindViewHolder(ViewHolder var1, int var2) {
                            View var3 = var1.v;
                            ((MyImageView)var3.findViewById(R.id.res_download_imageImageView)).setImageURL(var4.get(var2 + 1));
                            CardView var4 = (CardView)var3.findViewById(R.id.cardView);
                            var4.setRadius((float)20);
                            var4.setContentPadding(0, 0, 0, 0);
                            var4.setCardElevation((float)3);
                        }

                        @Override
                        public ViewHolder onCreateViewHolder(ViewGroup var1, int var2) {
                            return new ViewHolder(this.CreateView(var1, R.layout.res_download_image));
                        }
                    };
                    final Button var16 = (Button)findViewById(R.id.Download);
                    runOnUiThread(new Runnable(){
                            @Override
                            public void run() {
                                if (!isCouldConnect(var15.optString("download")) && !isSkin) {
                                    var16.setText("复制链接");
                                }
                            }
                        });
                    if (ImportGameContent.hasFree((new MD5Helper(var5[0])).getMD5String(), var11.optString("type"))) {
                        runOnUiThread(new Runnable(){

                                @Override
                                public void run() {
                                    var16.setText("已拥有(点击重新下载)");
                                }
                            });
                    }

                    var16.setOnClickListener(new OnClickListener() {


                            boolean can;
                            @Override
                            public void onClick(View var1) {
                                if (!can) {
                                    can = true;
                                    String password=var15.optString("password", "");
                                    if (isCouldConnect(var15.optString("download"))) {
                                        new Thread(new DlRunnable(var5, var15, var16)).start();
                                    } else if (isSkin) {
                                        //特殊导入皮肤
                                        if (!reshc[0].equals("none")) {
                                            ImportGameContent.importSkin(reshc[0], var5[0], var15.has("skinType"));
                                        }
                                        var16.setText("导入成功");
                                    } else {
                                        if ("".equals(password)) {
                                            ((ClipboardManager)getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("Label", var15.optString("download")));
                                        } else {
                                            ((ClipboardManager)getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("Label", var15.optString("download") + "密码:" + password));
                                        }
                                        Toast.makeText(getApplication(), "下载链接已复制，请用浏览器打开", 0).show();
                                    }
                                }

                            }
                        });

                    runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                RecyclerView var1 = findViewById(R.id.resdownloadRecyclerView1);
                                var1.setLayoutManager(new LinearLayoutManager(act, 0, false));
                                var1.setHasFixedSize(true);
                                var1.setAdapter(var17);
                                ((MyImageView)findViewById(R.id.another_image)).setImageURL(var5[3]);
                                ((TextView)findViewById(R.id.another_text)).setText(var5[2]);
                                ((TextView)pageview.get(0).findViewById(R.id.des)).setText(var15.optString("des"));
                                ((TextView)pageview.get(0).findViewById(R.id.usev)).setText("支持游戏版本: " + var15.optString("SuitableVersion"));
                                ((TextView)findViewById(R.id.useversion)).setText("作品版本: " + var15.optString("Version"));
                                ((TextView)findViewById(R.id.title)).setText(var5[0]);

                                try {
                                    ((MyImageView)findViewById(R.id.img_icon)).setImageURL(var4.get(0));
                                } catch (Exception var2) {
                                }
                            }
                        });
                }
            })).getUseCookie();
        //LoadingView();
    }
    private boolean isCouldConnect(String var1) {
        boolean var2;
        if (!var1.endsWith(".zip") && !(var1.endsWith(".mcaddon") | var1.endsWith(".mcpack")) && !var1.endsWith(".mc") && !var1.endsWith(".mcworld") && !var1.endsWith(".pack")) {
            if (var1.indexOf("lanzous.com") != -1) {
                var2 = true;
            } else {
                var2 = false;
            }
        } else {
            var2 = true;
        }

        return var2;
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (isPreView) {
                isPreView = false;
                findViewById(R.id.skinview).setVisibility(8);
            } else {

                super.onKeyDown(keyCode, event);
                finish();
            }
        }
        return false;
    }

    public class DlRunnable implements Runnable {
        private boolean can=false;
        private final Button val$button;
        private final String[] val$str;
        private final JSONObject val$usejson;
        final String path;
        public DlRunnable(String[] var2, JSONObject var3, Button var4) {

            this.val$str = var2;
            this.val$usejson = var3;
            this.val$button = var4;
            this.path = "/sdcard/playbox/download/" + (new MD5Helper(this.val$str[0])).getMD5String() + ".zip";
        }
        public void run() {

            final String var1 = (new MD5Helper(this.val$str[0])).getMD5String() + ".zip";
            String password=val$usejson.optString("password", "");
            DownloadUtil.get().download(NewResDownload.getUrl(this.val$usejson.optString("download"), password), "playbox/download", var1,
                new DownloadUtil.OnDownloadListener(){
                    @Override
                    public void onDownloadFailed() {
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    val$button.setText("下载失败");
                                }
                            });
                    }

                    @Override
                    public void onDownloadSuccess() {
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    val$button.setText("下载完成，导入中");
                                }
                            });
                        LOG.print("储存", var1);
                        if (val$usejson.optString("type").equals("Skin")) {
                            //ImportGameContent.importSkin(path, val$str[0]);
                        } else {
                            ImportGameContent.importPackage(path, val$usejson.optString("type"));
                        }
                        LOG.print("导入", path);
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    val$button.setText("导入完毕");
                                }
                            });
                    }

                    @Override
                    public void onDownloading(final int p1) {
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    val$button.setText("下载中" + p1 + "%");
                                }
                            });
                    }
                });



        }
    }
   
    public static String getUrl(String var0, String password) {
        if (var0.indexOf("lanzous.com") != -1) {
            final Stringx var1 = new Stringx("");

            
            JSONObject var4 = (JSONObject)null;
            SendMain.Function var3=new SendMain.Function(){

                @Override
                public void MainThread(Message var1) {
                }

                @Override
                public void OnReturn(String var18) {

                    synchronized (var1) {
                        try {
                            JSONObject var4 = new JSONObject(var18);
                            var1.set(var4.optJSONObject("data").optString("url"));
                        } catch (JSONException var7) {
                        }

                        var1.notify();
                    }

                }
            };
            UrlStringFactory url=new UrlStringFactory("https://www.aurora-sky.top/bugs/lanzous.php");
            if(!"".equals(password)){
                url.SetParameter("pwd",password);
            }
            
            SendMain var2 = new SendMain(url.SetParameter("url",var0).toString(), var4, var3);
            JSONObject var8 = new JSONObject();
            var2.getUseCookie();

            synchronized (var1) {
                try {
                    var1.wait();
                } catch (InterruptedException var5) {
                }

                var0 = var1.x;
            }
        }

        return var0;
    }
    private void loadingPL(Element body, boolean skip) {
        int base;
        if (skip) {
            base = 1;
        } else {
            base = 0;
        }

        Elements messaged=body.getElementsByClass("comiis_postli comiis_list_readimgs comiis_postli_v1 zpbe");
        for (int index=base;index < messaged.size();index++) {
            Element talk=messaged.get(index);
            String png="",time="",messagex="",floor="",name="",homepage="";
            JSONArray images=new JSONArray();
            JSONArray reply=new JSONArray();
            for (Element blockquote:talk.getElementsByTag("blockquote")) {
                for (Element font:blockquote.getElementsByTag("font")) {
                    reply.put(MachiningHTMLString.ToString(font));
                }
            }
            for (Element message : talk.getElementsByClass("top_user f_b")) {
                name = message.text();
            }
            for (Element message : talk.getElementsByClass("top_lev bg_c f_f")) {
                floor = message.text();
            }
            for (Element message : talk.getElementsByClass("comiis_a comiis_message_table cl")) {
                messagex = MachiningHTMLString.ToString(message).trim();
                //LOG.print("恢复",messagex);
            }
            for (Element message : talk.getElementsByClass("top_tximg")) {
                png = message.attr("src");
            }
            for (Element message : talk.getElementsByClass("postli_top_tximg bg_e")) {
                homepage = message.attr("href");
            }
            for (Element message : talk.getElementsByClass("f_d")) {
                time = message.text();
            }
            for (Element message : talk.getElementsByClass("comiis_img_one comiis_vximga cl")) {
                for (Element pngx : message.getElementsByTag("img")) {
                    images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
                }
            }
            for (Element message : talk.getElementsByClass("comiis_img_one comiis_vximgb cl")) {
                for (Element pngx : message.getElementsByTag("img")) {
                    images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
                }
            }
            for (Element message : talk.getElementsByClass("comiis_img_list comiis_vximgb comiis_vximgb_img4 cl")) {
                for (Element pngx : message.getElementsByTag("img")) {
                    images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
                }
            }
            json.optJSONArray("images").put(images);
            json.optJSONArray("png").put(png);
            json.optJSONArray("time").put(time);
            json.optJSONArray("message").put(messagex);
            json.optJSONArray("floor").put(floor);
            json.optJSONArray("name").put(name);
            json.optJSONArray("homepage").put(homepage);
            //LOG.print("图片输出测试", json.optJSONArray("images").toString());

            json.optJSONArray("reply").put(reply);
        }
        Message msg=new Message();
        msg.what = 3;
        hander.sendMessage(msg);
	}
    @Override
    protected void onCreate(Bundle var1) {

        super.onCreate(var1);
        this.setContentView(R.layout.res_download);
        this.SetTitleFree("资源下载");
        LoadingView();
        this.initJson();
        this.InitView();

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu var1) {
        return super.onPrepareOptionsMenu(var1);
    }
    private void LoadingView() {
        LayoutInflater inflater =getLayoutInflater();
        viewPager = (ViewPager) findViewById(R.id.ViewPager);
        
        TabLayout tabLayout=findViewById(R.id.tabbar);
        pageview = new ViewPagerHelper(viewPager,new String[]{"简介","评论","推荐"});
        
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        
        /*
        tabLayout.addTab(tabLayout.newTab().setText("简介"));
        tabLayout.addTab(tabLayout.newTab().setText("评论"));
        tabLayout.addTab(tabLayout.newTab().setText("推荐"));
        */
        
        
        View view0 = inflater.inflate(R.layout.res_download_download, null);
        View view1 = inflater.inflate(R.layout.res_download_comment, null);
        View view2 = inflater.inflate(R.layout.person_table, null);

        view1.findViewById(R.id.comment).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in=getIntent();
                    UrlStringFactory url=new UrlStringFactory(in.getStringExtra("url"));
                    Intent write=new Intent(act, WriteReply.class);
                    if (url.toString().indexOf("thread-") != -1) {
                        //write.putExtra("tie",url.GetParameterInt("tie"));
                        //等待修改
                        write.putExtra("fid", fid);
                        write.putExtra("inajax", in.getStringExtra("inajax"));
                        write.putExtra("tie", url.Pattern("thread-", "-1-1"));
                    } else {
                        write.putExtra("fid", fid);
                        write.putExtra("inajax", in.getStringExtra("inajax"));
                        write.putExtra("tie", url.GetParameterInt("tid") + "");
                    }
                    //LOG.print("tid",url.GetParameterInt("tid")+"");
                    //LOG.print("tid",url.GetParameter("tid")+"");
                    startActivityForResult(write, 222);
                }
            });



        adp = new RecyclerAdapter(){
            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.res_download_comment_item, viewGroup, false);
                return new RecyclerAdapter.ViewHolder(v);
            }
            @Override
            public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                final View v=viewHolder.v;
                ((TextView)v.findViewById(R.id.name)).setText(json.optJSONArray("name").optString(position));
                ((TextView)v.findViewById(R.id.time)).setText(json.optJSONArray("time").optString(position));
                MachiningHTMLString.SetTextFun(act, (TextView)v.findViewById(R.id.content), json.optJSONArray("message").optString(position));
                //((TextView)v.findViewById(R.id.floor_num)).setText(json.optJSONArray("floor").optString(position));
                /*
                 CardView var4 = (CardView)v.findViewById(R.id.card);
                 var4.setRadius((float)30);
                 var4.setContentPadding(0, 0, 0, 0);
                 var4.setCardElevation((float)10);
                 var4.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));
                 */
                TextureVideoViewOutlineProvider.round(v.findViewById(R.id.profile));
                ((MyImageView)v.findViewById(R.id.profile)).setImageURL(json.optJSONArray("png").optString(position));
                ((MyImageView)v.findViewById(R.id.profile)).setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            Intent web=new Intent(act, URLHandleActivity.class);
                            web.putExtra("name", "个人主页");
                            web.putExtra("url", Config.MAIN_URL + "/" + json.optJSONArray("homepage").optString(position));
                            startActivity(web);
                        }
                    });
                //JSONArray arr=json.optJSONArray("images").optJSONArray(position);
                //((LinearLayout)v.findViewById(R.id.postitemSHOWimage)).removeAllViews();

                if (json.optJSONArray("reply").optJSONArray(position).length() == 0) {
                    ((View)v.findViewById(R.id.bereply_layout)).setVisibility(8);
                } else {
                    ((TextView)v.findViewById(R.id.bereply_name)).setText(json.optJSONArray("reply").optJSONArray(position).optString(1));
                    ((TextView)v.findViewById(R.id.bereply_content)).setText(FaceUtil.getFaceWord(act, json.optJSONArray("reply").optJSONArray(position).optString(2)));
                }
            }
            @Override
            public int getItemCount() {
                return json.optJSONArray("name").length();
            }
		};
        pageview.add(view0);
        pageview.add(view1);
        pageview.add(view2);
        pageview.run();
        
	}


    

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO 自动生成的方法存根
        if (requestCode == 222 && resultCode == 2) {
            reStart();
        }
    };

    private void reStart() {
        if (Build.VERSION.SDK_INT >= 11) {
            recreate();   
        } else {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
    }
}

