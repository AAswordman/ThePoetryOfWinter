package com.play.common;
import android.os.Handler;
import android.os.Message;
import bms.helper.http.SendMain;
import bms.helper.lang.Stringx;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import java.util.HashMap;
import java.util.ArrayList;
import okhttp3.Cookie;

public class SignInCommon {
    public static String user;
	public static String pass;
	public static final Stringx formhash=new Stringx("");
	public static final Stringx cookietime=new Stringx("");
	public static JSONObject json=new JSONObject();
	public static Function fun;
	public static abstract class Function{
		public abstract void OnReturn(String result);
	}
	public static void SetFun(Function func){
		fun=func;
	}
	private static Handler handler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(msg.what==0){
			Sign(formhash.x,cookietime.x);
			}
		}
		
	};
	public static void LoadMessage(String str){
		try {
			json = new JSONObject(str);
			user=json.getString("user");
			pass=json.getString("pass");
		} catch (JSONException e) {}
	}
    public static void SetMessage(String a,String b){
		user=a;
		pass=b;
	}
	public static void Sign(){
		SendMain.cookieStore.put(Config.MAIN_DOMIN,new ArrayList<Cookie>());
		new SendMain(Config.Http.Client,Config.Http.Context, "https://bbs.aurora-sky.top/member.php?mod=logging&action=login&mobile=2",
			null, new SendMain.Function(){
				@Override
				public void MainThread(Message msg) {
				}

				@Override
				public void OnReturn(String result) {
					Document doc=Jsoup.parse(result);
					for(Element s : doc.select("[name=formhash]")){
						formhash.set(s.attr("value"));
					}
					for(Element s : doc.select("[name=cookietime]")){
						cookietime.set(s.attr("value"));
					}
					Message msg=new Message();
					msg.what=0;
					handler.sendMessage(msg);
				}
			}).getUseCookie();
	}
	public static void Sign(String formhash,String cookietime){
		JSONObject json=new JSONObject();
		try{
				json.put("formhash",formhash);
				json.put("referer", "https://bbs.aurora-sky.top/plugin.php?id=comiis_app_portal&pid=7&mobile=2");
				json.put("fastloginfield", "username");
				json.put("cookietime", cookietime);
				json.put("username", user);
				json.put("password", pass);
				json.put("questionid", "0");
				json.put("answer", "");
				} catch (JSONException e) {}
				new SendMain(Config.Http.Client,Config.Http.Context, Config.Sign.URL,
					json, new SendMain.Function(){
						@Override
						public void MainThread(Message msg) {
						}

						@Override
						public void OnReturn(String result) {
                            /*
                            String doc="";
                            Pattern r = Pattern.compile("showDialog\\('(.*)'");
                            Matcher m = r.matcher(result);
                            if(m.find()){
                                doc=m.group(1);
                            }
							//Document doc=Jsoup.parse(result.replace("<![CDATA[","").replace("]]>",""));
							if(fun!=null){
							    fun.OnReturn(doc);
							}
                            */
                            if(Jsoup.parse(result.
                            replace("<![CDATA[","").replace("]]>","")).getElementById("messagetext")==null){
                                Sign();
                            }else{
                            fun.OnReturn(Jsoup.parse(result.
                            replace("<![CDATA[","").replace("]]>","")).getElementById("messagetext").text());
                            }
							//UpDate();
							//load.log(SendMain.result);
							//load.log("发送成功");
						}
					}).postUseCookie();
	}

	public static String toStringx() {
		//super.toString();
		try {
			json.put("user",user);
			json.put("pass",pass);
		} catch (JSONException e) {}
		return json.toString();
	}
}
