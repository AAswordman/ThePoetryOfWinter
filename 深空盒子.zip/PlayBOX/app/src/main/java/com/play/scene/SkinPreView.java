package com.play.scene;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import bms.helper.app.CrashHandler;
import bms.helper.io.AssetsUtil;
import chineseframe.文件;
import com.play.box.R;
import java.io.IOException;
import org.json.JSONObject;
import bms.helper.encryption.Base64Helper;
import org.json.JSONException;
import com.play.common.LOG;
import android.webkit.WebChromeClient;
import android.graphics.BitmapFactory;
import com.play.scene.helper.CreateSkinPreView;

public class SkinPreView extends AppCompatActivity {
    CrashHandler crashHandler;
    WebView webView;
    Intent in;
    SkinPreView act=this;
    final String Basepath="scene/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
        setContentView(R.layout.SkinPreView);
        in = getIntent();
        getSupportActionBar().hide();
        webView = (WebView)findViewById(R.id.URLloadingingWebView1);
        CreateSkinPreView.create(act,webView,in.getStringExtra("model"),in.getStringExtra("skin"));
    }
    public static void Start(Activity c, String skin, String model) {
        Intent intent = new Intent(c, SkinPreView.class);
        intent.putExtra("skin", skin);
        intent.putExtra("model", model);
        c.startActivity(intent);
    }
}
