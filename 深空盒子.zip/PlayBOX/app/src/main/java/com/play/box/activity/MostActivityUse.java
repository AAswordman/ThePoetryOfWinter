package com.play.box.activity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import bms.helper.app.BaseActivityUse;
import com.play.box.activity.MostActivityUse;
import com.play.box.R;

public class MostActivityUse extends BaseActivityUse {
    protected void SetTitleFree(String paramString) {
        ((TextView)this.actionBarview.findViewById(R.id.back)).setText("<< " + paramString);
    }
    
    @Override
    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setActionBarLayout(R.layout.ActionBar);
        this.actionBarview.findViewById(R.id.back).setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p1) {
					finish();
				}
			});
        if (Build.VERSION.SDK_INT >= 21)
            getSupportActionBar().setElevation(0); 
    }
}
