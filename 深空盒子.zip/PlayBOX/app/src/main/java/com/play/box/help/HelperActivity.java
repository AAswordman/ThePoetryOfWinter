package com.play.box.help;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.io.AssetsUtil;
import bms.helper.script.json.JSONTools;
import com.play.box.R;
import com.play.box.activity.MostActivityUse;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;
import android.view.View;
import android.widget.TextView;
import android.support.v7.widget.CardView;
import android.widget.LinearLayout;
import android.view.KeyEvent;
import bms.helper.android.ViewHelper;
import chineseframe.屏幕工具;
import android.widget.ImageView;
import com.play.common.LOG;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.view.ViewTreeObserver;

public class HelperActivity extends MostActivityUse {
    HelperActivity act=this;
    boolean help=false;
    private ArrayList<String> getKey(Iterator it) {
        ArrayList<String> arr=new ArrayList<>();
        while (it.hasNext()) {
            arr.add((String)it.next());
        }
        return arr;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetTitleFree("帮助");
        setContentView(R.layout.act_help_all);
        CardView cd=findViewById(R.id.Card);
        cd.setRadius(40);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        final JSONObject json=JSONTools.parse(AssetsUtil.getFromAssets(this, "help/id.json"));
        final ArrayList<String> keys=getKey(json.keys());
        RecyclerAdapter adp=new RecyclerAdapter(){
            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                return new ViewHolder(CreateView(viewGroup, R.layout.act_help_all_item));
            }

            @Override
            public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                View v=viewHolder.v;
                ((TextView)v.findViewById(R.id.acthelp_text)).setText(keys.get(position));
                v.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            LinearLayout line=findViewById(R.id.acthelp_free);
                            line.removeAllViews();
                            findViewById(R.id.acthelp_free).setVisibility(0);
                            help = true;
                            findViewById(R.id.acthelp_list).setVisibility(8);

                            for (int index=0;index < json.optJSONArray(keys.get(position)).length();index++) {
                                String msg=json.optJSONArray(keys.get(position)).optString(index);
                                if (msg.startsWith("D@")) {
                                    msg = msg.replace("D@", "");
                                    //msg.split(",");
                                    final ImageView img=new ImageView(act);
                                    final int out=屏幕工具.dp转像素(act, 15);
                                    //LOG.print("msg",msg);
                                    //int imageId = getResources().getIdentifier(msg, "drawable",getPackageName());
                                    //img.setImageResource(imageId);
                                    //LOG.print("png",imageId+"");
                                    //final Bitmap map=BitmapFactory.decodeResource(getResources(),imageId);
                                    final Bitmap map=AssetsUtil.getImageFromAssetsFile(act,"help/"+msg);
                                    img.setImageBitmap(map);
                                    final LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                                    img.setLayoutParams(layout);
                                    layout.setMargins(out, out/2, out, out/2);
                                    ViewTreeObserver vto = img.getViewTreeObserver();
                                    vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                                            boolean hasMeasured=false;
                                            @Override
                                            public boolean onPreDraw() {
                                                if (hasMeasured == false){
                                                    hasMeasured=true;
                                                    layout.width=img.getMeasuredWidth();
                                                    layout.height=(int) (((float)map.getHeight()/map.getWidth())*img.getMeasuredWidth());
                                                    //LOG.print("png",layout.height+"");
                                                    img.setLayoutParams(layout);
                                                    
                                                }
                                                return true;
                                            }});
                                    /*
                                    int width =View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.EXACTLY);
                                    int height =View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.EXACTLY);
                                    img.measure(width,height);
                                    height=img.getMeasuredHeight();
                                    width=img.getMeasuredWidth();
                                    */
                                    
                                    
                                    //ViewHelper.setViewSize(text,T);
                                    line.addView(img);
                                } else {
                                    TextView text=new TextView(act);
                                    text.setText(msg);
                                    int out=屏幕工具.dp转像素(act, 15); 
                                    LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    text.setLayoutParams(layout);
                                    layout.setMargins(out, out/2, out, out/2);
                                    //ViewHelper.setViewSize(text,T);
                                    line.addView(text);
                                }
                            }
                        }
                    });
            }

            @Override
            public int getItemCount() {
                return keys.size();
            }
        };
        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.acthelp_list);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)act));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adp);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == event.KEYCODE_BACK && !help) {
            return super.onKeyDown(keyCode, event);
        } else if (keyCode == event.KEYCODE_BACK && help) {
            help = false;
            findViewById(R.id.acthelp_free).setVisibility(8);
            findViewById(R.id.acthelp_list).setVisibility(0);
            return false;
        } else {
            return super.onKeyDown(keyCode, event);
        }


    }

}
