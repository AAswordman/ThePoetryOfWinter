package com.play.box;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.View;
import android.widget.TextView;
import bms.helper.android.FaceUtil;
import com.play.android.html.HTMLLoading;
import org.json.JSONObject;
import org.jsoup.nodes.Element;
import android.text.method.LinkMovementMethod;
import com.play.common.LOG;
public class MachiningHTMLString {
	public static JSONObject json=new JSONObject();
    public static String ToString(Element i){
		Element f=i.clone();
		f.getElementsByClass("comiis_quote bg_h b_dashed f_c").remove();
		String p=f.html();
		//p=p.replaceAll("\n","").replaceAll("<br>","\n").replaceAll("&nbsp;","");
		
		
		return p.
			replaceAll("<img .*?smilieid=\"(.*?)\" .*?>",
			"{:5_$1:}");
	}
	public static String ToString(String var0) {
		//LOG.print("捕捉",var0);
        return var0.replaceAll("&quot;", "\"");
    }
	
	public static void SetTextFun(final Activity act,final TextView v,String msg){
		HTMLLoading.SetText(act, new HTMLLoading.Function() {
				@Override
				public void run(Spanned sp) {
					CharSequence text=getClickableHtml(act,FaceUtil.getFaceWordFromSP(act,sp));
					v.setText(text);
					v.setMovementMethod(LinkMovementMethod.getInstance());
				}
			},msg);
	}
	private static CharSequence getClickableHtml(Activity act,Spanned spannedHtml) {
        //Spanned spannedHtml = Html.fromHtml(html);
        SpannableStringBuilder clickableHtmlBuilder = new SpannableStringBuilder(spannedHtml);
        URLSpan[] urls = clickableHtmlBuilder.getSpans(0, spannedHtml.length(), URLSpan.class);
        for(final URLSpan span : urls) {
            setLinkClickable(act,clickableHtmlBuilder, span);
        }
        return clickableHtmlBuilder;
    }
	private static void setLinkClickable(final Activity act,final SpannableStringBuilder clickableHtmlBuilder,final URLSpan urlSpan) {
        int start = clickableHtmlBuilder.getSpanStart(urlSpan);
        int end = clickableHtmlBuilder.getSpanEnd(urlSpan);
        int flags = clickableHtmlBuilder.getSpanFlags(urlSpan);

        ClickableSpan clickableSpan = new ClickableSpan() {
            public void onClick(View view) {
                
                //LogW.i("URL-click:"+urlSpan.getURL());
                /*
				Uri uri = Uri.parse(urlSpan.getURL());
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				act.startActivity(intent);
                */
            }
        };
	}
}
