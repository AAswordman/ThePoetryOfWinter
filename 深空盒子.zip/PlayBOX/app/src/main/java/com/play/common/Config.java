package com.play.common;

import bms.helper.http.SendMain;
import bms.helper.tools.TimeDelayer;
import okhttp3.OkHttpClient;
import org.json.JSONObject;
import java.net.CookieStore;

public final class Config {
	public static final String MAIN_URL="https://bbs.aurora-sky.top";
	public static final String MAIN_DOMIN="bbs.aurora-sky.top";
    public static final String UPDATE="https://sharechain.qq.com/33d66c35a693aa46df921eda8a3dbaec";
    public static final class Forum {
		public static final String EDIT_COOKIE = "https://bbs.aurora-sky.top/forum.php?mod=post&action=edit&page=1&mobile=2";
		public static final String EDIT_Image = "https://bbs.aurora-sky.top/forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=1943&tid=960&pid=8385";
		public static final String EDIT_MAIN = "https://bbs.aurora-sky.top/forum.php?mod=post&action=edit&extra=&editsubmit=yes&mobile=2&handlekey=postform&inajax=1";
		public static final String Headlines = "https://bbs.aurora-sky.top/news/";
		public static final String List = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay";
		public static final String REPLY_COOKIE = "https://bbs.aurora-sky.top/forum.php?mod=post&action=reply";
		public static final String REPLY_MAIN = "https://bbs.aurora-sky.top/forum.php?mod=post&action=reply&extra=&replysubmit=yes&mobile=2&handlekey=postform";
		public static final String SEND = "https://bbs.aurora-sky.top/forum.php";
		public static final String SEND_COOKIE = "https://bbs.aurora-sky.top/forum.php?mod=post&action=newthread&mobile=2";
		public static final String SEND_Image = "https://bbs.aurora-sky.top/misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2";
		public static final String Search = "https://bbs.aurora-sky.top/search.php?mod=forum";
        public static final String Search_Cookie = "https://bbs.aurora-sky.top/search.php?mod=forum&mobile=2";
        public static final String SearchPage="https://bbs.aurora-sky.top/search.php?mod=forum&searchid=3&orderby=lastpost&ascdesc=desc&searchsubmit=yes&page=2&inajax=1";
		public static final String TYPE = "https://bbs.aurora-sky.top/forum.php?forumlist=1&mobile=2";
	}
	public final class Resources {
		public static final String Addon = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=152&mobile=2";
		public static final String Building = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=150&mobile=2";
		public static final String Map = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=147&mobile=2";
		public static final String Modpe = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=151&mobile=2";
		public static final String Seed = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=149&mobile=2";
		public static final String Skin = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=148&mobile=2";
		public static final String Texture = "https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=153&mobile=2";
        
        public static final String GetSkin="https://www.aurora-sky.top/bugs/imp/get.php";
        public static final String PutSkin="https://www.aurora-sky.top/bugs/imp/put.php";
	}
    
	
	public final class Http {
		public static final OkHttpClient Client = SendMain.getClient();
		public static final JSONObject Context = new JSONObject();
		public static final TimeDelayer Delay = new TimeDelayer(220);
	}


	public static final class Sign {
		public static final String URL="https://bbs.aurora-sky.top/member.php?mod=logging&action=login&loginsubmit=yes&loginhash=Ly554&handlekey=loginform&inajax=1";
		public static final String Message="https://bbs.aurora-sky.top/home.php?mod=space&do=profile&mycenter=1&mobile=2";
	}
	public static final class File {
		public static final String BASE="/sdcard/playbox/";
		public static final String USERDATA="user.json";
	}
	public static final class Person {
		public static final String POST="https://bbs.aurora-sky.top/home.php?mod=space&uid=36&do=thread&view=me&from=space&mobile=2";
		public static final String Message="https://bbs.aurora-sky.top/home.php?mod=space&uid=36&do=profile&mobile=2";
	}
}
