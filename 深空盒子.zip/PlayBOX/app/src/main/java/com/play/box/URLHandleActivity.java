package com.play.box;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import com.play.common.Config;
import java.util.HashMap;
import java.util.Map;
import okhttp3.Cookie;
import chineseframe.屏幕工具;
import com.play.common.LOG;

public class URLHandleActivity extends AppCompatActivity {
	CrashHandler crashHandler;
	WebView webView;
	Intent in;
	String Url;
    URLHandleActivity act=this;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
        setContentView(R.layout.URLloadinging);
        getSupportActionBar().hide();


		((View)findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
                    saveCookie();
					finish();
				}
			});
		//url,name
		in = getIntent();
		Url = in.getStringExtra("url");

		if (GotoPage(Url)) finish();


		((TextView)findViewById(R.id.actwatchingreslistTextView1)).setText(in.getStringExtra("name"));
		//((WebView)findViewById(R.id.URLloadingingWebView1))
		loadCookie();
		webView = (WebView)findViewById(R.id.URLloadingingWebView1);

		//支持javascript
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setSupportZoom(false);
		webView.getSettings().setBuiltInZoomControls(false);
		webView.getSettings().setUseWideViewPort(true);
		webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
		webView.getSettings().setLoadWithOverviewMode(true);
        if(in.hasExtra("pc"))webView.getSettings().setUserAgentString("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36");
		//如果不设置WebViewClient，请求会跳转系统浏览器
		webView.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					//该方法在Build.VERSION_CODES.LOLLIPOP以前有效，从Build.VERSION_CODES.LOLLIPOP起，建议使用shouldOverrideUrlLoading(WebView, WebResourceRequest)} instead
					//返回false，意味着请求过程里，不管有多少次的跳转请求（即新的请求地址），均交给webView自己处理，这也是此方法的默认处理
					//返回true，说明你自己想根据url，做新的跳转，比如在判断url符合条件的情况下，我想让webView加载http://ask.csdn.net/questions/178242
                    if (GotoPage(url)) return true;

                    if (url == null) return false;

                    if (url.startsWith("http:") || url.startsWith("https:")) {
                        view.loadUrl(url);
                        return false;
                    } else {
                        try {
                            LOG.print("uri",url);
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            startActivity(intent);
                        } catch (Exception e) {
//                    ToastUtils.showShort("暂无应用打开此链接");
                        }
                        return true;
                    }
				}
				@Override
				public void onPageFinished(WebView view, String url) {
					// hide element by class name
					/*
                     webView.loadUrl("javascript:(function() { " +
                     "document.getElementsByClassName('your_class_name')[0].style.display='none'; })()");
                     */
					// hide element by id
                    if (url.indexOf(Config.MAIN_DOMIN) != -1) {
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    LinearLayout.MarginLayoutParams params = (LinearLayout.MarginLayoutParams) webView.getLayoutParams();
                                    params.setMargins(0, 屏幕工具.dp转像素(act, 10), 0, 0);
                                    webView.setLayoutParams(params);
                                }
                            });
                        webView.loadUrl("javascript:(function() { " +
                                        "document.getElementById('comiis_head').style.display='none';})()");
                        webView.loadUrl("javascript:(function() { " +
                                        "document.getElementsByClassName('comiis_leftmenubg')[0].style.display='none';})()");
                        webView.loadUrl("javascript:(function() { " +
                                        "document.getElementsByClassName('comiis_lrmenukey bg_a f_f')[0].style.display='none';})()");
                        webView.loadUrl("javascript:(function() { " +
                                        "document.getElementsByClassName('comiis_sidenv_box')[0].style.display='none';})()");
                    } else {
                        LinearLayout.MarginLayoutParams params = (LinearLayout.MarginLayoutParams) view.getLayoutParams();
                        params.setMargins(0, 屏幕工具.dp转像素(act, 55), 0, 0);
                        webView.setLayoutParams(params);
                    }
				}
			});
		webView.loadUrl(Url);
	}
    public boolean GotoPage(String url) {
        if (url.indexOf("do=profile") != -1) {
            Intent into=new Intent(this, PersonHomePage.class);
            into.putExtra("url", url);
            startActivity(into);
            return true;
		} else if (url.indexOf("forum.php?mod=viewthread&tid") != -1) {
            Intent into=new Intent(this, Post.class);
            into.putExtra("url", url);
            into.putExtra("inajax", "1");
            startActivity(into);
            return true;
		}
        return false;
    }
	private void loadCookie() {
		for (Cookie k:SendMain.cookieStore.get(Config.MAIN_DOMIN)) {
			CookieManager.getInstance().setCookie(k.domain(), k.name() + "=" + k.value());
		}
	}
	public void saveCookie() {
        Map<String,String> map = new HashMap<>();
        CookieManager cookieManager = CookieManager.getInstance();
        String CookieStr = cookieManager.getCookie(Config.MAIN_DOMIN);
        String[] cooLs = CookieStr.split(";");
        for (String coo:cooLs) {
            String[] ls = coo.split("=");
            if (ls.length == 2) {
                //LOG.print(ls[0],ls[1]);
				SendMain.cookieStore.get(Config.MAIN_DOMIN).add(new Cookie.Builder()
                                                                .name(ls[0].trim()).value(ls[1]).domain(Config.MAIN_DOMIN).build());
            }
        }
    }
}
