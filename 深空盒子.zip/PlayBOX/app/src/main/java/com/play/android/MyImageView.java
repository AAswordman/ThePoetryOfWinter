package com.play.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.widget.ImageView;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;
import bms.helper.android.FaceUtil;
import bms.helper.encryption.MD5Helper;
import bms.helper.tools.TimeDelayer;
import bms.helper.http.SendMain;
import com.play.common.Config;

public class MyImageView extends ImageView {
    public static final int GET_DATA_SUCCESS = 1;
    public static final int NETWORK_ERROR = 2;
    public static final int SERVER_ERROR = 3;
	public static final JSONObject LOAD_PNG=new JSONObject();
	public static final JSONObject IS_GETTING=new JSONObject();
	public static TimeDelayer delay=new TimeDelayer(0);
	private final Context con;
    //子线程不能操作UI，通过Handler设置图片
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
			switch (msg.what) {
				case GET_DATA_SUCCESS:
					Bitmap bitmap = (Bitmap) msg.obj;
					setImageBitmap(bitmap);

					break;
				case NETWORK_ERROR:
					//Toast.makeText(getContext(),"网络连接失败",Toast.LENGTH_SHORT).show();

					break;
				case SERVER_ERROR:
					//Toast.makeText(getContext(),"服务器发生错误",Toast.LENGTH_SHORT).show();
					IS_GETTING.remove((String)msg.obj);
					break;
			}
        }
    };

    public MyImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
		con = context;
    }

    public MyImageView(Context context) {
        super(context);
		con = context;
    }

    public MyImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
		con = context;
    }

    //设置网络图片
    public void setImageURL(final String path) {
		if (!LOAD_PNG.has(path)) {
			if (!IS_GETTING.has(path)) {
				try {
					IS_GETTING.put(path, true);
				} catch (JSONException e) {}
                new SendMain(Config.Http.Client, Config.Http.Context, path, null, null).getImage(new SendMain.GetImage(){
                        @Override
                        public void OnReturn(Bitmap result) {
                            Message msg = Message.obtain();
                            msg.obj = result;
                            msg.what = GET_DATA_SUCCESS;
                            handler.sendMessage(msg);
                            try {
                                LOAD_PNG.put(path, result);
                            } catch (JSONException e) {}
                        }
                });
			}
		} else {
			Message msg = Message.obtain();
			msg.obj = LOAD_PNG.opt(path);
			msg.what = GET_DATA_SUCCESS;
			handler.sendMessage(msg);
		}
	}
}
