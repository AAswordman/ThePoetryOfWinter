package com.play.common.chunk;
import com.mithrilmania.blocktopograph.map.Dimension;
import com.play.common.ldb.Ldb;
import com.play.common.ldb.McLdb;
import com.play.common.terrain.Terrain;
import com.play.common.terrain.V0_9_Terrain;
import com.play.common.terrain.V1_0_Terrain;
import com.play.common.terrain.V1_1_Terrain;
import com.play.common.terrain.V1_2_Terrain;

public class Chunk {
    public final int x,z;
    public final Terrain ter;
    public final Dimension dimension;
    
    public final static int NULL=-1;
    public final static int ERROR=-2;
    public final static int V0_9=2;
    public final static int V1_0=3;
    public final static int V1_1=4;
    public final static int V1_2=7;
    
    public Chunk(int x,int z,Dimension d,byte num,Ldb db){
        this.x=x;this.z=z;this.dimension=d;
        
        byte[] tkey=McLdb.getChunkDataKey(x,z,ChunkTag.TERRAIN,d,num,true);
        byte[] dkey=McLdb.getChunkDataKey(x,z,ChunkTag.TERRAIN,d,num,false);
        
        int v=getVersion(db.get(tkey));
        
        switch(v){
            case V0_9:
                ter=new V0_9_Terrain(db);
                break;
            case V1_0:
                ter=new V1_0_Terrain(db);
                break;
            case V1_1:
                ter=new V1_1_Terrain(db);
                break;
            case V1_2:
                ter=new V1_2_Terrain(db);
                break;
            default:
                ter=new V1_2_Terrain(db);
        }
        ter.loadTerrain(tkey);
        ter.load2DData(dkey);
    }
    public static int getVersion(byte[] data) {
        if (data == null || data.length <= 0) {
            return 0;
        } else {
            int versionNumber = data[0] & 0xff;

            //fallback version
            //You can't just do this...
            if (versionNumber > V1_2) {
                versionNumber = V1_2;
            }
            //check if the returned version exists, fallback on ERROR otherwise.
            return versionNumber;
        }
    }
}
