//
// Decompiled by FernFlower - 935ms
//
package com.play.box.upload;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import bms.helper.android.ViewHelper;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.http.UrlStringFactory;
import chineseframe.屏幕工具;
import com.play.box.Post;
import com.play.box.R;
import com.play.box.WritePost;
import com.play.box.activity.MostActivityUse;
import com.play.common.ForumUtil;
import com.play.common.ImportGameContent;
import com.play.common.LOG;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import android.widget.Button;
import bms.helper.http.SendMain;
import com.play.common.Config;
import com.play.common.Global;
import bms.helper.encryption.MD5Helper;
import android.widget.Switch;

public class NewReleaseResource extends MostActivityUse {
    class ExceptionUse extends Exception {
        String t = "";
        public ExceptionUse(String var1) {
            this.t = var1;
        }

        public String getText() {
            return this.t;
        }
    }

    NewReleaseResource act = this;
    RecyclerAdapter adp = new RecyclerAdapter(){
        @Override
        public int getItemCount() {
            return Math.min(images.size() + 1, 9);
        }

        @Override
        public void onBindViewHolder(ViewHolder var1, int var2) {
            final int pos=var2;
            View var3 = var1.v;
            ImageView var5 = (ImageView)var3.findViewById(R.id.forumwritepostitempicImageView1);
            View var4 = (View)var3.findViewById(R.id.forumwritepostitempicImageView2);
            ViewHelper.setViewSize((View)var3.findViewById(R.id.forumwritepostitempicImageView1), 
                                   屏幕工具.dp转像素(act, (float)180), 屏幕工具.dp转像素(act, (float)100));
            if (var2 == images.size()) {
                var4.setVisibility(8);
                var5.setImageResource(R.drawable.ic_image_multiple);
                var5.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View p1) {
                            Message var2 = new Message();
                            var2.what = 5;
                            handler.sendMessage(var2);

                        }
                    });
            } else {
                var4.setVisibility(0);

                var5.setImageBitmap(BitmapFactory.decodeFile((images.get(var2))));

                var4.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View var1) {
                            images.remove(pos);
                            adp.notifyDataSetChanged();
                        }
                    });
            }

        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup var1, int var2) {
            return new ViewHolder(LayoutInflater.from(var1.getContext()).inflate(R.layout.forum_write_post_item_pic, var1, false));
        }
    };
    String fid = (new UrlStringFactory("https://aurora-sky.top/forum.php?mod=forumdisplay&fid=147&mobile=2")).GetParameter("fid");
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message var1) {
            super.handleMessage(var1);
            if (var1.what == 5) {
                startActivityForResult(WritePost.selectPicture(), 1);
            }

        }
    };
    ArrayList<String> images = new ArrayList<>();
    String type = "Map";
    String skinph="";

    private void InitView() {
        RecyclerView var1 = (RecyclerView)this.findViewById(R.id.Randombar);
        var1.setLayoutManager(new LinearLayoutManager(this, 0, false));
        var1.setHasFixedSize(true);
        var1.setAdapter(this.adp);
        
        findViewById(R.id.ljskin).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivityForResult(WritePost.selectPicture(), 2);
                }
            });
        
        Post.ChangeSpinner(this, (Spinner)findViewById(R.id.releaseResSpinner1), "请选择/地图/Addon/材质/皮肤".split("/"));
        ((Spinner)findViewById(R.id.releaseResSpinner1)).setOnItemSelectedListener(new OnItemSelectedListener(){
                @Override
                public void onItemSelected(AdapterView var1, View var2, int var3, long var4) {

                    String var7 = "";
                    final String var6 = (String)var1.getItemAtPosition(var3);
                    if (!var6.equals("请选择")) {
                        if (var6.equals("地图")) {
                            type = "Map";
                            var7 = ImportGameContent.getUrlPath("Map");
                        } else if (var6.equals("材质")) {
                            type = "Resource";
                            var7 = ImportGameContent.getUrlPath("Resource");
                        } else if (var6.equals("Addon")) {
                            type = "Addon";
                            var7 = ImportGameContent.getUrlPath("Addon");
                        }else if (var6.equals("皮肤")) {
                            type = "Skin";
                            var7 = ImportGameContent.getUrlPath("Skin");
                        }
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    if (var6.equals("皮肤")) {
                                        findViewById(R.id.releaseSkin).setVisibility(0);
                                        findViewById(R.id.releaseNormal).setVisibility(8);
                                    }else{
                                        findViewById(R.id.releaseSkin).setVisibility(8);
                                        findViewById(R.id.releaseNormal).setVisibility(0);
                                    }
                                }
                            });
                        
                        
                        LOG.print("路径", var7);
                        fid = (new UrlStringFactory(var7)).GetParameter("fid");
                        ((Button)findViewById(R.id.release)).setText("发布" + var6);
                    } else {
                        ((Button)findViewById(R.id.release)).setText("发布");
                    }
                }

                @Override
                public void onNothingSelected(AdapterView var1) {
                }
            });
        this.findViewById(R.id.release).setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View var1) {
                    try {
                        findViewById(R.id.loading).setVisibility(0);
                        final JSONObject var2 = new JSONObject();
                        
                        String time=System.currentTimeMillis()+"";
                        try {
                            var2.put("des", getTextstr(R.id.des));
                            if(type.equals("Skin")){
                                var2.put("download", time);
                                if(skinph.equals("")){
                                    throw new ExceptionUse("请选择发布的皮肤");
                                }
                            }else{
                                var2.put("download", getTextstr(R.id.lj));
                            }
                            var2.put("Version", getTextstr(R.id.v));
                            var2.put("SuitableVersion", getTextstr(R.id.usev));
                            var2.put("type", type);
                            try{
                                var2.put("password",getTextstr(R.id.ljmm));
                            }catch(ExceptionUse e){

                            }
                        } catch (JSONException var9) {
                        }
                        if (((Button)findViewById(R.id.release)).getText().toString().equals("发布")) {
                            throw new ExceptionUse("请选择发布类型");
                        }
                        if (images.size() <= 4) {
                            ExceptionUse var13 = new ExceptionUse("图片请至少上传5张");
                            throw var13;
                        }
                        if (((Button)findViewById(R.id.release)).getText().toString().equals("发布")) {
                            throw new ExceptionUse("请选择发布类型");
                        }
                        StringBuffer var3 = new StringBuffer();
                        StringBuffer var8 = new StringBuffer();
                        final String var9 = var3.append(var8.append(((EditText)findViewById(R.id.title)).getText().toString()).append("$")
                                                  .toString()).append(((EditText)findViewById(R.id.tag)).getText().toString()).toString();
                        //final String var11 = var2.toString();
                        final ArrayList var5 = images;
                        final String var4 = fid;
                        final ForumUtil.Function var15 = new ForumUtil.Function(){
                            @Override
                            public void OnResult(final String p1) {
                                runOnUiThread(new Runnable(){
                                        @Override
                                        public void run() {
                                            Toast.makeText(getApplication(), p1, 0).show();
                                            if (p1.indexOf("已发布") != -1) {
                                                setResult(2);
                                                finish();
                                            } else {
                                                findViewById(R.id.loading).setVisibility(8);
                                            }

                                        }

                                    });
                            }

                            @Override
                            public void UpDate(final String p1) {
                                runOnUiThread(new Runnable(){
                                        @Override
                                        public void run() {
                                            ((TextView)findViewById(R.id.useProgress)).setText(p1);

                                        }
                                    });

                            }
                        };
                        if(!type.equals("Skin")){
                            ForumUtil.SendMessage(var9, var2.toString(), var5, var4, var15);
                        }else{
                            try {
                                int uid=Integer.parseInt(Global.uid);
                                new SendMain(Config.Resources.PutSkin, 
                                new JSONObject()
                                .put("uid", Global.uid)
                                .put("hash",new MD5Helper(uid*5-99+Math.round(Math.sin(uid)*200)+"").getMD5String())
                                .put("tid",time)
                                , new SendMain.Function(){
                                        @Override
                                        public void OnReturn(String result) {
                                            try {
                                                if(((Switch)findViewById(R.id.releaseResSwitchSkin)).isChecked())var2.put("skinType", "Woman");
                                                ForumUtil.SendMessage(var9, var2.toString(), var5, var4, var15);
                                            } catch (JSONException e) {}
                                        }

                                        @Override
                                        public void MainThread(Message msg) {
                                        }
                                    }).postFile(skinph,"file","t.png");
                            } catch (JSONException e) {}
                        }
                    } catch (ExceptionUse var10) {
                        Toast.makeText(getApplication(), var10.getText(), 0).show();
                        findViewById(R.id.loading).setVisibility(8);
                    }

                }
            });
    }
    private String getTextstr(int var1) throws ExceptionUse {
        String var2 = ((EditText)this.findViewById(var1)).getText().toString();
        if (var2.equals("")) {
            throw new ExceptionUse("请填写全部空格");
        } else {
            return var2;
        }
    }

    
    
    private void setTextstr(int var1, String var2) {
        ((TextView)this.findViewById(var1)).setText(var2);
    }

    @Override
    protected void onActivityResult(int var1, int var2, Intent var3) {
        if (var1 == 1 && var2 == -1 && var3 != null) {
            Uri var4 = var3.getData();
            String[] var5 = new String[]{"_data"};
            Cursor var7 = this.getContentResolver().query(var4, var5, (String)null, (String[])null, (String)null);
            var7.moveToFirst();
            String var6 = var7.getString(var7.getColumnIndex(var5[0]));
            var7.close();
            this.images.add(var6);
            this.adp.notifyDataSetChanged();
        }else if(var1 == 2 && var2 == -1 && var3 != null){
            Uri var4 = var3.getData();
            String[] var5 = new String[]{"_data"};
            Cursor var7 = this.getContentResolver().query(var4, var5, (String)null, (String[])null, (String)null);
            var7.moveToFirst();
            String var6 = var7.getString(var7.getColumnIndex(var5[0]));
            var7.close();
            ((ImageView)findViewById(R.id.ljskin)).setImageBitmap(BitmapFactory.decodeFile(var6));
            skinph=var6;
        }

        super.onActivityResult(var1, var2, var3);
    }

    @Override
    protected void onCreate(Bundle var1) {
        super.onCreate(var1);
        this.SetTitleFree("资源发布");
        this.setContentView(R.layout.releaseRes);

        CardView var2 = (CardView)this.findViewById(R.id.card);
        var2.setRadius((float)30);
        var2.setContentPadding(0, 0, 0, 0);
        var2.setCardElevation((float)10);
        this.InitView();
        this.findViewById(R.id.loading).setVisibility(8);
    }
}


