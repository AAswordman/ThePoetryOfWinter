//
// Decompiled by FernFlower - 935ms
//
package com.play.box.upload;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import bms.helper.android.ViewHelper;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import bms.helper.script.json.JSONObjectTool;
import bms.helper.script.json.JSONTools;
import chineseframe.屏幕工具;
import com.play.android.MyImageView;
import com.play.box.R;
import com.play.box.WritePost;
import com.play.box.activity.MostActivityUse;
import com.play.common.Config;
import com.play.common.Config.Http;
import com.play.common.ForumUtil;
import com.play.common.ForumUtil.IdImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import android.widget.Switch;

public class NewEditResource extends MostActivityUse {
    class ExceptionUse extends Exception {
        String t = "";
        public ExceptionUse(String var1) {
            this.t = var1;
        }

        public String getText() {
            return this.t;
        }
    }

    NewEditResource act = this;
    RecyclerAdapter adp = new RecyclerAdapter(){
        @Override
        public int getItemCount() {
            return Math.min(images.size() + 1, 9);
        }

        @Override
        public void onBindViewHolder(ViewHolder var1, int var2) {
            final int pos=var2;
            View var3 = var1.v;
            ImageView var5 = (ImageView)var3.findViewById(R.id.forumwritepostitempicImageView1);
            View var4 = (View)var3.findViewById(R.id.forumwritepostitempicImageView2);
            ViewHelper.setViewSize((View)var3.findViewById(R.id.forumwritepostitempicImageView1), 
                                   屏幕工具.dp转像素(act, (float)180), 屏幕工具.dp转像素(act, (float)100));
            if (var2 == images.size()) {
                var4.setVisibility(8);
                var5.setImageResource(R.drawable.ic_image_multiple);
                var5.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View p1) {
                            Message var2 = new Message();
                            var2.what = 5;
                            handler.sendMessage(var2);

                        }
                    });
            } else {
                var4.setVisibility(0);
                if ((images.get(var2)).path != null) {
                    var5.setImageBitmap(BitmapFactory.decodeFile((images.get(var2)).path));
                } else {
                    ((MyImageView)var5).setImageURL((images.get(var2)).url);
                }

                var4.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View var1) {
                            IdImage var2 = (IdImage)images.get(pos);
                            if (var2.id != null) {
                                (new SendMain(Http.Client, Http.Context, 
                                    (new UrlStringFactory(Config.Forum.EDIT_Image))
                                    .SetParameter("fid", getIntent().getStringExtra("fid"))
                                    .SetParameter("pid", getIntent().getStringExtra("pid"))
                                    .toString() + "&aids[]=" + var2.id, (JSONObject)null, 
                                    new SendMain.Function(){
                                        @Override
                                        public void OnReturn(String result) {
                                        }

                                        @Override
                                        public void MainThread(Message msg) {
                                        }
                                    })).getUseCookie();
                            }

                            images.remove(pos);
                            adp.notifyDataSetChanged();
                        }
                    });
            }

        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup var1, int var2) {
            return new ViewHolder(LayoutInflater.from(var1.getContext()).inflate(R.layout.forum_write_post_item_pic, var1, false));
        }
    };
    String fid = (new UrlStringFactory("https://aurora-sky.top/forum.php?mod=forumdisplay&fid=147&mobile=2")).GetParameter("fid");
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message var1) {
            super.handleMessage(var1);
            if (var1.what == 5) {
                startActivityForResult(WritePost.selectPicture(), 1);
            }

        }
    };
    ArrayList<ForumUtil.IdImage> images = new ArrayList<>();
    String type = "Map";

    private void InitView() {
        RecyclerView var1 = (RecyclerView)this.findViewById(R.id.Randombar);
        var1.setLayoutManager(new LinearLayoutManager(this, 0, false));
        var1.setHasFixedSize(true);
        var1.setAdapter(this.adp);
        (new SendMain(Http.Client, Http.Context, 
            (new UrlStringFactory("https://bbs.aurora-sky.top/forum.php?mod=post&action=edit&page=1&mobile=2"))
            .SetParameter("fid", this.getIntent().getStringExtra("fid"))
            .SetParameter("tid", this.getIntent().getStringExtra("tid"))
            .SetParameter("pid", this.getIntent().getStringExtra("pid"))
            .SetParameter("page", this.getIntent().getStringExtra("page")).toString(), 
            (JSONObject)null, 
            new SendMain.Function(){

                @Override
                public void OnReturn(String var1) {
                    Document var3 = Jsoup.parse(var1);
                    final JSONObjectTool var7 = new JSONObjectTool(JSONTools.parse(var3.getElementById("e_textarea").text()));
                    final String[] var2 = var3.getElementById("needsubject").attr("value").split("\\$");
                    Iterator var4 = ((Collection)var3.getElementById("imglist").getElementsByClass("vm b_ok")).iterator();

                    while (var4.hasNext()) {
                        Element var5 = (Element)var4.next();
                        String var8 = "https://bbs.aurora-sky.top" + "/" + var5.attr("src");
                        String var6 = var5.attr("id").replace("aimg_", "");
                        images.add(new IdImage(var6, var8));
                    }

                    runOnUiThread(new Runnable(){
                            @Override
                            public void run() {
                                setTextstr(R.id.tag, var2[1]);
                                setTextstr(R.id.title, var2[0]);
                                setTextstr(R.id.des, var7.gs("des"));
                                setTextstr(R.id.v, var7.gs("Version"));
                                setTextstr(R.id.usev, var7.gs("SuitableVersion"));
                                setTextstr(R.id.lj, var7.gs("download"));
                                if(var7.toJSON().has("password")){
                                    setTextstr(R.id.ljmm,var7.gs("password"));
                                }
                                if(var7.toJSON().has("skinType")){
                                    ((Switch)findViewById(R.id.releaseResSwitchSkin)).setChecked(true);
                                }
                                type=var7.gs("type");
                                if (type.equals("Skin")) {
                                        findViewById(R.id.releaseSkin).setVisibility(0);
                                        findViewById(R.id.releaseNormal).setVisibility(8);
                                    }else{
                                        findViewById(R.id.releaseSkin).setVisibility(8);
                                        findViewById(R.id.releaseNormal).setVisibility(0);
                                }
                                adp.notifyDataSetChanged();
                            }
                        });
                }

                @Override
                public void MainThread(Message msg) {

                }
            })).getUseCookie();
        this.findViewById(R.id.release).setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View var1) {
                    try {
                        findViewById(R.id.loading).setVisibility(0);
                        JSONObject var2 = new JSONObject();

                        try {
                            try{
                                var2.put("password",getTextstr(R.id.ljmm));
                            }catch(ExceptionUse e){
                                
                            }
                            var2.put("des", getTextstr(R.id.des));
                            var2.put("download", getTextstr(R.id.lj));
                            var2.put("Version", getTextstr(R.id.v));
                            var2.put("SuitableVersion", getTextstr(R.id.usev));
                            var2.put("type", type);
                            if(((Switch)findViewById(R.id.releaseResSwitchSkin)).isChecked())var2.put("skinType", "Woman");
                        } catch (JSONException var9) {
                        }

                        if (images.size() <= 4) {
                            ExceptionUse var13 = new ExceptionUse("图片请至少上传5张");
                            throw var13;
                        }

                        StringBuffer var11 = new StringBuffer();
                        StringBuffer var3 = new StringBuffer();
                        String var12 = var11.append(var3.append(getTextstr(R.id.title)).append("$").toString()).append(getTextstr(R.id.tag)).toString();
                        String var14 = var2.toString();
                        ArrayList var5 =images;
                        String var6 = getIntent().getStringExtra("fid");
                        String var4 = getIntent().getStringExtra("tid");
                        String var7 = getIntent().getStringExtra("pid");
                        String var8 = getIntent().getStringExtra("page");
                        ForumUtil.Function var15 = new ForumUtil.Function(){
                            @Override
                            public void OnResult(final String p1) {
                                runOnUiThread(new Runnable(){
                                        @Override
                                        public void run() {
                                            Toast.makeText(getApplication(), p1, 0).show();
                                            if (p1.indexOf("编辑成功") != -1) {
                                                setResult(2);
                                                finish();
                                            } else {
                                                findViewById(R.id.loading).setVisibility(8);
                                            }

                                        }

                                    });
                            }

                            @Override
                            public void UpDate(final String p1) {
                                runOnUiThread(new Runnable(){
                                        @Override
                                        public void run() {
                                            ((TextView)findViewById(R.id.useProgress)).setText(p1);

                                        }
                                    });
                                
                            }
                        };
                        ForumUtil.EditMessage(var12, var14, var5, var6, var4, var7, var8, var15);
                    } catch (ExceptionUse var10) {
                        Toast.makeText(getApplication(), var10.getText(), 0).show();
                        findViewById(R.id.loading).setVisibility(8);
                    }

                }
            });
    }
    private String getTextstr(int var1) throws ExceptionUse {
        String var2 = ((EditText)this.findViewById(var1)).getText().toString();
        if (var2.equals("")) {
            throw new ExceptionUse("请填写全部空格");
        } else {
            return var2;
        }
    }

    private void setTextstr(int var1, String var2) {
        ((TextView)this.findViewById(var1)).setText(var2);
    }

    @Override
    protected void onActivityResult(int var1, int var2, Intent var3) {
        if (var1 == 1 && var2 == -1 && var3 != null) {
            Uri var4 = var3.getData();
            String[] var5 = new String[]{"_data"};
            Cursor var7 = this.getContentResolver().query(var4, var5, (String)null, (String[])null, (String)null);
            var7.moveToFirst();
            String var6 = var7.getString(var7.getColumnIndex(var5[0]));
            var7.close();
            this.images.add(new IdImage(var6));
            this.adp.notifyDataSetChanged();
        }

        super.onActivityResult(var1, var2, var3);
    }

    @Override
    protected void onCreate(Bundle var1) {
        super.onCreate(var1);
        this.SetTitleFree("资源发布");
        this.setContentView(R.layout.releaseRes);
        this.setTextstr(R.id.releaseResTextView, "图片(会保持原封面)");
        CardView var2 = (CardView)this.findViewById(R.id.card);
        var2.setRadius((float)30);
        var2.setContentPadding(0, 0, 0, 0);
        var2.setCardElevation((float)10);
        this.InitView();
        this.findViewById(R.id.loading).setVisibility(8);
    }
}


