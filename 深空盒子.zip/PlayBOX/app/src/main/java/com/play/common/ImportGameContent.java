//
// Decompiled by FernFlower - 2105ms
//
package com.play.common;

import bms.helper.io.CopyFile;
import bms.helper.io.CreateFile;
import bms.helper.zip.ZipUtils;
import chineseframe.文件;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import org.json.JSONException;
import org.json.JSONObject;
import bms.helper.io.AssetsUtil;
import android.content.Context;
import bms.helper.script.json.JSONTools;
import org.json.JSONArray;

public class ImportGameContent {
	public final class Name {
		static final String Beh = "behavior_packs";
		static final String Map = "minecraftWorlds";
		static final String Res = "resource_packs";
        static final String Skin = "skin_packs/PlayBoxSkins";
	}
    public static Context con;
    static final String PathMain = "/sdcard/games/com.mojang/";
    static final String DATAmain = Config.File.BASE + "importdata/";

    public static void AddAddonList(String var0) {
        if (!HasAddonList(var0)) {
            CreateFile.WriteAppend(Config.File.BASE + "/addon/have.txt", var0);
        }

    }

    public static boolean ArrHas(String[] var0, String var1) {
        return (new HashSet(Arrays.asList(var0))).contains(var1);
    }

    public static boolean HasAddonList(String var0) {
        boolean var1;
        try {
            StringBuffer var3 = new StringBuffer();
            文件 var2 = new 文件(var3.append(Config.File.BASE).append("/addon/have.txt").toString());
            var1 = ArrHas(var2.获取内容().split("\n"), var0);
        } catch (Exception var4) {
            var1 = false;
        }

        return var1;
    }

    public static String getName(String var0) {
        return var0.substring(var0.lastIndexOf("/") + 1, var0.lastIndexOf(".") - 1);
    }

    public static String getPathName(String var0) {
        if (var0.equals("Map")) {
            var0 = Name.Map;
        } else if (var0.equals("Addon")) {
            var0 = Name.Beh;
        } else if (var0.equals("Resource")) {
            var0 = Name.Res;
        } else if (var0.equals("Skin")) {
            var0 = Name.Skin;
        } 

        return var0;
    }

    public static String getUrlPath(String var0) {
        if (var0.equals("Map")) {
            var0 = Config.Resources.Map;
        } else if (var0.equals("Addon")) {
            var0 = Config.Resources.Addon;
        } else if (var0.equals("Resource")) {
            var0 = Config.Resources.Texture;
        } else if (var0.equals("Skin")) {
            var0 = Config.Resources.Skin;
        }

        return var0;
    }

    public static boolean has(String var0, String var1) {
        File var3 = new File(PathMain + var1 + "/" + getName("/" + var0 + "."));
        boolean var2;
        if (var3.exists() && var3.isDirectory()) {
            var2 = true;
        } else {
            var2 = false;
        }

        return var2;
    }

    public static boolean hasAddon(String var0) {
        return HasAddonList(var0);
    }

    public static boolean hasSkin(String var0) {
        return new File(PathMain+Name.Skin+"/"+getName("/" + var0 + ".")+".png").exists();
    }
    
    public static boolean hasFree(String var0, String var1) {
        boolean var2 = false;
        if (var1.equals("Addon")) {
            var2 = hasAddon(getName("/" + var0 + "."));
        } else if (var1.equals("Skin")) {
            var2=hasSkin(var0);
        } else {
            var2 = has(var0, getPathName(var1));
        }

        return var2;
    }

    public static boolean hasMap(String var0) {
        return has(var0, Name.Map);
    }

    public static boolean hasResource(String var0) {
        return has(var0, Name.Res);
    }

    public static void importAddon(String var0) {
        AddAddonList(getName(var0));
        String var1 = DATAmain + getName(var0);
        (new File(var1)).mkdirs();

        try {
            ZipUtils.UnZipFolder(var0, var1);
        } catch (Exception var2) {
        }

        importAddonData(var1);
    }
    public static void importSkin(String var0) {
        importSkin(var0, "未知");
    }
    public static void importSkin(String var0,String langname,boolean women) {
        String path=PathMain + Name.Skin;
        File f;
        if (!(f = new File(path)).exists()) {
            f.mkdirs();
        }
        String name=getName(var0);
        CopyFile.copyFile(new File(var0), new File(path + "/" + name + ".png"));

        if (!(f = new File(path + "/manifest.json")).exists()) {
            try {
                new 文件(f.getAbsolutePath()).写入内容(AssetsUtil.getFromAssets(con, "packs/PlayBoxSkins/manifest.json"));
            } catch (IOException e) {}
        }
        f = new File(path + "/skins.json");
        if (!(f).exists()) {
            try {
                new 文件(f.getAbsolutePath()).写入内容(AssetsUtil.getFromAssets(con, "packs/PlayBoxSkins/skins.json"));
            } catch (IOException e) {}
        }
        try {
            JSONObject json=JSONTools.parse(new 文件(f.getAbsolutePath()).获取内容());
            String type="";
            if(women){
                type="geometry.humanoid.customSlim";
            }else{
                type="geometry.humanoid.custom";
            }
            json.optJSONArray("skins").put(new JSONObject()
                                           .put("localization_name", name)
                                           .put("geometry", type)
                                           .put("texture", name + ".png")
                                           .put("type", "free")
                                           );
            new 文件(f.getAbsolutePath()).写入内容(json.toString());
        } catch (IOException e) {} catch (JSONException e) {}

        new File(path + "/texts").mkdirs();
        f = new File(path + "/texts/zh_CN.lang");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {}
        }
        CreateFile.WriteAppend(f.getAbsolutePath(), "skin.PlayBoxSkins." + name + "=" + langname);


    }
        
    public static void importSkin(String var0, String langname) {
        importSkin(var0,langname,false);
    }
    private static void importAddonData(String var0) {
        File[] var4 = (new File(var0)).listFiles();

        for (int var1 = 0; var1 < var4.length; ++var1) {
            File var5 = var4[var1];
            if (!var5.isDirectory()) {
                if (var5.getAbsolutePath().endsWith("[.zip|.mcpack]")) {
                    try {
                        String var17 = var5.getAbsolutePath();
                        StringBuffer var16 = new StringBuffer();
                        StringBuffer var14 = new StringBuffer();
                        StringBuffer var15 = new StringBuffer();
                        StringBuffer var8 = new StringBuffer();
                        ZipUtils.UnZipFolder(var17, var16.append(var14.append(var15.append(var8.append(var0).append("/").toString()).append(getName(var5.getAbsolutePath())).toString()).append("/").toString()).append(getName(var5.getAbsolutePath())).toString());
                    } catch (Exception var9) {
                    }

                    importAddonData(var0 + "/" + getName(var5.getAbsolutePath()));
                }
            } else {
                JSONObject var2 = (JSONObject)null;
                文件 var6 = new 文件(var5.getAbsolutePath() + "/manifest.json");
                JSONObject var3 = null;
                if (var6.file.exists()) {
                    try {
                        var3 = new JSONObject(var6.获取内容());
                    } catch (IOException var12) {

                    } catch (JSONException var13) {

                    }

                    var2 = var3;
                } else {
                    try {
                        StringBuffer var7 = new StringBuffer();
                        var6 = new 文件(var7.append(var5.getAbsolutePath()).append("/pack_manifest.json").toString());
                        var3 = new JSONObject(var6.获取内容());
                    } catch (IOException var10) {

                    } catch (JSONException var11) {

                    }

                    var2 = var3;

                }

                if (var2.optJSONArray("modules").optJSONObject(0).optString("type").equals("resources")) {
                    CopyFile.copyDirectory(var5, new File(PathMain + "resource_packs/" + var2.optJSONObject("header").optString("uuid")));
                } else {
                    CopyFile.copyDirectory(var5, new File(PathMain + "behavior_packs/" + var2.optJSONObject("header").optString("uuid")));
                }
            }
        }

    }

    public static void importMap(String var0) {
        //importPkg(var0, Name.Map);
        String var1 = DATAmain + getName(var0);
        (new File(var1)).mkdirs();

        try {
            ZipUtils.UnZipFolder(var0, var1);
        } catch (Exception var2) {
        }

        importMapData(var1, getName(var0));
    }

    private static void importMapData(String var1, String or) {
        File origin=new File(var1 + "/levelname.txt");
        if (origin.exists()) {
            CopyFile.copyDirectory(new File(var1), new File(PathMain + Name.Map + "/" + or));
        } else {
            for (File f : new File(var1).listFiles()) {
                importMapData(f.getAbsolutePath(), or);
            }
        }
    }

    public static void importPackage(String var0, String var1) {
        LOG.print("类型", var1);
        if (var1.equals("Addon")) {
            importAddon(var0);
        } else if (var1.equals("Map")) {
            importMap(var0);
        } else if (var1.equals("Skin")) {
            importSkin(var0);
        } else {
            importPkg(var0, getPathName(var1));
        }

    }

    public static void importPkg(String var0, String var1) {
        var1 = PathMain + var1 + "/" + getName(var0);
        (new File(var1)).mkdirs();

        try {
            ZipUtils.UnZipFolder(var0, var1);
        } catch (Exception var2) {
        }

    }
}


