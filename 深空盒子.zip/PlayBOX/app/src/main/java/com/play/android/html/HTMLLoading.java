package com.play.android.html;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.widget.TextView;
import bms.helper.tools.TimeDelayer;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import org.xml.sax.XMLReader;
import com.play.common.Config;
import bms.helper.lang.Stringx;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import com.play.common.LOG;

public class HTMLLoading {
	public static abstract class Function {
		public abstract void run(Spanned sp);
	}
	public static TimeDelayer delay;
	public static void SetText(final Activity act, final Function r, final String htmlContentx) {
		Document htmlContent=Jsoup.parse("<fp>" + htmlContentx.trim() + "</fp>");
		for (Element e:htmlContent.getElementsByTag("img")) {
            if (e.hasAttr("comiis_loadimages")) {
                e.attr("src", e.attr("comiis_loadimages"));
                e.removeAttr("comiis_loadimages");
            }
		}
		String HTMLStringx=htmlContent.getElementsByTag("fp").get(0).html().trim();
        if(HTMLStringx.startsWith("<br>")){
            HTMLStringx=HTMLStringx.replaceFirst("<br>","");
        }
        final String HTMLString=HTMLStringx;
        //LOG.print("lg",HTMLString);
		new Thread(new Runnable() { //从网络中下载图片是耗时操作,所以需要使用线程.还有mSpanned = Html.fromHtml()的创建其实也是异步耗时的.
				@Override
				public void run() {
					final Spanned mSpanned = Html.fromHtml(HTMLString, 		
                        new Html.ImageGetter() {
							@Override
							public Drawable getDrawable(String source) {
								TimeDelayer.Stop(delay);
								Drawable drawable = null;
								if (source.indexOf("http") == -1) {
									source = Config.MAIN_URL + "/" + source;
								}
                                //LOG.print("网络", source);
								try {

									drawable = Drawable.createFromStream(new URL(source).openStream(), "image.jpg");//下载图片
									drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());//设置图片显示范围
								} catch (IOException e) {
									e.printStackTrace();
								}
								return drawable;
							}
						}, null
					);

					act.runOnUiThread(new Runnable(){

							@Override
							public void run() {
								r.run(mSpanned);
							}


                        });
				}
			}).start();
	}

}
