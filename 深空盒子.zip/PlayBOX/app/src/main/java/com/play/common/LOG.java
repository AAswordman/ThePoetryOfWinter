package com.play.common;
import chineseframe.文件;
import java.io.IOException;
import bms.helper.io.CreateFile;

public class LOG {
    public static void print(String head,String msg){
		CreateFile.WriteAppend("/sdcard/playbox/printlog/log.txt",head+" : "+msg);
	}
}
