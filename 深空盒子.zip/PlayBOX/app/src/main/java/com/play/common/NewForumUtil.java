package com.play.common;

import java.util.ArrayList;

public class NewForumUtil extends ForumUtil {
    
    public static class Edit extends ForumUtil.Edit{
        
    }
    public static class NewThread extends ForumUtil.NewThread{
    }
}
