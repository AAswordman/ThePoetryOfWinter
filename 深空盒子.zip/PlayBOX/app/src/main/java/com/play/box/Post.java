package com.play.box;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import bms.helper.android.FaceUtil;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import com.play.android.MyImageView;
import com.play.common.Config;
import com.play.common.LOG;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import android.widget.Spinner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView;
import android.widget.Adapter;
import com.play.android.html.HTMLLoading;
import android.text.Spannable;
import android.text.Spanned;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.graphics.Color;
import com.play.box.activity.MostActivityUse;
import bms.helper.http.PreloadingGet;
import android.content.Context;

public class Post extends MostActivityUse {
	Post act=this;
	RecyclerAdapter adp;
	final JSONObject json=new JSONObject();
	int maxPage=0;
    String fid="0";
	Handler hander=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 1) {
				final String[] str=(String[]) msg.obj;
				((MyImageView)findViewById(R.id.profile)).setImageURL(str[2]);
                ((MyImageView)findViewById(R.id.profile)).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent web=new Intent(act, URLHandleActivity.class);
                            web.putExtra("name", "个人主页");
                            web.putExtra("url", Config.MAIN_URL + "/" + str[5]);
                            startActivity(web);
                        }
                    });
				((TextView)findViewById(R.id.title)).setText(str[0]);
				((TextView)findViewById(R.id.txt_time)).setText(str[4]);
				MachiningHTMLString.SetTextFun(act, (TextView)findViewById(R.id.txt_content), str[3]);
				((TextView)findViewById(R.id.name)).setText(str[1]);

			} else if (msg.what == 2) {
				ArrayList<String> str=(ArrayList<String>) msg.obj;

				for (String png: str) {
					MyImageView img=new MyImageView(act);
				    img.setImageURL(png);
					((LinearLayout)findViewById(R.id.image_layout)).addView(img);
				}
			} else if (msg.what == 3) {
				RecyclerView recycler_view = findViewById(R.id.postRecyclerView1);
				LinearLayoutManager mLayoutManager = new LinearLayoutManager(act);
				recycler_view.setLayoutManager(mLayoutManager);
				recycler_view.setHasFixedSize(true);
				recycler_view.setAdapter(adp);
				recycler_view.setNestedScrollingEnabled(false);

			}
		}
	};
	private void initJson() {
		try {
			json.put("png", new JSONArray());
			json.put("name", new JSONArray());
			json.put("time", new JSONArray());
			json.put("message", new JSONArray());
			json.put("floor", new JSONArray());
			json.put("reply", new JSONArray());
			json.put("images", new JSONArray());
            json.put("homepage", new JSONArray());
		} catch (JSONException e) {}
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.post);

		initJson();



		adp = new RecyclerAdapter(){
			@Override
			public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
				View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_item, viewGroup, false);
				return new RecyclerAdapter.ViewHolder(v);
			}
			@Override
			public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
				final View v=viewHolder.v;
				((TextView)v.findViewById(R.id.name)).setText(json.optJSONArray("name").optString(position));
				((TextView)v.findViewById(R.id.time)).setText(json.optJSONArray("time").optString(position));
				MachiningHTMLString.SetTextFun(act, (TextView)v.findViewById(R.id.content), json.optJSONArray("message").optString(position));
				((TextView)v.findViewById(R.id.floor_num)).setText(json.optJSONArray("floor").optString(position));
                CardView var4 = (CardView)v.findViewById(R.id.card);
				var4.setRadius((float)30);
				var4.setContentPadding(0, 0, 0, 0);
				var4.setCardElevation((float)10);
				var4.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));
				((MyImageView)v.findViewById(R.id.profile)).setImageURL(json.optJSONArray("png").optString(position));
                ((MyImageView)v.findViewById(R.id.profile)).setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            Intent web=new Intent(act, URLHandleActivity.class);
                            web.putExtra("name", "个人主页");
                            web.putExtra("url", Config.MAIN_URL + "/" + json.optJSONArray("homepage").optString(position));
                            startActivity(web);
                        }
                    });
				JSONArray arr=json.optJSONArray("images").optJSONArray(position);
				((LinearLayout)v.findViewById(R.id.postitemSHOWimage)).removeAllViews();
				for (int index=0;index < arr.length();index++) {
					MyImageView img=new MyImageView(act);
				    img.setImageURL(arr.optString(index));
					//LOG.print("创建新图片", arr.optString(index));
					((LinearLayout)v.findViewById(R.id.postitemSHOWimage)).addView(img);
				}
				if (json.optJSONArray("reply").optJSONArray(position).length() == 0) {
					((View)v.findViewById(R.id.bereply_layout)).setVisibility(8);
				} else {
					((TextView)v.findViewById(R.id.bereply_name)).setText(json.optJSONArray("reply").optJSONArray(position).optString(1));
					((TextView)v.findViewById(R.id.bereply_content)).setText(FaceUtil.getFaceWord(act, json.optJSONArray("reply").optJSONArray(position).optString(2)));
				}
			}
			@Override
			public int getItemCount() {
				return json.optJSONArray("name").length();
			}
		};
		loadView();
		addTouch();
	}

	private void addTouch() {
		CardView var1 = (CardView)this.findViewById(R.id.postCardView1);
        var1.setRadius((float)30);
        var1.setContentPadding(0, 0, 0, 0);
        var1.setCardElevation((float)10);
        var1.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));
		((Spinner)findViewById(R.id.postSpinner1)).setOnItemSelectedListener(new OnItemSelectedListener(){
				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4) {
					UrlStringFactory fac=new UrlStringFactory(getIntent().getStringExtra("url"));
					fac.SetParameter("page", (p3 + 1) + "");
					new SendMain(Config.Http.Client, Config.Http.Context, fac.toString() , null,
						new SendMain.Function(){
							@Override
							public void OnReturn(String result) {
								initJson();
								for (Element body : Jsoup.parse(result).getElementsByClass("comiis_bodybox")) {
									loadingPL(body, false);
								}
								runOnUiThread(new Runnable(){

                                        @Override
                                        public void run() {
                                            adp.notifyDataSetChanged();
                                        }
                                    });
							}

							@Override
							public void MainThread(Message msg) {
							}
						}).getUseCookie();
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1) {
				}
			});
		findViewById(R.id.postButton1).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent in=getIntent();
					UrlStringFactory url=new UrlStringFactory(in.getStringExtra("url"));
					Intent write=new Intent(act, WriteReply.class);
					if (url.toString().indexOf("thread-") != -1) {
						//write.putExtra("tie",url.GetParameterInt("tie"));
						//等待修改
						write.putExtra("fid", fid);
						write.putExtra("inajax", in.getStringExtra("inajax"));
						write.putExtra("tie", url.Pattern("thread-", "-1-1"));
					} else {
						write.putExtra("fid", fid);
						write.putExtra("inajax", in.getStringExtra("inajax"));
						write.putExtra("tie", url.GetParameterInt("tid") + "");
					}
					//LOG.print("tid",url.GetParameterInt("tid")+"");
					//LOG.print("tid",url.GetParameter("tid")+"");
					startActivityForResult(write, 222);
				}
			});

	}
	private void loadingPL(Element body, boolean skip) {
		int base;
		if (skip) {
			base = 1;
		} else {
			base = 0;
		}

		Elements messaged=body.getElementsByClass("comiis_postli comiis_list_readimgs comiis_postli_v1 zpbe");
		for (int index=base;index < messaged.size();index++) {
			Element talk=messaged.get(index);
			String png="",time="",messagex="",floor="",name="",homepage="";
			JSONArray images=new JSONArray();
			JSONArray reply=new JSONArray();
			for (Element blockquote:talk.getElementsByTag("blockquote")) {
				for (Element font:blockquote.getElementsByTag("font")) {
					reply.put(MachiningHTMLString.ToString(font));
				}
			}
			for (Element message : talk.getElementsByClass("top_user f_b")) {
				name = message.text();
			}
			for (Element message : talk.getElementsByClass("top_lev bg_c f_f")) {
				floor = message.text();
			}
			for (Element message : talk.getElementsByClass("comiis_a comiis_message_table cl")) {
				messagex = MachiningHTMLString.ToString(message).trim();
                //LOG.print("恢复",messagex);
			}
			for (Element message : talk.getElementsByClass("top_tximg")) {
				png = message.attr("src");
			}
            for (Element message : talk.getElementsByClass("postli_top_tximg bg_e")) {
                homepage = message.attr("href");
			}
			for (Element message : talk.getElementsByClass("f_d")) {
				time = message.text();
			}
			for (Element message : talk.getElementsByClass("comiis_img_one comiis_vximga cl")) {
				for (Element pngx : message.getElementsByTag("img")) {
					images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
				}
			}
			for (Element message : talk.getElementsByClass("comiis_img_one comiis_vximgb cl")) {
				for (Element pngx : message.getElementsByTag("img")) {
					images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
				}
			}
            for (Element message : talk.getElementsByClass("comiis_img_list comiis_vximgb cl")) {
                for (Element pngx : message.getElementsByTag("img")) {
                    images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
                }
			}
            for (Element message : talk.getElementsByClass("comiis_img_list comiis_vximga cl")) {
                for (Element pngx : message.getElementsByTag("img")) {
                    images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
                }
			}
			for (Element message : talk.getElementsByClass("comiis_img_list comiis_vximgb comiis_vximgb_img4 cl")) {
				for (Element pngx : message.getElementsByTag("img")) {
					images.put(Config.MAIN_URL + "/" + pngx.attr("comiis_loadimages"));
				}
			}
			json.optJSONArray("images").put(images);
			json.optJSONArray("png").put(png);
			json.optJSONArray("time").put(time);
			json.optJSONArray("message").put(messagex);
			json.optJSONArray("floor").put(floor);
			json.optJSONArray("name").put(name);
            json.optJSONArray("homepage").put(homepage);
			//LOG.print("图片输出测试", json.optJSONArray("images").toString());

			json.optJSONArray("reply").put(reply);
		}
		Message msg=new Message();
		msg.what = 3;
		hander.sendMessage(msg);
	}
	/**
     * Spinner自定义样式
     * 1、Spinner内的TextView样式：item_select
     * 2、Spinner下拉中每个item的TextView样式：item_drop
     * 3、Spinner下拉框样式，属性设置
     * */
    public static void ChangeSpinner(Context con,Spinner mSpinnerSimple, String[] spinnerItems) {
        mSpinnerSimple.setDropDownWidth(400); //下拉宽度
        mSpinnerSimple.setDropDownHorizontalOffset(100); //下拉的横向偏移
        mSpinnerSimple.setDropDownVerticalOffset(100); //下拉的纵向偏移
        //mSpinnerSimple.setBackgroundColor(AppUtil.getColor(instance,R.color.wx_bg_gray)); //下拉的背景色
        //spinner mode ： dropdown or dialog , just edit in layout xml
        //mSpinnerSimple.setPrompt("Spinner Title"); //弹出框标题，在dialog下有效
        //String[] spinnerItems = {"10","200","400"};
        //自定义选择填充后的字体样式
        //只能是textview样式，否则报错：ArrayAdapter requires the resource ID to be a TextView
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(con, R.layout.item_select, spinnerItems);
        //自定义下拉的字体样式
        spinnerAdapter.setDropDownViewResource(R.layout.item_drop);
        //这个在不同的Theme下，显示的效果是不同的
        //spinnerAdapter.setDropDownViewTheme(Theme.LIGHT);
        mSpinnerSimple.setAdapter(spinnerAdapter);
    }
	private void loadView() {
		Intent in=getIntent();
		new SendMain(Config.Http.Client, Config.Http.Context,
			in.getStringExtra("url"), null, new SendMain.Function(){
				@Override
				public void OnReturn(String result) {
					Pattern p = Pattern.compile("共 *([0-9]*) *页");  
					Matcher m = p.matcher(result);
					while (m.find()) {
						maxPage = Integer.parseInt(m.group(1)) + 1;
					}
					final ArrayList<String> str=new ArrayList<String>();
					for (int index=1;index < maxPage;index++) {
						str.add("第" + index + "页");
					}
					act.runOnUiThread(new Runnable(){
							@Override
							public void run() {
								ChangeSpinner(act,(Spinner)findViewById(R.id.postSpinner1) , (String[])str.toArray(new String[str.size()]));

							}
						});

                    if (!getIntent().hasExtra("fid")) {
                        String pattern = "&fid=([0-9]*)&";
                        Pattern r = Pattern.compile(pattern);
                        Matcher mt = r.matcher(result);
                        if (mt.find()) fid = mt.group(1);
                    } else {
                        fid = getIntent().getStringExtra("fid");
                    }

					Document doc=Jsoup.parse(result);

					String[] strArr=new String[]{"标题","作者","头像","内容","时间","主页"};
					for (Element body : doc.getElementsByClass("comiis_bodybox")) {
						for (Element messagex : body.getElementsByClass("comiis_viewtit bg_f cl")) {
							for (Element message : messagex.getElementsByTag("h2")) {
							    strArr[0] = message.text();
							}
						}
						Element head=body.getElementsByClass("comiis_postli comiis_list_readimgs comiis_postli_v1 zpbe").get(0);
						for (Element message:head.getElementsByClass("top_tximg")) {
							strArr[2] = message.attr("src");
						}
						for (Element messagex : head.getElementsByClass("comiis_postli_time")) {
							for (Element message : messagex.getElementsByClass("f_d")) {
							    strArr[4] = message.text();
							}
						}
						for (Element message : head.getElementsByClass("comiis_a comiis_message_table cl")) {
							strArr[3] = MachiningHTMLString.ToString(message);
						}
						for (Element message : head.getElementsByClass("top_user f_b")) {
							strArr[1] = message.text();
                            strArr[5] = message.attr("href");
						}
						Message msg=new Message();
						msg.what = 1;
						msg.obj = strArr;
						hander.sendMessage(msg);

						ArrayList<String> img=new ArrayList<String>();
						for (Element pngs : head.getElementsByClass("comiis_img_one cl")) {
							for (Element png: pngs.getElementsByTag("img")) {
								img.add(Config.MAIN_URL + "/" + png.attr("comiis_loadimages"));
							}
						}
						for (Element pngs : head.getElementsByClass("comiis_img_list cl")) {
							for (Element png: pngs.getElementsByTag("img")) {
								img.add(Config.MAIN_URL + "/" + png.attr("comiis_loadimages"));
							}
						}
						Message msgx=new Message();
						msgx.what = 2;
						msgx.obj = img;
						hander.sendMessage(msgx);
						System.out.println(json.toString());
						loadingPL(body, true);
						
					}

				}

				@Override
				public void MainThread(Message msg) {
				}
			}).getUseCookie();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO 自动生成的方法存根
		if (requestCode == 222 && resultCode == 2) {
			reStart();
		}
	};
	
	private void reStart() {
		if (Build.VERSION.SDK_INT >= 11) {
			recreate();   
		} else {
			Intent intent = getIntent();
			finish();
			startActivity(intent);
		}
	}
}
