package com.play.common;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class SlideFree{
	private Context context;
	private float x = 0;//点击时候坐标位置
	private float y = 0;
	private float startx;//自定义view的开始坐标位置
	private float starty;
	private View v;
	private float nmovey;
	private float smovey;
	public GestureDetector.OnGestureListener GDO;
	public SlideFree(Context con,View view,final float smovey,final float nmovey){
		context=con;v=view;
		this.nmovey=nmovey;
		this.smovey=smovey;
	    GDO=new GestureDetector.OnGestureListener() {

				@Override
				public boolean onDown(MotionEvent event) {
					/*
					Rect rect = new Rect();
					v.getGlobalVisibleRect(rect);
					startx = (rect.left); //设置当前view x坐标位置
					
					Rect frame = new Rect();
					((Activity)context).getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
					int statusBarHeight = frame.top;
					starty = (rect.top - statusBarHeight*2);
					*/
					/*
					Log.d("mile","event.getRawX():"+event.getRawY());
					Log.d("mile","event.getRawY():"+event.getRawY());
					//新建一个Rect来获取当前view的坐标位置
					Rect rect = new Rect();
					v.getGlobalVisibleRect(rect);
					startx = (rect.left); //设置当前view x坐标位置

					//获取状态来的高度
					Rect frame = new Rect();
					((Activity)context).getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
					int statusBarHeight = frame.top;
					statty = (rect.top - statusBarHeight);//设置当前view y坐标 需要减去状态来高度
					*/
					return true;
				}

				@Override
				public void onShowPress(MotionEvent p1) {
				}

				@Override
				public boolean onSingleTapUp(MotionEvent p1) {
					return false;
				}

				@Override
				public boolean onScroll(MotionEvent p1, MotionEvent event, float p3, float p4) {
					//startx += event.getRawX() - p1.getRawX();
					starty += event.getRawY() - p1.getRawY();
					starty=Math.max(Math.min(starty,nmovey),smovey);
					//v.setTranslationX(startx);
					v.setTranslationY(starty);
					return true;
				}

				@Override
				public void onLongPress(MotionEvent p1) {
				}

				@Override
				public boolean onFling(MotionEvent event, MotionEvent p2, float p3, float p4) {
					return true;
				}

			};
		
	}
    
    
}
