package com.play.box;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import bms.helper.android.FaceUtil;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import bms.helper.lang.Stringx;
import com.play.common.Config;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import bms.helper.http.UrlStringFactory;
import org.json.JSONObject;
import org.json.JSONException;
import com.play.box.activity.MostActivityUse;

public class WriteReply extends MostActivityUse {
	WriteReply act=this;
	RecyclerAdapter[] adp;
	public static final Stringx formhash=new Stringx("");
	public static final Stringx posttime=new Stringx("");
	final String[] mustUS=new String[]{"",""};
	int[] focusid=new int[]{R.id.forumpostwriteEditText1,
		R.id.forumpostwriteEditText2};
	int focus=0;
	ArrayList<String> images=new ArrayList<String>();
	ArrayList<String> imageRes=new ArrayList<String>();
	Handler handler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 0) {
				Intent in=act.getIntent();
				String inajax=in.getStringExtra("inajax");
				String fid=in.getStringExtra("fid");
				JSONObject map=new JSONObject();
				try {
					map.put("noticetrimstr", "");
				map.put("noticeauthormsg", "");
				map.put("noticeauthor", "");
				map.put("replysubmit", "yes");
				map.put("formhash", formhash.x);
				map.put("posttime", posttime.x);
				map.put("usesig","1");
				//map.put("subject", ((EditText)findViewById(focusid[0])).getText());
				map.put("message", ((EditText)findViewById(focusid[1])).getText());
				for (String s : imageRes) {
					if (s != null) {
						map.put("attachnew[" + s + "][description]", "");
					}
				}
				} catch (JSONException e) {}
				String tie=in.getStringExtra("tie");
				
				UrlStringFactory url=new UrlStringFactory(Config.Forum.REPLY_MAIN);
				url.SetParameter("fid",fid);
				url.SetParameter("inajax",inajax);
				url.SetParameter("tid",tie);
				new SendMain(Config.Http.Client, Config.Http.Context,
					 url.toString(),
					map, new SendMain.Function(){
						@Override
						public void OnReturn(String result) {
							Document doc=Jsoup.parse(result.replace("<![CDATA[", "").replace("]]>", ""));
							String res=doc.getElementById("messagetext").text();
							Message msg=new Message();
							msg.what = 2;
							msg.obj = res;
							handler.sendMessage(msg);
						}

						@Override
						public void MainThread(Message msg) {
						}
					}
				).postUseCookie();
			} else if (msg.what == 2) {
				String res=(String) msg.obj;
				Toast.makeText(getApplication(), res, Toast.LENGTH_SHORT).show();
				if (res.indexOf("发布成功") != -1) {
					setResult(2);
					finish();
				}else{
					findViewById(R.id.loading).setVisibility(8);
				}
			} else if (msg.what == 4) {
				if (msg.obj == null) {
					imageRes.add(null);
				} else {
					imageRes.add(((String)msg.obj).split("\\|")[3]);
				}
				if (imageRes.size() == images.size()) {
					Message msgz=new Message();
					msgz.what = 0;
					handler.sendMessage(msgz);
					/*
					 Message msgz=new Message();
					 msgz.what = 3;
					 handler.sendMessage(msgz);
					 */
				}
			} else if (msg.what == 3) {
				for (String png : images) {
					JSONObject map=new JSONObject();
					try{
					map.put("uid", mustUS[0]);
					map.put("hash", mustUS[1]);
					} catch (JSONException e) {}
					new SendMain(Config.Http.Client, Config.Http.Context, Config.Forum.SEND_Image
						, map, new SendMain.Function(){
							@Override
							public void OnReturn(String result) {
								Message msg=new Message();
								msg.what = 4;
								msg.obj = result;
								handler.sendMessage(msg);
							}

							@Override
							public void MainThread(Message msg) {
							}
						}).postFile(png, "Filedata", "ic_pencil_plus.png");
				}
				if(images.size()==0){
					Message msgz=new Message();
					msgz.what = 0;
					handler.sendMessage(msgz);
				}
			} else if (msg.what == 5) {
				//第二个参数：1，用来表示是哪一个startActivityForResult发起的，以便回调分别。回调中的requestCode
				startActivityForResult(selectPicture(), 1);
			}
		}
	};
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SetTitleFree("发布评论");
        setContentView(R.layout.forum_post_write);
		act.findViewById(R.id.forumpostwritefunction).setVisibility(8);
		findViewById(R.id.forumpostwriteEditText1).setVisibility(8);
		
		adp = new RecyclerAdapter []{
			new RecyclerAdapter(){
				@Override
				public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
					View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.forum_write_post_item_expression, viewGroup, false);
					return new RecyclerAdapter.ViewHolder(v);
				}

				@Override
				public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
					View v=viewHolder.v;
					((ImageView)v.findViewById(R.id.forumwritepostitemexpressionImageView1)).setImageBitmap(
						FaceUtil.getFaceImage(FaceUtil.bitmapkey.get(position)));
					v.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View view) {
								View vFocus=getWindow().getDecorView().findFocus();
								if (vFocus instanceof EditText) {
									FaceUtil.AddEditText(act,
														 (EditText)vFocus
														 , FaceUtil.bitmapkey.get(position));
									//open((EditText)vFocus);
								}
							}
						});
				}

				@Override
				public int getItemCount() {
					return FaceUtil.bitmapkey.size();
				}
			},
			new RecyclerAdapter(){
				@Override
				public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
					View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.forum_write_post_item_pic, viewGroup, false);
					return new RecyclerAdapter.ViewHolder(v);
				}
				@Override
				public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
					View v=viewHolder.v;
					ImageView img=((ImageView)v.findViewById(R.id.forumwritepostitempicImageView1));
					View ch=((View)v.findViewById(R.id.forumwritepostitempicImageView2));
					if (position == images.size()) {
						ch.setVisibility(8);
						img.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View view) {
									Message msg=new Message();
									msg.what = 5;
									handler.sendMessage(msg);
								}
							});
					} else {
						img.setImageBitmap(BitmapFactory.decodeFile(images.get(position)));
						ch.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View view) {
									images.remove(position);
									adp[1].notifyDataSetChanged();
								}
							});
					}
				}

				@Override
				public int getItemCount() {
					return Math.min(images.size() + 1, 9);
				}
			}
		};
		AddTouch();
	}
	private void Putaway() {
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
		act.findViewById(R.id.forumpostwritefunction).setVisibility(0);

	}
	private void open(EditText diaryEdit) {
		/*diaryEdit.requestFocus();
		 InputMethodManager manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
		 if (manager != null) manager.showSoftInput(diaryEdit, 0);
		 */
		act.findViewById(R.id.forumpostwritefunction).setVisibility(8);
	}
	private void AddTouch() {
		findViewById(R.id.loading).setVisibility(8);
		((View)findViewById(R.id.forumpostwriteButton1)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {

					Intent in=act.getIntent();
					//String inajax=in.getStringExtra("inajax");
					String fid=in.getStringExtra("fid");
					String tie=in.getStringExtra("tie");
					findViewById(R.id.loading).setVisibility(0);
					UrlStringFactory url=new UrlStringFactory(Config.Forum.REPLY_COOKIE);
					url.SetParameter("fid",fid);
					//url.SetParameter("inajax",inajax);
					url.SetParameter("tid",tie);
					url.SetParameter("mobile","2");
					new SendMain(Config.Http.Client, Config.Http.Context, url.toString(),
						null, new SendMain.Function(){
							@Override
							public void MainThread(Message msg) {
							}
							@Override
							public void OnReturn(String result) {
								
								Pattern r = Pattern.compile("uid:\"([0-9]*)\".*hash:\"(.*)\"");
								Matcher m = r.matcher(result);
								if (m.find()) {
								    mustUS[0] = m.group(1);
									mustUS[1] = m.group(2);
								}
								
								Document doc=Jsoup.parse(result);
								posttime.set(doc.getElementById("posttime").attr("value"));
								formhash.set(doc.getElementById("formhash").attr("value"));
								Message msg=new Message();
								msg.what = 3;

								handler.sendMessage(msg);
							}
						}).getUseCookie();



				}


			});
		((View)findViewById(R.id.forumpostwriteImageView1)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					RecyclerView recycler_view = findViewById(R.id.Randombar);

					recycler_view.setLayoutManager(new LinearLayoutManager(act, LinearLayoutManager.HORIZONTAL, false));

					recycler_view.setHasFixedSize(true);
					recycler_view.setAdapter(adp[1]);
					recycler_view.setNestedScrollingEnabled(false);
					Putaway();
				}
			});
		((View)findViewById(focusid[0])).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					focus = 0;
					open((EditText)view);
				}
			});
		((View)findViewById(focusid[1])).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					focus = 1;
					open((EditText)view);
				}
			});
		((View)findViewById(R.id.forumpostwriteImageView2)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					RecyclerView recycler_view = findViewById(R.id.Randombar);
					GridLayoutManager mLayoutManager = new GridLayoutManager(act, 8);
					recycler_view.setLayoutManager(mLayoutManager);
					recycler_view.setHasFixedSize(true);
					recycler_view.setAdapter(adp[0]);
					recycler_view.setNestedScrollingEnabled(false);
					Putaway();
				}
			});
	}

	//调用系统图库选择图片
	public Intent selectPicture() {
		Intent intent = new Intent(
			Intent.ACTION_PICK,
			android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    	return intent;
	}



	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO 自动生成的方法存根
		if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
			Uri selectedImage = data.getData();
			String[] filePathColumn = { MediaStore.Images.Media.DATA };
			//查询我们需要的数据
			Cursor cursor = getContentResolver().query(selectedImage,
													   filePathColumn, null, null, null);
			cursor.moveToFirst();

			int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			String picturePath = cursor.getString(columnIndex);
			cursor.close();

			//拿到了图片的路径picturePath可以自行使用
			images.add(picturePath);
			adp[1].notifyDataSetChanged();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
