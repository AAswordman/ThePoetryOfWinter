package com.play.box;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import bms.helper.android.TextureVideoViewOutlineProvider;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import com.play.android.MyImageView;
import com.play.common.Config;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.play.common.LOG;
import android.text.Html;
import android.content.Intent;

public class PersonHomePage extends AppCompatActivity {
	CrashHandler crashHandler;
	String uid;
	PersonHomePage act=this;
    RecyclerAdapter adp;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
        setContentView(R.layout.person_homepage);
        getSupportActionBar().hide();
		((View)findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					finish();
				}
			});
		
		UrlStringFactory fac=new UrlStringFactory(getIntent().getStringExtra("url"));
		uid=fac.GetParameter("uid");
		new SendMain(Config.Http.Client,Config.Http.Context,fac.toString(),
			null, new SendMain.Function(){
				@Override
				public void OnReturn(String result) {
					if(result==null){
						Toast.makeText(getApplication(), "加载失败", Toast.LENGTH_SHORT).show();
					}else{
						final String[] data=new String[]{"","","","","","","无认证"};
						Document doc=Jsoup.parse(result);
						Element body=doc.getElementsByClass("comiis_bodybox").get(0);
						Element user_code_top=body.getElementsByClass("comiis_user_code_top").get(0);
						data[0]=user_code_top.getElementsByTag("h2").get(0).text();
						data[1]=user_code_top.getElementsByTag("img").get(0).attr("src");
						String pattern = ".comiis_space_box\\{background:url\\((.*)\\)";
						Pattern r = Pattern.compile(pattern);
						Matcher m = r.matcher(result);
						if(m.find()){
							data[2]=m.group(1).replace("./",Config.MAIN_URL+"/");
						}
						data[3]=body.getElementsByClass("profile_r profile_face f_c").get(0).html();
						r = Pattern.compile("粉丝 ([0-9]*)");
						m = r.matcher(result);
						if(m.find()){
							data[4]=m.group(1);
						}
						r = Pattern.compile("好友 ([0-9]*)");
						m = r.matcher(result);
						if(m.find()){
							data[5]=m.group(1);
						}
						Elements authentication=body.getElementsByClass("profile_r comiis_verify").get(0).getElementsByTag("p");
						if(authentication.size()!=0){
							data[6]=authentication.get(0).text();
						}
						act.runOnUiThread(new Runnable(){
								@Override
								public void run() {
								    ((TextView)findViewById(R.id.name)).setText(data[0]);
									((MyImageView)findViewById(R.id.face)).setImageURL(data[1]);
									TextureVideoViewOutlineProvider.round(act,R.id.face);
									((MyImageView)findViewById(R.id.homepage_top_img)).setImageURL(data[2]);
									((TextView)findViewById(R.id.signiture)).setText(Html.fromHtml(data[3]));
									((TextView)findViewById(R.id.attend_num)).setText(data[5]);
									((TextView)findViewById(R.id.attended_num)).setText(data[4]);
									if(data[6].equals("无认证")||data[6].trim().equals("")){
										findViewById(R.id.auth_type_name).setVisibility(8);
									}else{
										((TextView)findViewById(R.id.auth_type_name)).setText("官方认证:"+data[6]);
									}
								}
						});
                        
                        new SendMain(Config.Http.Client,Config.Http.Context,
                        new UrlStringFactory(Config.Person.POST)
                            .SetParameter("uid", uid).toString(), null, new SendMain.Function(){
                                @Override
                                public void OnReturn(String result) {
                                    final ArrayList<String> time=new ArrayList<>();
                                    final ArrayList<String> message=new ArrayList<>();
                                    final ArrayList<String> title=new ArrayList<>();
                                    final ArrayList<String> post=new ArrayList<>();
                                    Document doc=Jsoup.parse(result);
                                    
                                    for(Element e:doc.getElementsByClass("forumlist_li_time"))time.add(e.text());
                                    for(Element nr:doc.getElementsByClass("mmlist_li_box cl")){
                                        String msg="",tit="",go="";
                                        Elements msgs=nr.getElementsByClass("list_body cl"),tits=nr.getElementsByTag("h2");
                                        if(msgs.size()!=0){
                                            msg=msgs.get(0).text();
                                            go=Config.MAIN_URL+"/"+msgs.get(0).getElementsByTag("a")
                                            .get(0).attr("href");
                                        }
                                        if(tits.size()!=0){
                                            tit=tits.get(0).text();
                                        }
                                        message.add(msg);
                                        title.add(tit);
                                        post.add(go);
                                    }
                                    
                                    adp = new RecyclerAdapter(){

                                        @Override
                                        public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                                            return new RecyclerAdapter.ViewHolder(this.CreateView(viewGroup,R.layout.person_post_item));
                                        }

                                        @Override
                                        public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                                            View v=viewHolder.v;
                                            ((TextView)v.findViewById(R.id.title)).setText(title.get(position));
                                            ((TextView)v.findViewById(R.id.desc)).setText(message.get(position));
                                            ((TextView)v.findViewById(R.id.time)).setText(time.get(position));
                                            v.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        Intent web=new Intent(act, URLHandleActivity.class);
                                                        web.putExtra("name", "帖子");
                                                        web.putExtra("url", post.get(position));
                                                        startActivity(web);
                                                    }
                                                });
                                        }
                                        @Override
                                        public int getItemCount() {
                                            return message.size();
                                        }
                                    };
                                    runOnUiThread(new Runnable(){
                                            @Override
                                            public void run() {
                                                RecyclerView recycler_view = findViewById(R.id.tidpage);
                                                LinearLayoutManager mLayoutManager = new LinearLayoutManager(act);
                                                recycler_view.setLayoutManager(mLayoutManager);
                                                recycler_view.setHasFixedSize(true);
                                                recycler_view.setAdapter(adp);
                                                recycler_view.setNestedScrollingEnabled(false);
                                            }
                                        });
                                }

                                @Override
                                public void MainThread(Message msg) {
                                }
                            }).getUseCookie();
					}
				}

				@Override
				public void MainThread(Message msg) {
				}
		}).getUseCookie();
			
	}
}
