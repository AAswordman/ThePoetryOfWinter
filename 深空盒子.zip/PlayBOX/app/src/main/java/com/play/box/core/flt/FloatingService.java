package com.play.box.core.flt;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.io.AssetsUtil;
import bms.helper.script.json.JSONTools;
import chineseframe.屏幕工具;
import com.play.box.R;
import com.play.box.core.CoreWS;
import com.play.box.core.ServerManager;
import com.play.common.LOG;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import org.java_websocket.WebSocket;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.support.v4.app.NotificationCompat;
import android.graphics.BitmapFactory;
import android.app.NotificationManager;

public class FloatingService extends Service {
    View allview;
    int SettingX=200;
    int SettingY=200;
    static ServerManager serverManager=new ServerManager();
    FloatingService sv=this;
    HashMap<Integer,UseFindResult> useCommand=new HashMap<>();
    HashMap<Integer,UseFindResult> inspectCommand=new HashMap<>();
    HashMap<Integer,UseFindResult> usePlayerCommand=new HashMap<>();
    RecyclerAdapter adp,tplist,enclist;
    JSONObject playersList=new JSONObject();
    HashMap<Integer,Integer> choosebar=new HashMap<>();
    ArrayList<EnchantingData> enchantingdata=new ArrayList<>();
    String ChoosePlayer=null;
    ArrayList<String> player_blacklist=new ArrayList<>();
    boolean sanction=false;
    ArrayList<PositionData> positiondata=new ArrayList<>();

    @Override
    public IBinder onBind(Intent p1) {
        return null;
    }
    Handler thd=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                adp.notifyDataSetChanged();
            }
        }
    };
    Handler timer=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 2) {
                //for(
                SendCommand("/tp @a[tag=playblacklist] 9999 -99 9999", UUID.randomUUID().toString());
                SendCommand("/gamemode 0 @a[tag=playblacklist]", UUID.randomUUID().toString());
                SendCommand("/kill @a[tag=playblacklist]", UUID.randomUUID().toString());
                removeMessages(2);
                if (sanction) sendEmptyMessageDelayed(2, 2000);
            }
        }
    };

    WindowManager.LayoutParams layoutParams;
    RelativeLayout.LayoutParams logo;
    public static Intent intent;
    WindowManager windowManager;
    @Override
    public void onCreate() {
        super.onCreate();
        
        //Notification notification = new Notification(R.drawable.logo,"深空盒子悬浮窗",
        //                                             System.currentTimeMillis());
        Notification notification = new NotificationCompat.Builder(this)
            .setContentTitle("深空我的世界盒子")  //设置标题
            .setContentText("(PLAYBOX)悬浮窗运行中") //设置内容
            .setWhen(System.currentTimeMillis())  //设置时间
            .setSmallIcon(R.drawable.logo)  //设置小图标
            .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))   //设置大图标
            
        .build();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(1,notification);
        startForeground(1,notification);
        
        
        showFloatingWindow();
        Initjson();
        tplist = new RecyclerAdapter(){

            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                return new RecyclerAdapter.ViewHolder(this.CreateView(viewGroup, R.layout.suspension_main_tplist));
            }

            @Override
            public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, int position) {
                View v=viewHolder.v;
                final PositionData data=positiondata.get(position);
                ((TextView)v.findViewById(R.id.tp_tag)).setText(data.tag);
                ((TextView)v.findViewById(R.id.tp_position)).setText(data.position);
                v.findViewById(R.id.tp_start).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SendCommand("/tp " + "\"" + ChoosePlayer + "\"" + " " + data.position, UUID.randomUUID().toString());
                        }
                    });
            }

            @Override
            public int getItemCount() {
                return positiondata.size();
            }
        };
        adp = new RecyclerAdapter(){

            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                return new RecyclerAdapter.ViewHolder(this.CreateView(viewGroup, R.layout.suspension_main_playerlist));
            }

            @Override
            public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                View v=viewHolder.v;

                ((TextView)v.findViewById(R.id.name)).setText(playersList.optJSONArray("name").optString(position));
                v.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ChoosePlayer = playersList.optJSONArray("name").optString(position);
                            allview.findViewById(R.id.Players_choose).setVisibility(8);
                            allview.findViewById(R.id.Players_set).setVisibility(0);
                            allview.findViewById(R.id.Tp_back).setVisibility(8);
                            allview.findViewById(R.id.Tp_setting).setVisibility(0);
                            allview.findViewById(R.id.Builder_back).setVisibility(8);
                            allview.findViewById(R.id.Builder_setting).setVisibility(0);
                            allview.findViewById(R.id.Enchanting_back).setVisibility(8);
                    allview.findViewById(R.id.Enchanting_setting).setVisibility(0);
                            ((TextView)allview.findViewById(R.id.player_choose_name)).setText(playersList.optJSONArray("name").optString(position));
                        }
                    });
            }
            @Override
            public int getItemCount() {
                return playersList.optJSONArray("name").length();
            }
        };

        final JSONArray arr=JSONTools.parse(AssetsUtil.getFromAssets(this, "core/enchanting/id.json")).optJSONArray("id");
        for (int index=0;index < arr.length();index++) {
            JSONObject obj=arr.optJSONObject(index);
            enchantingdata.add(new EnchantingData(obj.optString("id"), 0, obj.optInt("max"), obj.optString("name")));
        }
        enclist = new RecyclerAdapter(){
            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                return new ViewHolder(this.CreateView(viewGroup, R.layout.suspension_main_enchantinglist));
            }

            @Override
            public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                View v=viewHolder.v;
                ((TextView)v.findViewById(R.id.EnchantingName)).setText(enchantingdata.get(position).name);
                v.findViewById(R.id.EnchantingAdd).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            enchantingdata.get(position).add();
                            enclist.notifyItemChanged(position);
                        }
                    });
                v.findViewById(R.id.EnchantingRemove).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            enchantingdata.get(position).remove();
                            enclist.notifyItemChanged(position);
                        }
                    });
                ((CheckBox)v.findViewById(R.id.EnchantingUse)).setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
                        @Override
                        public void onCheckedChanged(CompoundButton p1, boolean p2) {
                            enchantingdata.get(position).use = p2;
                        }
                    });
                ((CheckBox)v.findViewById(R.id.EnchantingUse)).setChecked(enchantingdata.get(position).use);
                ((TextView)v.findViewById(R.id.EnchantingNum)).setText(enchantingdata.get(position).value+"");
            }

            @Override
            public int getItemCount() {
                return enchantingdata.size();
            }
        };

        RecyclerView recycler_view =allview. findViewById(R.id.player_playerlist);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        recycler_view.setLayoutManager(mLayoutManager);
        recycler_view.setHasFixedSize(true);
        recycler_view.setAdapter(adp);
        recycler_view.setNestedScrollingEnabled(false);

        recycler_view = allview. findViewById(R.id.tp_list);
        mLayoutManager = new LinearLayoutManager(this);
        recycler_view.setLayoutManager(mLayoutManager);
        recycler_view.setHasFixedSize(true);
        recycler_view.setAdapter(tplist);
        recycler_view.setNestedScrollingEnabled(false);

        recycler_view = allview. findViewById(R.id.enchanting_list);
        mLayoutManager = new LinearLayoutManager(this);
        recycler_view.setLayoutManager(mLayoutManager);
        recycler_view.setHasFixedSize(true);
        recycler_view.setAdapter(enclist);
        recycler_view.setNestedScrollingEnabled(false);

        //初始化命令发送
        Command.Init(serverManager);
        new Thread(new Runnable(){
                @Override
                public void run() {
                    serverManager.Start(1233, new CoreWS.Function(){
                            @Override
                            public void OnConnect(WebSocket conn) {
                                String[] events = "AgentCommand;PlayerMessage;AgentCreated".split(";");
                                for (String eventName:events) {
                                    SubscribeEvent(conn, eventName);
                                }
                            }
                            @Override
                            public void OnResult(String message) {
                                LOG.print("收到", message);
                                JSONObject json = null;
                                try {
                                    json = new JSONObject(message);
                                } catch (JSONException e) {}
                                if (!json.optJSONObject("body").has("eventName")) {
                                    Command.OnResult(json);
                                } else {
                                    if (json.optJSONObject("body").optString("eventName").equals("BlockPlaced")) {
                                        JSONObject properties=json.optJSONObject("body").optJSONObject("properties");
                                        final String block=properties.optString("Block") + " " + properties.optInt("AuxType");
                                        runOnUiThread(new Runnable(){
                                                @Override
                                                public void run() {
                                                    ((EditText)allview.findViewById(R.id.build_baseblock)).setText(block);
                                                }
                                            });

                                    }
                                }
                            }
                        });
                }
            }).start();
    }

    private void Initjson() {
        try {
            playersList.put("name", new JSONArray());
        } catch (JSONException e) {}
    }
    public int getStatusBarHeight() {
        Resources resources = getResources();
        int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        return resources.getDimensionPixelSize(resourceId);
    }
    private void showFloatingWindow() {
        // if(Settings.canDrawOverlays(this)) {
// 获取WindowManager服务
        //windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
// 新建悬浮窗控件
        allview = LayoutInflater.from(this).inflate(R.layout.suspension_main, null);
        allview.findViewById(R.id.logo).setOnTouchListener(new FloatingOnTouchListener());
        allview.findViewById(R.id.logo).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    allview.findViewById(R.id.logo).setVisibility(8);
                    allview.findViewById(R.id.main).setVisibility(0);

                    layoutParams.width = windowManager.getDefaultDisplay().getWidth();
                    layoutParams.height = windowManager.getDefaultDisplay().getHeight();
                    layoutParams.x = 0;
                    layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                    layoutParams.y = getStatusBarHeight();
                    windowManager.updateViewLayout(allview, layoutParams);
                }
            });
        allview.findViewById(R.id.main).setVisibility(8);
        allview.findViewById(R.id.main).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    allview.findViewById(R.id.logo).setVisibility(0);
                    allview.findViewById(R.id.main).setVisibility(8);

                    layoutParams.width = 屏幕工具.dp转像素(sv, 45);
                    layoutParams.height = 屏幕工具.dp转像素(sv, 45);
                    layoutParams.x = SettingX;
                    layoutParams.y = SettingY;
                    layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    windowManager.updateViewLayout(allview, layoutParams);
                }
            });
        allview.findViewById(R.id.Close_All).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    stopForeground(true);
                    stopService(intent);
                    
                }
            });
// 设置LayoutParam
        layoutParams = new WindowManager.LayoutParams();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        layoutParams.format = PixelFormat.RGBA_8888;
        layoutParams.width = 屏幕工具.dp转像素(sv, 45);
        layoutParams.height = 屏幕工具.dp转像素(sv, 45);
        layoutParams.x = SettingX;
        layoutParams.y = SettingY;
// 将悬浮窗控件添加到WindowManager
        windowManager.addView(allview, layoutParams);

        logo = (RelativeLayout.LayoutParams)allview.findViewById(R.id.logo).getLayoutParams();

        useCommand.put(R.id.weather_a, new UseFindResult("/weather clear"));
        useCommand.put(R.id.weather_b, new UseFindResult("/weather rain"));
        useCommand.put(R.id.weather_c, new UseFindResult("/weather thunder"));

        useCommand.put(R.id.difficulty0, new UseFindResult("/difficulty peaceful"));
        useCommand.put(R.id.difficulty1, new UseFindResult("/difficulty easy"));
        useCommand.put(R.id.difficulty2, new UseFindResult("/difficulty normal"));
        useCommand.put(R.id.difficulty3, new UseFindResult("/difficulty hard"));

        useCommand.put(R.id.player_reload, new UseFindResult("/list", new AfterFindResult(){
                               @Override
                               public void OnResult(JSONObject message) {
                                   //LOG.print("查找信息","得到");
                                   try {
                                       playersList.put("name", new JSONArray());
                                   } catch (JSONException e) {}
                                   ArrayList<String> str=new ArrayList<>(Arrays.asList(message.optJSONObject("body").optString("players").split("\n")));
                                   for (String playername : str) {
                                       playersList.optJSONArray("name").put(playername);
                                   }
                                   /*
                                    for(String name:player_blacklist){
                                    if(str.indexOf(name)==-1){
                                    player_blacklist.remove(name);
                                    }
                                    }
                                    */
                                   Message msg=new Message();
                                   msg.what = 1;
                                   thd.sendMessage(msg);
                               }
                           }));

        choosebar.put(R.id.to_Config, R.id.Config);
        choosebar.put(R.id.to_Game, R.id.Game);
        choosebar.put(R.id.to_Players, R.id.Players);
        choosebar.put(R.id.to_Tp, R.id.Tp);
        choosebar.put(R.id.to_Builder, R.id.Builder);
        choosebar.put(R.id.to_Enchanting, R.id.Enchanting);

        inspectCommand.put(R.id.gamerule_daynight, new UseFindResult("/gamerule dodaylightcycle"));
        inspectCommand.put(R.id.gamerule_playerhurtanother, new UseFindResult("/gamerule pvp"));
        inspectCommand.put(R.id.gamerule_showzb, new UseFindResult("/gamerule showcoordinates"));
        inspectCommand.put(R.id.gamerule_weatherchange, new UseFindResult("/gamerule doweathercycle true"));

        usePlayerCommand.put(R.id.player_setborn, new UseFindResult("/execute [target] ~ ~ ~ spawnpoint"));
        usePlayerCommand.put(R.id.playergamemode_a, new UseFindResult("/execute [target] ~ ~ ~ gamemode survival"));
        usePlayerCommand.put(R.id.playergamemode_b, new UseFindResult("/execute [target] ~ ~ ~ gamemode creative"));
        usePlayerCommand.put(R.id.playergamemode_c, new UseFindResult("/execute [target] ~ ~ ~ gamemode adventure"));
        GameSetting();
        // }

    }

    private void ChooseReset() {
        Iterator iter=choosebar.keySet().iterator();
        while (iter.hasNext()) {
            int key=iter.next();
            final int use=choosebar.get(key);
            allview.findViewById(key).setBackgroundColor(Color.parseColor("#E92E2E2E"));
            allview.findViewById(use).setVisibility(8);
        }
    }

    private void GameSetting() {
        Iterator iter=choosebar.keySet().iterator();
        while (iter.hasNext()) {
            int key=iter.next();
            final int use=choosebar.get(key);
            allview.findViewById(key).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ChooseReset();
                        view.setBackgroundColor(Color.parseColor("#FF4CAF50"));
                        allview.findViewById(use).setVisibility(0);
                    }
                });
        }
        ((SeekBar)allview.findViewById(R.id.time_judge)).setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                int pos=0;
                @Override
                public void onProgressChanged(SeekBar p1, int p2, boolean p3) {
                    pos = p2;
                }

                @Override
                public void onStartTrackingTouch(SeekBar p1) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar p1) {
                    SendCommand("/time set " + (int)Math.round((24000 * pos) / 100), UUID.randomUUID().toString());
                }
            });
        iter = useCommand.keySet().iterator();
        while (iter.hasNext()) {
            int key=iter.next();
            final UseFindResult use=useCommand.get(key);
            allview.findViewById(key).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uuid=UUID.randomUUID().toString();
                        SendCommand(use, uuid);

                    }
                });
        }
        iter = inspectCommand.keySet().iterator();
        while (iter.hasNext()) {
            int key=iter.next();
            final UseFindResult use=inspectCommand.get(key);
            ((Switch) allview.findViewById(key)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton p1, boolean p2) {
                        SendCommand(use.command + " " + p2, UUID.randomUUID().toString());
                    }
                });
        }
        iter = usePlayerCommand.keySet().iterator();
        while (iter.hasNext()) {
            int key=iter.next();
            final UseFindResult use=usePlayerCommand.get(key);
            allview.findViewById(key).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uuid=UUID.randomUUID().toString();
                        use.command.replace("[target]", "\"" + ChoosePlayer + "\"");
                        SendCommand(use, uuid);
                    }
                });
        }


        allview.findViewById(R.id.enchanting_max).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    for (EnchantingData e : enchantingdata) {
                        e.value = e.max;e.use = true;
                    }
                    enclist.notifyDataSetChanged();
                }
            });
        allview.findViewById(R.id.enchanting_start).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    for (EnchantingData e : enchantingdata) {
                        e.run(ChoosePlayer);
                    }

                }
            });


        allview.findViewById(R.id.start_copy).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //获取剪贴版
                    ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
//创建ClipData对象
//第一个参数只是一个标记，随便传入。
//第二个参数是要复制到剪贴版的内容
                    ClipData clip = ClipData.newPlainText("simple text", "/connect 127.0.0.1:1233");
//传入clipdata对象.
                    clipboard.setPrimaryClip(clip);
                }
            });
        ((Switch) allview.findViewById(R.id.player_blacklist)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    //SendCommand(use.command + " " + p2, UUID.randomUUID().toString());
                    if (p2) {
                        player_blacklist.add(ChoosePlayer);
                        SendCommand("/tag " + "\"" + ChoosePlayer + "\"" + " add playblacklist", UUID.randomUUID().toString());
                    } else {
                        player_blacklist.remove(ChoosePlayer);
                        SendCommand("/tag " + "\"" + ChoosePlayer + "\"" + " remove playblacklist", UUID.randomUUID().toString());
                    }
                }
            });
        allview.findViewById(R.id.player_back).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ChoosePlayer = null;
                    allview.findViewById(R.id.Players_choose).setVisibility(0);
                    allview.findViewById(R.id.Players_set).setVisibility(8);
                    allview.findViewById(R.id.Tp_back).setVisibility(0);
                    allview.findViewById(R.id.Tp_setting).setVisibility(8);
                    allview.findViewById(R.id.Builder_back).setVisibility(0);
                    allview.findViewById(R.id.Builder_setting).setVisibility(8);
                    allview.findViewById(R.id.Enchanting_back).setVisibility(0);
                    allview.findViewById(R.id.Enchanting_setting).setVisibility(8);
                }
            });
        ((Switch)allview.findViewById(R.id.gamerule_sanction)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    //SendCommand(use.command + " " + p2, UUID.randomUUID().toString());
                    if (p2) {
                        sanction = true;
                        timer.sendEmptyMessage(2);
                    } else {
                        sanction = false;
                    }
                }
            });
        allview.findViewById(R.id.tp_save).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    positiondata.add(new PositionData(
                                         ((TextView)allview.findViewById(R.id.tp_input_tag)).getText().toString(),
                                         ((TextView)allview.findViewById(R.id.tp_input_position)).getText().toString()
                                     ));
                    tplist.notifyDataSetChanged();
                }
            });
        allview.findViewById(R.id.tp_update_position).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String uuid=UUID.randomUUID().toString();
                    SendCommand(new UseFindResult("/tp " + "\"" + ChoosePlayer + "\"" + " " + "\"" + ChoosePlayer + "\"", new AfterFindResult(){
                                        @Override
                                        public void OnResult(JSONObject message) {
                                            final JSONObject position=message.optJSONObject("body").optJSONObject("destination");
                                            runOnUiThread(new Runnable(){
                                                    @Override
                                                    public void run() {
                                                        ((EditText)allview.findViewById(R.id.tp_input_position)).setText(new PositionData("",
                                                                                                                                          (float)position.optDouble("x"),
                                                                                                                                          (float)position.optDouble("y"),
                                                                                                                                          (float)position.optDouble("z")).position);
                                                    }
                                                });

                                        }
                                    }), uuid);
                }
            });




        fastBuildInit();
    }

    int BuildId=-1;
    private void whetherUseLine(int var1) {
        Integer[] var3 = new Integer[]{new Integer(R.id.build_use_direction), new Integer(R.id.build_use_line), new Integer(R.id.build_use_size), new Integer(R.id.build_use_rotate)};

        for (int var2 = 0; var2 < var3.length;var2++) {
            if (var2 != var1) {
                if (var1 == 3 && var2 == 1) {
                    this.allview.findViewById((Integer)var3[var2]).setVisibility(0);
                } else if (var1 == 2 && var2 == 0) {
                    this.allview.findViewById((Integer)var3[var2]).setVisibility(0);
                } else {
                    this.allview.findViewById((Integer)var3[var2]).setVisibility(8);
                }
            } else {
                this.allview.findViewById((Integer)var3[var2]).setVisibility(0);
            }
        }

        if (var1 == 3) {
            this.allview.findViewById(R.id.build_baseblock).setVisibility(8);
            this.allview.findViewById(R.id.build_baseradius).setVisibility(8);
            this.allview.findViewById(R.id.build_use_usual).setVisibility(8);
        } else if (var1 == 2) {
            this.allview.findViewById(R.id.build_baseblock).setVisibility(0);
            this.allview.findViewById(R.id.build_baseradius).setVisibility(8);
            this.allview.findViewById(R.id.build_use_usual).setVisibility(0);
        } else {
            this.allview.findViewById(R.id.build_baseblock).setVisibility(0);
            this.allview.findViewById(R.id.build_baseradius).setVisibility(0);
            this.allview.findViewById(R.id.build_use_usual).setVisibility(0);
        }

    }
    private void fastBuildInit() {
        allview.findViewById(R.id.build_baseblock_listen).setOnClickListener(new View.OnClickListener() {
                public boolean use=false;
                @Override
                public void onClick(View view) {
                    if (!use) {
                        use = true;
                        SubscribeEvent("BlockPlaced");
                        Toast.makeText(getApplication(), "方块监听已开启", Toast.LENGTH_SHORT).show();
                    } else {
                        use = false;
                        UnSubscribeEvent("BlockPlaced");
                        Toast.makeText(getApplication(), "方块监听已关闭", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        final TextView typeShow=allview.findViewById(R.id.build_show);
        allview.findViewById(R.id.build_type_circle).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 0;
                    typeShow.setText("你选择了[ 圆 ]");
                    whetherUseLine(0);
                }
            });

        allview.findViewById(R.id.build_type_line).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 1;
                    typeShow.setText("你选择了[ 直线 ]");
                    whetherUseLine(1);
                }
            });
        allview.findViewById(R.id.build_type_cube_Empty).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 2;
                    typeShow.setText("你选择了[ 长方体(框架) ]");
                    whetherUseLine(2);
                }
            });
        allview.findViewById(R.id.build_type_rotate).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 3;
                    typeShow.setText("你选择了[ 建筑旋转 ]");
                    whetherUseLine(3);
                }
            });
        allview.findViewById(R.id.build_type_ball).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 4;
                    typeShow.setText("你选择了[ 球 ]");
                    whetherUseLine(0);
                }
            });
		allview.findViewById(R.id.build_type_pyramid).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BuildId = 5;
                    typeShow.setText("你选择了[ 四棱锥 ]");
                    whetherUseLine(2);
                }
            });
        allview.findViewById(R.id.build_point_load).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String uuid=UUID.randomUUID().toString();

                    SendCommand(new UseFindResult("/tp " + "\"" + ChoosePlayer + "\"" + " " + "\"" + ChoosePlayer + "\"", new AfterFindResult(){
                                        @Override
                                        public void OnResult(JSONObject message) {
                                            JSONObject position=message.optJSONObject("body").optJSONObject("destination");
                                            final PositionData data=new PositionData("",
                                                                                     (float)position.optDouble("x"),
                                                                                     (float)position.optDouble("y"),
                                                                                     (float)position.optDouble("z"));
                                            runOnUiThread(new Runnable(){
                                                    @Override
                                                    public void run() {
                                                        ((EditText)allview.findViewById(R.id.build_basepoint_x)).setText(data.pos[0].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basepoint_y)).setText(data.pos[1].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basepoint_z)).setText(data.pos[2].toString());
                                                    }
                                                });

                                        }
                                    }), uuid);
                }

            });
        allview.findViewById(R.id.build_pointdirection_load).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String uuid=UUID.randomUUID().toString();
                    SendCommand(new UseFindResult("/tp " + "\"" + ChoosePlayer + "\"" + " " + "\"" + ChoosePlayer + "\"", new AfterFindResult(){
                                        @Override
                                        public void OnResult(JSONObject message) {
                                            JSONObject position=message.optJSONObject("body").optJSONObject("destination");
                                            final PositionData data=new PositionData("",
                                                                                     (float)position.optDouble("x"),
                                                                                     (float)position.optDouble("y"),
                                                                                     (float)position.optDouble("z"));
                                            runOnUiThread(new Runnable(){
                                                    @Override
                                                    public void run() {
                                                        ((EditText)allview.findViewById(R.id.build_basedirection_x)).setText(data.pos[0].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basedirection_y)).setText(data.pos[1].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basedirection_z)).setText(data.pos[2].toString());
                                                    }
                                                });

                                        }
                                    }), uuid);

                }
            });
        allview.findViewById(R.id.build_pointcenter_load).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String uuid=UUID.randomUUID().toString();
                    SendCommand(new UseFindResult("/tp " + "\"" + ChoosePlayer + "\"" + " " + "\"" + ChoosePlayer + "\"", new AfterFindResult(){
                                        @Override
                                        public void OnResult(JSONObject message) {
                                            JSONObject position=message.optJSONObject("body").optJSONObject("destination");
                                            final PositionData data=new PositionData("",
                                                                                     (float)position.optDouble("x"),
                                                                                     (float)position.optDouble("y"),
                                                                                     (float)position.optDouble("z"));
                                            runOnUiThread(new Runnable(){
                                                    @Override
                                                    public void run() {
                                                        ((EditText)allview.findViewById(R.id.build_basecenter_x)).setText(data.pos[0].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basecenter_y)).setText(data.pos[1].toString());
                                                        ((EditText)allview.findViewById(R.id.build_basecenter_z)).setText(data.pos[2].toString());
                                                    }
                                                });

                                        }
                                    }), uuid);

                }
            });
        allview.findViewById(R.id.build_start).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (BuildId != -1) {
                        final Integer[] deviation=new Integer[]{1,1,1};
                        final Float[] position=new Float[]{0f,0f,0f};
                        final Float[] direction=new Float[]{0f,0f,0f};
                        final Float[] size=new Float[]{0f,0f,0f};
                        final Float[] center=new Float[]{0f,0f,0f};
                        if (!((Switch)allview.findViewById(R.id.build_basedirect_x)).isChecked()) deviation[0] = -1;
                        if (!((Switch)allview.findViewById(R.id.build_basedirect_y)).isChecked()) deviation[1] = -1;
                        if (!((Switch)allview.findViewById(R.id.build_basedirect_z)).isChecked()) deviation[2] = -1;

                        position[0] = parseFloat(((TextView)allview.findViewById(R.id.build_basepoint_x)).getText().toString());
                        position[1] = parseFloat(((TextView)allview.findViewById(R.id.build_basepoint_y)).getText().toString());
                        position[2] = parseFloat(((TextView)allview.findViewById(R.id.build_basepoint_z)).getText().toString());
                        direction[0] = parseFloat(((TextView)allview.findViewById(R.id.build_basedirection_x)).getText().toString());
                        direction[1] = parseFloat(((TextView)allview.findViewById(R.id.build_basedirection_y)).getText().toString());
                        direction[2] = parseFloat(((TextView)allview.findViewById(R.id.build_basedirection_z)).getText().toString());
                        size[0] = parseFloat(((TextView)allview.findViewById(R.id.build_basesize_x)).getText().toString());
                        size[1] = parseFloat(((TextView)allview.findViewById(R.id.build_basesize_y)).getText().toString());
                        size[2] = parseFloat(((TextView)allview.findViewById(R.id.build_basesize_z)).getText().toString());
                        center[0] = parseFloat(((TextView)allview.findViewById(R.id.build_basecenter_x)).getText().toString());
                        center[1] = parseFloat(((TextView)allview.findViewById(R.id.build_basecenter_y)).getText().toString());
                        center[2] = parseFloat(((TextView)allview.findViewById(R.id.build_basecenter_z)).getText().toString());

                        final String block=((EditText)allview.findViewById(R.id.build_baseblock)).getText().toString();
                        final float angle=parseFloat(((TextView)allview.findViewById(R.id.build_baseangle)).getText().toString());
                        final int radius=parseInt(((TextView)allview.findViewById(R.id.build_baseradius)).getText().toString());

                        new Thread(new Runnable(){
                                public void buildcircular(int y, int r) {
                                    ArrayList<Position> data=new ArrayList<>();

                                    float last=0;
                                    for (int index=0;index <= r;index++) {
                                        float present=pythagoreanCB2A(r, index);
                                        float use=present;
                                        data.add(new Position(index, y, use));
                                        while (use < last - 1) {
                                            use++;
                                            data.add(new Position(index, y, use));
                                        }
                                        last = present;
                                    }

                                    for (Position use:data) {
                                        SetBlock(use.pos[0] * deviation[0] + position[0],
                                                 use.pos[1] * deviation[1] + position[1],
                                                 use.pos[2] * deviation[2] + position[2], block);
                                    }
                                    for (Position use:data) {
                                        SetBlock(-use.pos[0] * deviation[0] + position[0],
                                                 use.pos[1] * deviation[1] + position[1],
                                                 use.pos[2] * deviation[2] + position[2], block);
                                    }
                                    for (Position use:data) {
                                        SetBlock(use.pos[0] * deviation[0] + position[0],
                                                 use.pos[1] * deviation[1] + position[1],
                                                 -use.pos[2] * deviation[2] + position[2], block);
                                    }
                                    for (Position use:data) {
                                        SetBlock(-use.pos[0] * deviation[0] + position[0],
                                                 use.pos[1] * deviation[1] + position[1],
                                                 -use.pos[2] * deviation[2] + position[2], block);
                                    }
                                }
                                @Override
                                public void run() {
                                    switch (BuildId) {
                                        case 0:
                                            buildcircular(0, radius);

                                            break;
                                        case 1:
                                            //SendCommand("/say 生成直线，方块"+block+",位置"+position.toString()+",方向"+direction.toString(),UUID.randomUUID().toString());
                                            Integer[] total=new Integer[]{direction[0].intValue() - position[0].intValue(),direction[1].intValue() - position[1].intValue(),direction[2].intValue() - position[2].intValue()};
                                            int max=Math.max(Math.max(Math.abs(total[0]), Math.abs(total[1])), Math.abs(total[2]));
                                            float xcx=total[0].floatValue() / max,ycy=total[1].floatValue() / max,
                                                zcz=total[2].floatValue() / max;
                                            //LogArray(total);
                                            //LogArray(direction);
                                            //LogArray(position);
                                            for (int index=0;index <= max;index++) {
                                                SetBlock(position[0] + Math.round(xcx * index), 
                                                         position[1] + Math.round(ycy * index),
                                                         position[2] + Math.round(zcz * index), block);
                                            }
                                            break;
                                        case 2:
											Fill(position[0], position[1], position[2], position[0] + size[0] * deviation[0], position[1], position[2], block);
											Fill(position[0], position[1], position[2], position[0], position[1] + size[1] * deviation[1], position[2], block);
											Fill(position[0] + size[0] * deviation[0], position[1], position[2], position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2], block);
											Fill(position[0], position[1] + size[1] * deviation[1], position[2], position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2], block);
											Fill(position[0], position[1], position[2] + size[2] * deviation[2], position[0] + size[0] * deviation[0], position[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0], position[1], position[2] + size[2] * deviation[2], position[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0] + size[0] * deviation[0], position[1], position[2] + size[2] * deviation[2], position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0], position[1] + size[1] * deviation[1], position[2], position[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0], position[1], position[2], position[0], position[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2], position[0] + size[0] * deviation[0], position[1] + size[1] * deviation[1], position[2] + size[2] * deviation[2], block);
											Fill(position[0] + size[0] * deviation[0], position[1], position[2], position[0] + size[0] * deviation[0], position[1], position[2] + size[2] * deviation[2], block);

                                            break;
                                        case 3:
                                            for (int index=0;index <= 2;index++) {
                                                if (position[index] > direction[index]) {
                                                    float r=position[index];
                                                    position[index] = direction[index];
                                                    direction[index] = r;
                                                }
                                            }
                                            for (float cx=position[0];cx <= direction[0];cx++) {
                                                for (float cy=position[1];cy <= direction[1];cy++) {
                                                    for (float cz=position[2];cz <= direction[2];cz++) {
                                                        float x=cx - center[0],y=cy - center[1],z=cz - center[2];
                                                        float r=pythagoreanAB2C(x, z);

                                                        float alf=(Arcsin(z / r, x) + angle);

                                                        int nx=(int)(cos(alf) * r);
                                                        int nz=(int)(sin(alf) * r);
                                                        Clone(cx, cy, cz, nx + center[0], y + center[1], nz + center[2]);
                                                    }
                                                }
                                            }

                                            break;
                                        case 4:
                                            ArrayList<Position> data=new ArrayList<>();

                                            float last=0;
                                            for (int index=0;index <= radius;index++) {
                                                float present=pythagoreanCB2A(radius, index);
                                                float use=present;
                                                data.add(new Position(0, use, index));
                                                while (use < last - 1) {
                                                    use++;
                                                    data.add(new Position(0, use, index));
                                                }
                                                last = present;
                                            }

                                            for (Position use:data) {
                                                try {
                                                    Thread.sleep(50);
                                                } catch (InterruptedException e) {}
                                                buildcircular(use.pos[1], use.pos[2]);
                                            }
                                            for (Position use:data) {
                                                try {
                                                    Thread.sleep(50);
                                                } catch (InterruptedException e) {}
                                                buildcircular(-use.pos[1], use.pos[2]);
                                            }
                                            break;
										case 5:
											float var1 = size[0] / 2 / size[1];
											float var2 = size[2] / 2 / size[1];

											for (int var8 = 0; var8 <= size[2]; ++var8) {
												Fill(position[0] + (deviation[0] * Math.round(var8 * var1)), (var8 * deviation[1]) + position[1], position[2] + (deviation[2] * Math.round(var8 * var2)), position[0] + (deviation[0] * Math.round((-var8) * var1 + size[0])), (var8 * deviation[1]) + position[1], position[2] + (deviation[2] * Math.round((-var8) * var2 + size[2])), block);
											}
											break;
                                    }
                                }

                            }).start();
                    } else {
                        Toast.makeText(getApplication(), "你还没有选择生成类型", Toast.LENGTH_SHORT).show();

                    }
                }
            });
    }
    public static void UnSubscribeEvent(WebSocket conn, String str) {
        Command.UnSubscribeEvent(conn, str);
    }
    public static void UnSubscribeEvent(String str) {
        Command.UnSubscribeEvent(str);
    }
    public static void SubscribeEvent(WebSocket conn, String str) {
        Command.SubscribeEvent(conn, str);
    }
    public static void SubscribeEvent(String str) {
        Command.SubscribeEvent(str);
    }
    public static void SendCommand(String str, String uuid) {
        Command.SendCommand(str, uuid);
    }
    public static void SendCommand(UseFindResult str, String uuid) {
        Command.SendCommand(str, uuid);
    }
    private class FloatingOnTouchListener implements View.OnTouchListener {

        private int x;

        private int y;

        @Override
        public boolean onTouch(View view, MotionEvent event) {

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x = ( int) event.getRawX();
                    y = ( int) event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    int nowX = ( int) event.getRawX();
                    int nowY = ( int) event.getRawY();
                    int movedX = nowX - x;
                    int movedY = nowY - y;
                    x = nowX;
                    y = nowY;

                    layoutParams.x = (SettingX += movedX);
                    layoutParams.y = (SettingY += movedY);
// 更新悬浮窗控件布局
                    windowManager.updateViewLayout(allview, layoutParams);
                    //allview.findViewById(R.id.logo).setLayoutParams(logo);
                    break;
                default:
                    break;
            }
            return false;

        }

    }
    public static class EnchantingData {
        String id="",name="";
        int value=0;
        int max=1;
        boolean use=false;
        public EnchantingData(String id, int value, int max, String name) {
            this.id = id;this.value = value;this.max = max;this.name = name;
        }
        public void add() {
            value = Math.min(value + 1, max);
        }
        public void remove() {
            value = Math.max(value - 1, 0);
        }
        public void run(String name) {
            if (use) {
                Command.SendCommand("/enchant \"" + name + "\" " + id + " " + value);
            }
        }
    }
	public static class UseFindResult extends Command.UseFindResult {
        public UseFindResult(String com, AfterFindResult afr) {
            super(com, afr);
        }
        public UseFindResult(String com) {
            super(com);
        }
    }
    public static abstract class AfterFindResult extends Command.AfterFindResult {

    }
    Handler run=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 999) {
                ((Runnable)msg.obj).run();
            }
        }
    };
    private void runOnUiThread(Runnable r) {
        Message msg=new Message();
        msg.what = 999;
        msg.obj = r;
        run.sendMessage(msg);
    }
    private float parseFloat(String str) {
        float s=0;
        try {
            s = Float.parseFloat(str);
        } catch (Exception e) {
            return 0;
        }
        return s;
    }
    private int parseInt(String str) {
        int s=0;
        try {
            s = Integer.parseInt(str);
        } catch (Exception e) {
            return 0;
        }
        return s;
    }
    public float sin(float n) {
        return (float)Math.sin(Math.toRadians(n));
    }
    public float Arcsin(float n) {
        return (float)Math.toDegrees(Math.asin(n));
    }
    public static float Arcsin(float n, float s) {
        if (n > 0 && s > 0) {
            return (float)Math.toDegrees(Math.asin(n));
        } else if (n > 0 && s < 0) {
            return -(float)Math.toDegrees(Math.asin(n)) + 180;
        } else if (n < 0 && s < 0) {
            return -(float)Math.toDegrees(Math.asin(n)) + 180;
        } else {
            return (float)Math.toDegrees(Math.asin(n)) + 360;
        }
    }
    public float cos(float n) {
        return (float)Math.cos(Math.toRadians(n));
    }
    public float Arccos(float n) {
        return (float)Math.toDegrees(Math.acos(n));
    }
	public void Clone(float x, float y, float z, float xx, float yy, float zz) {
        Command.Clone(x, y, z, xx, yy, zz);
    }
	public void SetBlock(float x, float y, float z, String useblock) {
        Command.SetBlock(x, y, z, useblock);
    }
	public void Fill(float x, float y, float z, float xx, float yy, float zz, String useblock) {
        Command.Fill(x, y, z, xx, yy, zz, useblock);
    }
	public void LogArray(Object[] arr) {
		LOG.print("输出", new ArrayList(Arrays.asList(arr)).toString());
	}
	public float pythagoreanCB2A(float c, float b) {
		return (float)Math.sqrt(c * c - b * b);
	}
	public float pythagoreanAB2C(float a, float b) {
		return (float)Math.sqrt(a * a + b * b);
	}
}
