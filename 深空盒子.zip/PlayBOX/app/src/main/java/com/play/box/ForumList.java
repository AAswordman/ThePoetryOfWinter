package com.play.box;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import bms.helper.android.ListViewHelper;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import chineseframe.文件;
import com.play.android.MyImageView;
import com.play.common.Config;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import android.widget.LinearLayout;
import bms.helper.lang.Booleanx;
import bms.helper.http.UrlStringFactory;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.android.v7.RecyclerAdapter.ViewHolder;
import android.view.LayoutInflater;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.view.GestureDetector;
import com.play.common.SlideFree;
import android.graphics.Rect;
import bms.helper.android.ScrollHelperRecycler;
import android.support.v4.widget.NestedScrollView;
import android.os.Build;
import com.play.common.LOG;
import bms.helper.http.PreloadingGet;
import android.support.v7.widget.CardView;
import android.graphics.Color;
import android.support.design.widget.CoordinatorLayout;
import com.play.box.activity.MostActivityUse;
import android.app.ActivityOptions;
import bms.helper.android.PairBuilder;


public class ForumList extends MostActivityUse {

	final JSONObject json=new JSONObject();
	ForumList act=this;
	final Booleanx nextload=new Booleanx(false);
	final Integer[] page=new Integer[]{1};
	RecyclerAdapter adp;
	int lastUpdate=0;
	LinearLayoutManager mLayoutManager;
	//private GestureDetector mDetector;
	private int lastY = 0;
	private int touchEventId = -9983761;
	private Handler handlerg = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			View scroller = (View) msg.obj;

			if (msg.what == touchEventId) {
				if (lastY == scroller.getScrollY()) {
					//停止了，此处你的操作业务
					for (int indexx=0;indexx < mLayoutManager.getChildCount();indexx++) {
						if (ScrollHelperRecycler.isInScreen(mLayoutManager, indexx)) {
							View v=mLayoutManager.findViewByPosition(indexx);
							((MyImageView)v.findViewById(R.id.icon)).setImageURL(json.optJSONArray("userimage").optString(indexx));

							JSONArray usearr=json.optJSONArray("msgpng").optJSONArray(indexx);
							try {
								if (usearr.length() != 0) {
									for (int index=0;index < usearr.length();index++) {
										MyImageView image = null;
										switch (index) {
											case 0:
												image = v.findViewById(R.id.pic1);
												break;
											case 1:
												image = v.findViewById(R.id.pic2);
												break;
											case 2:
												image = v.findViewById(R.id.pic3);
												break;
										}
										image.setImageURL(usearr.optString(index));
									}
								} else {
									//((View)v.findViewById(R.id.pic_layout)).setVisibility(8);
								}
							} catch (Exception e) {}

						}
					}


				} else {
					handlerg.sendMessageDelayed(handlerg.obtainMessage(touchEventId, scroller), 1);
					lastY = scroller.getScrollY();
				}
			}
		}
	};
	private Handler handle=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 0) {
				page[0] += 1;
				nextload.set(false);


				final RecyclerView recycler_view = findViewById(R.id.post_viewpager);

				recycler_view.setOnTouchListener(new View.OnTouchListener(){

						@Override
						public boolean onTouch(View view, MotionEvent event) {
							int action = event.getAction();
							if (action == MotionEvent.ACTION_DOWN) {
								//点击
							} else if (action == MotionEvent.ACTION_UP) {
								//松开  
							} else if (action == MotionEvent.ACTION_MOVE) {
								if (!nextload.x && isVisBottom(recycler_view)) {
									Intent in=getIntent();
									nextload.set(true);
									String url=in.getStringExtra("url");
									UrlStringFactory urlx=new UrlStringFactory(url);
									//url.substring(url.indexOf("forum-"),url.indexOf());
									if (url.indexOf("forum-") != -1) {
										String fid=urlx.Pattern("forum-", "-");
										LoadPost("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=" +
												 fid + "&page=" + page[0].intValue() + "&inajax=1"
												 + urlx.Pattern(fid + "-", ".html"));
                                        //Reload(page[0]+1);
									} else {
										LoadPost("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay&fid=" +
												 urlx.GetParameterInt("fid") + "&page=" + page[0].intValue() + "&inajax=1");
										//Reload(page[0]+1);
									}
									((View)findViewById(R.id.forumevtlistProgressBar1)).setVisibility(0);
								}
								//移动
							}
							return false;
						}
					});

				mLayoutManager = new LinearLayoutManager(act);
				recycler_view.setLayoutManager(mLayoutManager);
				recycler_view.setHasFixedSize(true);
				recycler_view.setAdapter(adp);
				//recycler_view.setNestedScrollingEnabled(false);
				lastUpdate = adp.getItemCount();
			    //((View)findViewById(R.id.loading)).setVisibility(8);
				//handlerg.sendMessageDelayed(handlerg.obtainMessage(touchEventId, findViewById(R.id.forumevtlistScrollView1)), 1);
                Reload(page[0]);
                Reload(page[0] + 1);
                ((View)findViewById(R.id.forumevtlistProgressBar1)).setVisibility(8);
			} else if (msg.what == 3) {
				page[0] += 1;
				nextload.set(false);
                Reload(page[0]);
				adp.notifyItemRangeChanged(lastUpdate - 1, adp.getItemCount() - lastUpdate + 1);
                //LOG.print("页数", lastUpdate + "");
				//adp.notifyItemRangeChanged(lastUpdate - 2, adp.getItemCount() - lastUpdate);
                //adp.notifyDataSetChanged();
				lastUpdate = adp.getItemCount();

				((View)findViewById(R.id.forumevtlistProgressBar1)).setVisibility(8);

				//int targetIndex=-1;
			}
		}


	};
    private void Reload(int pg) {
        String url=getIntent().getStringExtra("url");
        UrlStringFactory urlx=new UrlStringFactory(url);
        if (url.indexOf("forum-") != -1) {
            String fid=urlx.Pattern("forum-", "-");
            Preloading(Config.Forum.List + "&fid=" +
                       fid + "&page=" + pg + "&inajax=1"
                       + urlx.Pattern(fid + "-", ".html"));
        } else {
            Preloading(Config.Forum.List + "&fid=" +
                       urlx.GetParameterInt("fid") + "&page=" + pg + "&inajax=1");
        }
    }
	public static boolean isVisBottom(RecyclerView recyclerView) {  
		LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();  
		//屏幕中最后一个可见子项的position
		int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();  
		//当前屏幕所看到的子项个数
		int visibleItemCount = layoutManager.getChildCount();  
		//当前RecyclerView的所有子项个数
		int totalItemCount = layoutManager.getItemCount();  
		//RecyclerView的滑动状态
		int state = recyclerView.getScrollState();  
		if (visibleItemCount > 0 && lastVisibleItemPosition == totalItemCount - 1) {   
			return true; 
		} else {   
			return false;  
		}
	}

	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        setContentView(R.layout.forum_evt_list);
		ScrollHelperRecycler.init(act);
        PreloadingGet.reset();
		initJson();
		final View header=findViewById(R.id.forum_header);
		adp = new RecyclerAdapter(){
			@Override
			public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
				View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.forum_evt_item, viewGroup, false);
				return new RecyclerAdapter.ViewHolder(v);
			}
			@Override
			public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
				final View v=viewHolder.v;
				//((MyImageView)v.findViewById(R.id.icon)).setImageURL(json.optJSONArray("userimage").optString(position));
				((TextView)v.findViewById(R.id.title)).setText(json.optJSONArray("title").optString(position));
				((TextView)v.findViewById(R.id.name)).setText(json.optJSONArray("username").optString(position));
				((TextView)v.findViewById(R.id.desc)).setText(json.optJSONArray("body").optString(position));
				((TextView)v.findViewById(R.id.time)).setText(json.optJSONArray("time").optString(position));
                ((TextView)v.findViewById(R.id.watchNum)).setText(json.optJSONArray("viewNum").optString(position));
                CardView cd=v.findViewById(R.id.card);
                cd.setRadius(30);
                cd.setContentPadding(0, 0, 0, 0);
                cd.setCardElevation(10);
                cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));
				/*
				 JSONArray usearr=json.optJSONArray("msgpng").optJSONArray(position);
				 if (usearr.length() != 0) {
				 } else {
				 ((View)v.findViewById(R.id.pic_layout)).setVisibility(8);
				 }
				 */
				((MyImageView)v.findViewById(R.id.icon)).setImageURL(json.optJSONArray("userimage").optString(position));
				((MyImageView)v.findViewById(R.id.icon)).setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							Intent web=new Intent(act, URLHandleActivity.class);
							web.putExtra("name", "个人主页");
							web.putExtra("url", Config.MAIN_URL + "/" + json.optJSONArray("userhomepage").optString(position));
							startActivity(web);
						}
					});
				JSONArray usearr=json.optJSONArray("msgpng").optJSONArray(position);
				if (usearr.length() != 0) {
					for (int index=0;index < usearr.length();index++) {
						MyImageView image = null;
						switch (index) {
							case 0:
								image = v.findViewById(R.id.pic1);
								break;
							case 1:
								image = v.findViewById(R.id.pic2);
								break;
							case 2:
								image = v.findViewById(R.id.pic3);
								break;
						}
						image.setImageURL(usearr.optString(index));
					}
				} else {
					((View)v.findViewById(R.id.pic_layout)).setVisibility(8);
				}

				cd.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View view) {
							Intent x=new Intent(act, Post.class);
							final Intent in=getIntent();
							String fid="",inajax="1";
							String url=in.getStringExtra("url");
							UrlStringFactory urlx=new UrlStringFactory(url);
							if (url.indexOf("forum-") != -1) {
								fid = urlx.Pattern("forum-", "-");
							} else {
								fid = "" + urlx.GetParameterInt("fid");
							}
							x.putExtra("fid", fid);
							x.putExtra("inajax", inajax);
							x.putExtra("url", Config.MAIN_URL + "/" + json.optJSONArray("url").optString(position));
							startActivity(x,ActivityOptions.makeSceneTransitionAnimation(act,
                                                                                         PairBuilder.get(v.findViewById(R.id.card)),PairBuilder.get(v.findViewById(R.id.time)),PairBuilder.get(v.findViewById(R.id.icon)),
                                                                                         PairBuilder.get(v.findViewById(R.id.title)),PairBuilder.get(v.findViewById(R.id.name))
                            ).toBundle());
						}
					});
			}
			@Override
			public int getItemCount() {
				return json.optJSONArray("title").length();
			}
		};
		loadview();
	}

	private void initJson() {
		try {
			json.put("time", new JSONArray());
			json.put("body", new JSONArray());
			json.put("username", new JSONArray());
			json.put("userimage", new JSONArray());
			json.put("title", new JSONArray());
			json.put("msgpng", new JSONArray());
			json.put("url", new JSONArray());
			json.put("userhomepage", new JSONArray());
            json.put("viewNum", new JSONArray());
		} catch (JSONException e) {}
		//int height;
	}
	private void loadview() {
        CardView cd=findViewById(R.id.forumevtlistCardView1);
        cd.setRadius(70);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);



		((View)findViewById(R.id.post_write)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					final Intent in=getIntent();
					String fid="",inajax="1";
					Intent write=new Intent(act, WritePost.class);
					String url=in.getStringExtra("url");
					UrlStringFactory urlx=new UrlStringFactory(url);
					if (url.indexOf("forum-") != -1) {
						fid = urlx.Pattern("forum-", "-");
					} else {
						fid = "" + urlx.GetParameterInt("fid");
					}
					write.putExtra("fid", fid);
					write.putExtra("inajax", inajax);
					startActivityForResult(write, 111);
				}
			});
		final Intent in=getIntent();
		((TextView)findViewById(R.id.back)).setText("<< " + in.getStringExtra("name"));
        ((TextView)findViewById(R.id.text_name)).setText(in.getStringExtra("name"));
		//LoadPost(in.getStringExtra("url"));
		final CoordinatorLayout scrollView=findViewById(R.id.forumevtlistScrollView1);
        
        new SendMain(in.getStringExtra("url"), null, new SendMain.Function(){
                @Override
                public void OnReturn(String result) {
                    Document doc=Jsoup.parse(result.replace("<![CDATA[", "").replace("]]>", ""));
                    final String num=doc.getElementsByClass("top_left f_f").get(0).getElementsByTag("p").get(0).text();
                    runOnUiThread(new Runnable(){
                            @Override
                            public void run() {
                                ((TextView)findViewById(R.id.txt_post_num)).setText(num);
                            }
                        });
                    LoadPost(doc);
                }
                @Override
                public void MainThread(Message msg) {
                }
			}).getUseCookie();

	}
    private void LoadPost(Element doc) {
        //Document doc=Jsoup.parse(result.replace("<![CDATA[", "").replace("]]>", ""));
        for (Element top : doc.getElementsByClass("top_ico")) {
            for (Element png : top.getElementsByTag("img")) {
                ((MyImageView)findViewById(R.id.img_icon)).setImageURL(Config.MAIN_URL + "/" + png.attr("src"));
            }
        }
        for (Element post : doc.getElementsByClass("comiis_mmlist bg_f b_t b_b mt10 comiis_list_readimgs")) {
            String title="",time="",body="",username="",url="",userhomepage="";
            String[] more=new String[]{""};
            for (Element message : post.getElementsByClass("top_user")) {
                username = message.text();
                userhomepage = message.attr("href");
            }
            for (Element message : post.getElementsByClass("list_body")) {
                body = message.text();
            }
            for (Element message : post.getElementsByClass("mmlist_li_time b_b comiis_tm")) {
                time = message.text();
            }
            for (Element message : post.getElementsByClass("kmview f_d")) {
                more[0] = message.getElementsByTag("a").get(0).ownText();
            }
            for (Element messages : post.getElementsByClass("mmlist_li_box kmleft cl")) {
                for (Element message : messages.getElementsByTag("h2")) {
                    title = message.text();
                }
                for (Element message : messages.getElementsByTag("a")) {
                    url = message.attr("href");
                }
            }
            for (Element messages : post.getElementsByClass("mmlist_li_top cl")) {
                for (Element message : messages.getElementsByTag("img")) {
                    json.optJSONArray("userimage").put(message.attr("src"));
                    break;
                }
            }
            JSONArray pngs=new JSONArray();
            int max=0;
            for (Element msgpng : post.getElementsByClass("comiis_pyqlist_img")) {

                for (Element png : msgpng.getElementsByTag("img")) {
                    if (max >= 3) {
                        break;
                    }
                    max++;
                    pngs.put(Config.MAIN_URL + "/" + png.attr("comiis_loadimages"));
                }
            }
            for (Element msgpng : post.getElementsByClass("comiis_pyqlist_imgs")) {

                for (Element png : msgpng.getElementsByTag("img")) {
                    if (max >= 3) {
                        break;
                    }
                    max++;
                    pngs.put(Config.MAIN_URL + "/" + png.attr("comiis_loadimages"));
                }
            }
            json.optJSONArray("msgpng").put(pngs);
            json.optJSONArray("title").put(title);
            json.optJSONArray("time").put(time);
            json.optJSONArray("username").put(username);
            json.optJSONArray("body").put(body);
            json.optJSONArray("url").put(url);
            json.optJSONArray("userhomepage").put(userhomepage);
            json.optJSONArray("viewNum").put(more[0]);
        }
        if (page[0] == 1) {
            Message message=new Message();
            message.what = 0;
            handle.sendMessage(message);
        } else {
            Message message=new Message();
            message.what = 3;
            handle.sendMessage(message);
        }

	}
	private void LoadPost(String stringExtra) {
		new SendMain(stringExtra, null, new SendMain.Function(){
				@Override
				public void OnReturn(String result) {
                    Document doc=Jsoup.parse(result.replace("<![CDATA[", "").replace("]]>", ""));
                    LoadPost(doc);
                }
				@Override
				public void MainThread(Message msg) {
				}
			}).getUseCookie();
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO 自动生成的方法存根
		if (requestCode == 111 && resultCode == 2) {
			reStart();
		}
	};
	private void reStart() {
		if (Build.VERSION.SDK_INT >= 11) {
			recreate();   
		} else {
			Intent intent = getIntent();
			finish();
			startActivity(intent);
		}
	}
    private void Preloading(String url) {
        PreloadingGet.get(Config.Http.Client, Config.Http.Context, url, null, 15000);
    }
}
