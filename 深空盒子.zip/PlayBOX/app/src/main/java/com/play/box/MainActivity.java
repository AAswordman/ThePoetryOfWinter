package com.play.box;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import bms.helper.android.FaceUtil;
import bms.helper.android.ListViewHelper;
import bms.helper.android.TextureVideoViewOutlineProvider;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.app.CrashHandler;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import bms.helper.io.AssetsUtil;
import bms.helper.lang.Stringx;
import chineseframe.应用工具;
import chineseframe.文件;
import chineseframe.系统工具;
import com.play.android.MyImageView;
import com.play.android.html.HTMLLoading;
import com.play.box.core.CoreWSActivity;
import com.play.box.help.HelperActivity;
import com.play.box.upload.NewReleaseResource;
import com.play.common.Config;
import com.play.common.Global;
import com.play.common.SignInCommon;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import android.app.ActivityOptions;
import android.util.Pair;
import bms.helper.android.PairBuilder;
import bms.helper.android.ViewCenterUtils;
import com.play.common.ldb.Ldb;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
	private ViewPager viewPager;
	private ArrayList<View> pageview;
	CrashHandler crashHandler;
	final MainActivity act=this;
	RecyclerView FtypeView;
	final ArrayList<String> typetitle =new ArrayList<String>();
	final ArrayList<String> typedes =new ArrayList<String>();
	final ArrayList<String> typepng =new ArrayList<String>();
	final ArrayList<String> typeurl =new ArrayList<String>();
	final ArrayList<String>[] Headlines=new ArrayList[]{new ArrayList<String>(),new ArrayList<String>()};
	final Stringx formhash=new Stringx("");
	final Stringx cookietime=new Stringx("");
	RecyclerAdapter adp;
	private Handler handler = new Handler() {  
        @Override  
        public void handleMessage(Message msg) {  
            if (msg.what == 0) {
                if (!new File(Config.File.BASE + Config.File.USERDATA).exists()) {
                    findViewById(R.id.starting).setVisibility(8);
                }


                FtypeView.setHasFixedSize(true);

                FtypeView.setNestedScrollingEnabled(false);

                StaggeredGridLayoutManager layoutManager = 
                    new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
// 绑定布局管理器
                FtypeView.setLayoutManager(layoutManager);
                FtypeView.setAdapter(new RecyclerAdapter(){

                        @Override
                        public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.forum_type_list, viewGroup, false));
                        }

                        @Override
                        public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                            final View v=viewHolder.v;
                            final CardView cd=v.findViewById(R.id.forumtypelistCardView1);
                            cd.setRadius(30);
                            cd.setContentPadding(10, 10, 10, 10);
                            cd.setCardElevation(10);
                            cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));
                            ((MyImageView) v.findViewById(R.id.forumtypelistImageView1)).setImageURL(typepng.get(position));
                            ((TextView) v.findViewById(R.id.forumtypelistTextView1)).setText(typetitle.get(position));
                            ((TextView) v.findViewById(R.id.forumtypelistTextView2)).setText(typedes.get(position));
                            cd.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent=new Intent(act, ForumList.class);
                                        intent.putExtra("url", typeurl.get(position));
                                        intent.putExtra("name", typetitle.get(position));
                                        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(act,
                                                                                                           PairBuilder.get(cd),
                                                                                                           PairBuilder.get(v.findViewById(R.id.forumtypelistTextView1)),
                                                                                                           PairBuilder.get(v.findViewById(R.id.forumtypelistImageView1))
                                                                                                           ).toBundle());
                                    }
                                });
                        }

                        @Override
                        public int getItemCount() {
                            return typedes.size();
                        }
                    });


			} else if (msg.what == 2) {
				//Toast.makeText(getApplication(), msg.obj.toString(), Toast.LENGTH_SHORT).show();
				if (msg.obj.toString().indexOf("欢迎") != -1) {
					new SendMain(Config.Forum.TYPE, null, new SendMain.Function(){
							@Override
							public void OnReturn(String result) {
								Document doc=Jsoup.parse(result);
								//Elements typess=doc.body().getElementsByClass("b_b");
								//for (Element types : typess) {
								for (Element type : doc.body().getElementsByClass("b_b")) {
									Elements pngs=type.select("[src]");
									for (Element png: pngs) {
										typepng.add(Config.MAIN_URL + "/" + png.attr("src"));
										//((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("text",Config.MAIN_URI+ png.attr("src")));

										//Toast.makeText(getApplication(), Config.MAIN_URI+ png.attr("src"), Toast.LENGTH_SHORT).show();
										//typetitle.add(png.attr("alt"));
										//typedes.add(png.);
									}
									for (Element des : type.getElementsByClass("post_tit")) {
										typedes.add(des.text());
										typetitle.add(des.text());

										typeurl.add(Config.MAIN_URL + "/" + des.attr("href").
													replace("&amp;", "&").
													replace("mod=post&action=newthread&", "mod=forumdisplay&"));
									}

									//}
								}
								Message msg = new Message();  
								msg.what = 0;
								handler.sendMessage(msg);
							}
							@Override
							public void MainThread(Message msg) {
							}
						}).getUseCookie();
					new SendMain(Config.Http.Client, Config.Http.Context, Config.Sign.Message,
						null, new SendMain.Function(){

							@Override
							public void OnReturn(String result) {
								Document doc=Jsoup.parse(result);
								final String[] msg=new String[]{"名字","头像"};
								for (Element message: doc.getElementsByClass("myinfo_user")) {
									msg[0] = message.ownText();
								}
								for (Element message: doc.getElementsByClass("myinfo_imgv1 bg_e f_c")) {
									for (Element messagex:message.getElementsByTag("img")) {
										msg[1] = messagex.attr("src");
										//LOG.print("img", msg[1]);
                                        Global.uid = new UrlStringFactory(msg[1]).GetParameter("uid");
									}
								}
								final Object[][] function=new Object[][]{
									new Integer[]{
										R.drawable.ic_message_alert_outline,
										R.drawable.ic_foot_print,
										R.drawable.ic_account_circle,
										R.drawable.ic_currency_usd_circle_outline,
										R.drawable.ic_clipboard_check_outline
									},
									new String[]{
										"消息提醒","最近来访","我的资料",
										"我的积分","我的任务"
									},
									new String[]{
										"https://bbs.aurora-sky.top/home.php?mod=space&do=notice&mobile=2",
										"https://bbs.aurora-sky.top/home.php?mod=space&do=friend&view=visitor&mobile=2",
										"https://bbs.aurora-sky.top/home.php?mod=spacecp&mobile=2",
										"https://bbs.aurora-sky.top/home.php?mod=spacecp&ac=credit&mobile=2",
										"https://bbs.aurora-sky.top/home.php?mod=task&mobile=2"
									}
								};
								adp = new RecyclerAdapter(){
									@Override
									public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
										View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.person_function_item, viewGroup, false);
										return new RecyclerAdapter.ViewHolder(v);
									}
									@Override
									public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
										View v=viewHolder.v;
										((TextView)v.findViewById(R.id.personfunctionitemTextView1)).setText((String)function[1][position]);
										((ImageView)v.findViewById(R.id.personfunctionitemImageView1)).setImageResource(((Integer)function[0][position]).intValue());
										((View)v.findViewById(R.id.personfunctionitemRelativeLayout1)).setOnClickListener(new View.OnClickListener() {
												@Override
												public void onClick(View view) {
													Intent web=new Intent(act, URLHandleActivity.class);
													web.putExtra("name", (String)function[1][position]);
													web.putExtra("url", (String)function[2][position]);
													startActivity(web);
												}
											});
									}
									@Override
									public int getItemCount() {
										return function[0].length;
									}
								};
                                final Object[][] function2=new Object[][]{
                                    new Integer[]{
                                        R.drawable.ic_package_up,R.drawable.ic_help_circle_outline
                                    },
                                    new String[]{
                                        "发布资源","使用方法"
                                    },
                                    new Intent[]{
                                        new Intent(act, NewReleaseResource.class),new Intent(act, HelperActivity.class)
                                    }
                                };
                                final RecyclerAdapter adp2 = new RecyclerAdapter(){
                                    @Override
                                    public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                                        View v=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.person_function_item, viewGroup, false);
                                        return new RecyclerAdapter.ViewHolder(v);
                                    }
                                    @Override
                                    public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, final int position) {
                                        View v=viewHolder.v;
                                        ((TextView)v.findViewById(R.id.personfunctionitemTextView1)).setText((String)function2[1][position]);
                                        ((ImageView)v.findViewById(R.id.personfunctionitemImageView1)).setImageResource(((Integer)function2[0][position]).intValue());
                                        ((View)v.findViewById(R.id.personfunctionitemRelativeLayout1)).setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {       
                                                    startActivity((Intent)function2[2][position]);
                                                }
                                            });
                                    }
                                    @Override
                                    public int getItemCount() {
                                        return function2[0].length;
                                    }
								};
								act.runOnUiThread(new Runnable(){
										@Override
										public void run() {
											((MyImageView)pageview.get(2).findViewById(R.id.persontableImageView1)).setImageURL(msg[1]);
											round(pageview.get(2).findViewById(R.id.persontableImageView1));
											((TextView)findViewById(R.id.persontableTextView1)).setText(msg[0]);

											RecyclerView recycler_view = findViewById(R.id.persontableRecyclerView1);
											LinearLayoutManager mLayoutManager = new LinearLayoutManager(act);
											recycler_view.setLayoutManager(mLayoutManager);
											recycler_view.setHasFixedSize(true);
											recycler_view.setAdapter(adp);
											recycler_view.setNestedScrollingEnabled(false);

                                            recycler_view = findViewById(R.id.persontableRecyclerView2);
                                            mLayoutManager = new LinearLayoutManager(act);
                                            recycler_view.setLayoutManager(mLayoutManager);
                                            recycler_view.setHasFixedSize(true);
                                            recycler_view.setAdapter(adp2);
											recycler_view.setNestedScrollingEnabled(false);

                                            findViewById(R.id.starting).setVisibility(8);
										}
									});
							}

							@Override
							public void MainThread(Message msg) {
							}

						}).getUseCookie();
				}
			} else if (msg.what == 3) {
                if (!new File(Config.File.BASE + Config.File.USERDATA).exists()) {
                    findViewById(R.id.starting).setVisibility(8);
                }
                RecyclerView recycler_view =pageview.get(1). findViewById(R.id.restableMyListView1);

				recycler_view.setLayoutManager(new LinearLayoutManager(act, LinearLayoutManager.HORIZONTAL, false));

				recycler_view.setHasFixedSize(true);
                recycler_view.setAdapter(new RecyclerAdapter(){
                        @Override
                        public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
                            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.headlines_item, viewGroup, false));
                        }

                        @Override
                        public void onBindViewHolder(RecyclerAdapter.ViewHolder viewHolder, int position) {
                            View v=viewHolder.v;
                            CardView cd=v.findViewById(R.id.headlinesitemCardView1);
                            cd.setRadius(50);
                            cd.setContentPadding(0, 0, 0, 0);
                            cd.setCardElevation(15);
                            ((MyImageView)v.findViewById(R.id.headlinesitemMyImageView1)).setImageURL(Config.MAIN_URL + "/" + Headlines[1].get(position));
                            ((TextView)v.findViewById(R.id.headlinesitemTextView1)).setText(Headlines[0].get(position));

                        }

                        @Override
                        public int getItemCount() {
                            return Headlines[0].size();
                        }
                    });
				recycler_view.setNestedScrollingEnabled(false);
				;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		crashHandler = CrashHandler.getInstance();
		crashHandler.init(getApplicationContext());
		setContentView(R.layout.activity_main);

		//Config.Http.Context.setAttribute(ClientContext.COOKIE_STORE, Config.Http.Cookie);
		SendMain.SetDelay(Config.Http.Delay);
		MyImageView.delay = Config.Http.Delay;
		HTMLLoading.delay = Config.Http.Delay;
        /*try {
         Config.Http.Context.put("user-agent", "Mozilla/5.0 (Linux; Android 6.0; PLK-UL00) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36");
         } catch (JSONException e) {}
         */
        SendMain.UserAgent = "Mozilla/5.0 (Linux; Android 6.0; PLK-UL00) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Mobile Safari/537.36";
		//if(new File(Config.File.BASE + Config.File.USERDATA).
		LoadingView();
		SettingView();
		FtypeView = pageview.get(0).findViewById(R.id.fTYPEGrid);
		AddTouching();

		getSupportActionBar().hide();
		this.RemoveFile();


        new Thread(new Runnable(){
                @Override
                public void run() {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {}
                    runOnUiThread(new Runnable(){
                            @Override
                            public void run() {
                                findViewById(R.id.starting).setVisibility(8);
                            }
                        });
                }
            }).start();

	}

	private void RemoveFile() {
		new Thread(new Runnable(){
				@Override
				public void run() {
					(new 文件("/sdcard/playbox/" + "download")).删除文件夹();
					(new 文件("/sdcard/playbox/" + "png")).删除文件夹();
					(new 文件("/sdcard/playbox/" + "importdata")).删除文件夹();
				}
			}).start();
	}

	private void AddTouching() {

		findViewById(R.id.activitytoperson).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					viewPager.setCurrentItem(2);
				}
			});
		findViewById(R.id.lay_load_0).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					viewPager.setCurrentItem(1);

                    //制造bug
                    //SkinPreView.Start(act,"/storage/emulated/0/数据库/44掌握之神/世界边境/WBR/textures/wb/5_x/intentions_first2.png",
                    //"def");
                    new Thread(new Runnable(){

                            @Override
                            public void run() {
                                Ldb ldb=new Ldb(new File("/storage/emulated/0/games/com.mojang/minecraftWorlds/新世界[1_2_13]/db"));
                                //ldb.LOGALL();
                                ldb.LOGALL2();
                                ldb.close();
                                runOnUiThread(new Runnable(){
                                        @Override
                                        public void run() {
                                            Toast.makeText(getApplication(), "完毕", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                            }
                        }).start();
                    
                    
				}
			});

		findViewById(R.id.toforum).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					viewPager.setCurrentItem(0);

				}
			});
		pageview.get(2).findViewById(R.id.persontableCardView1).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
                    if (Global.uid.equals("")) {
                        startActivityForResult(new Intent(act, SignIn.class), 123, ActivityOptions.makeSceneTransitionAnimation(act,
                                                                                                                                PairBuilder.get(pageview.get(2).findViewById(R.id.persontableCardView1)),
                                                                                                                                PairBuilder.get(pageview.get(2).findViewById(R.id.persontableTextView1)),
                                                                                                                                PairBuilder.get(pageview.get(2).findViewById(R.id.persontableImageView1))
                                                                                                                                ).toBundle());
                    } else {
                        Intent in =new Intent(act, URLHandleActivity.class);
                        in.putExtra("url", new UrlStringFactory(Config.Person.Message).SetParameter("uid", Global.uid).toString());
                        startActivity(in);
                    }

				}

			});
        pageview.get(1).findViewById(R.id.restableLinearLayout2).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(act, CoreWSActivity.class));
                }
			});
        pageview.get(1).findViewById(R.id.restableLinearLayout1).setOutlineProvider(new TextureVideoViewOutlineProvider());
        pageview.get(1).findViewById(R.id.restableLinearLayout1).setClipToOutline(true);
        pageview.get(1).findViewById(R.id.restableLinearLayout2).setOutlineProvider(new TextureVideoViewOutlineProvider());
        pageview.get(1).findViewById(R.id.restableLinearLayout2).setClipToOutline(true);

	}

	private void SettingView() {
		GridView gridView=(GridView)pageview.get(1).findViewById(R.id.FunctionGrid);
		final int[] imageId=new int[]{R.drawable.ic_map,R.drawable.ic_wrench_outline,R.drawable.ic_account_tie_outline,
			R.drawable.ic_wrench,R.drawable.ic_texture,R.drawable.ic_map_legend};
		final String[] title=new String[]{"地图","Addon","皮肤",
			"MODPE","材质","地图种子"};
		final String[] url=new String[]{
            Config.Resources.Map,Config.Resources.Addon,Config.Resources.Skin,
            Config.Resources.Modpe,Config.Resources.Texture,Config.Resources.Seed
        };


		gridView.setAdapter(new ListViewHelper(this, new ListViewHelper.Adepter(){
									@Override
									public View getView(ListViewHelper adp, final int position, View convertView, ViewGroup parent) {
										final View v = adp.inflate(R.layout.function_grid_table, null);
										ImageView iv = (ImageView) v.findViewById(R.id.functionitemimage);
										TextView tv = (TextView) v.findViewById(R.id.functionitemtttt);
										iv.setImageResource(imageId[position]);
										tv.setText(title[position]);
										v.findViewById(R.id.functiongridtableLinearLayout1).setOnClickListener(new View.OnClickListener() {
												@Override
												public void onClick(View view) {
													Intent in=new Intent(act, NewResWatching.class);
													in.putExtra("url", url[position]);
                                                    int[] viewCenter = ViewCenterUtils.getViewCenter(view);
                                                    in.putExtra("x", viewCenter[0]);
                                                    in.putExtra("y", viewCenter[1]);
													act.startActivity(in);
												}
											});
										return v;
									}
									@Override
									public int getCount() {
										return title.length;
									}
								}));


        if (new File(Config.File.BASE + "report").exists()) {

            JSONObject json=new JSONObject();
            try {
                json.put("bug", new 文件(new 文件(Config.File.BASE + "report").获取内容()).获取内容());
            } catch (IOException e) {} catch (JSONException e) {}
            new SendMain(Config.Http.Client, Config.Http.Context, "https://www.aurora-sky.top/bugs/bug.php", json, new SendMain.Function(){
                    @Override
                    public void OnReturn(String result) {

                    }

                    @Override
                    public void MainThread(Message msg) {
                    }
                }).postUseCookie();
            new File(Config.File.BASE + "report").delete();
        }

        new SendMain(Config.UPDATE, null, new SendMain.Function(){
                @Override
                public void OnReturn(String result) {
                    String str=Jsoup.parse(result).getElementsByClass("note-content").get(0).text();
                    int code=应用工具.获取应用版本号(act, getPackageName());
                    try {
                        final JSONObject json=new JSONObject(str);
                        runOnUiThread(new Runnable(){
                                @Override
                                public void run() {
                                    new AlertDialog.Builder(act)
                                        .setTitle("公告")
                                        .setMessage(json.optString("gg"))
                                        .setNegativeButton("确定", null)
                                        .create().show();
								}
							});
                        //LOG.print("y",json.optString("expression"));
                        FaceUtil.init(act, AssetsUtil.getFromAssets(act, "id.json"), json.optString("expression"));
                        //FaceUtil.init(act, AssetsUtil.getFromAssets(act, "id.json"));
                        if (json.getInt("version") > code) {
                            runOnUiThread(new Runnable(){
                                    @Override
                                    public void run() {
                                        final AlertDialog dialog = new AlertDialog.Builder(act)
                                            .setTitle("有新版本")
                                            .setMessage(json.optString("describe"))
                                            .setPositiveButton("下载", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dia, int which) {


                                                }
                                            })
                                            .setNegativeButton("复制链接", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dia, int which) {

                                                }
                                            }).setCancelable(false)
                                            .create();
                                        dialog.setOnShowListener(new DialogInterface.OnShowListener(){
                                                @Override
                                                public void onShow(DialogInterface p1) {
                                                    dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                //获取剪贴板管理器：
                                                                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                                                // 创建普通字符型ClipData
                                                                ClipData mClipData = ClipData.newPlainText("Label", json.optString("url"));
                                                                // 将ClipData内容放到系统剪贴板里。
                                                                cm.setPrimaryClip(mClipData);
                                                                // (act, );
                                                            }
                                                        });
                                                    dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                系统工具.打开浏览器(act, json.optString("url"));
                                                            }
                                                        });
                                                }
                                            });
                                        dialog.show();
                                    }
                                });

                        }
                    } catch (JSONException e) {}
                }

                @Override
                public void MainThread(Message msg) {
                }
            }).getUseCookie();
		new SendMain(Config.Forum.Headlines, null, new SendMain.Function(){
				@Override
				public void OnReturn(String result) {
					Document doc=Jsoup.parse(result);
					for (Element msg : doc.getElementsByClass("wz_list comiis_list_readimgs")) {
                        Elements pngs=msg.getElementsByClass("comiis_noloadimage comiis_loadimages");
                        if (pngs.size() != 0) {
                            String message="",png="";
                            Headlines[0].add(msg.text());
                            Headlines[1].add(pngs.get(0).attr("comiis_loadimages"));
                        }
					}
                    for (Element msg : doc.getElementsByClass("wz_list comiis_list_readimgs cl")) {
                        Elements pngs=msg.getElementsByClass("comiis_noloadimage comiis_loadimages");
                        if (pngs.size() != 0) {
                            String message="",png="";
                            Headlines[0].add(msg.text());
                            Headlines[1].add(pngs.get(0).attr("comiis_loadimages"));
                        }
					}

					Message msg = new Message();  
					msg.what = 3;
					handler.sendMessage(msg);
				}

				@Override
				public void MainThread(Message msg) {
				}
			}).getUseCookie();
		if (new File(Config.File.BASE + Config.File.USERDATA).exists()) {
			try {
				SignInCommon.LoadMessage(new 文件(Config.File.BASE + Config.File.USERDATA).获取内容());
			} catch (IOException e) {}
			SignInCommon.SetFun(new SignInCommon.Function(){
					@Override
					public void OnReturn(String result) {
						Message msg=new Message();
						msg.what = 2;
						msg.obj = result;
						handler.sendMessage(msg);
					}
				});
			SignInCommon.Sign();
		}

	}
	private void round(View v) {
		v.setOutlineProvider(new TextureVideoViewOutlineProvider());
		v.setClipToOutline(true);
    }
	private void LoadingView() {



		LayoutInflater inflater =getLayoutInflater();
		findViewById(R.id.lay_load_0).setOutlineProvider(new TextureVideoViewOutlineProvider());
		findViewById(R.id.lay_load_0).setClipToOutline(true);
		findViewById(R.id.lay_load_1).setOutlineProvider(new TextureVideoViewOutlineProvider());
		findViewById(R.id.lay_load_1).setClipToOutline(true);
		viewPager = (ViewPager) findViewById(R.id.pagemain);
		pageview = new ArrayList<View>();
		View view0 = inflater.inflate(R.layout.forum_base, null);
		View view1 = inflater.inflate(R.layout.res_table, null);
		View view2 = inflater.inflate(R.layout.person_table, null);

        CardView cd=view1.findViewById(R.id.restableCardView1);
        cd.setRadius(70);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));

        cd = view2.findViewById(R.id.persontableCardView1);
        cd.setRadius(70);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));

        cd = view2.findViewById(R.id.persontableCardView2);
        cd.setRadius(40);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));

        cd = view2.findViewById(R.id.persontableCardView3);
        cd.setRadius(40);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        cd.setCardBackgroundColor(Color.parseColor("#FFF9F3E7"));


		pageview.add(view0);
		pageview.add(view1);
		pageview.add(view2);
		PagerAdapter mPagerAdapter = new PagerAdapter(){

			@Override
			//获取当前窗体界面数
			public int getCount() {
				// TODO Auto-generated method stub
				return pageview.size();
			}

			@Override
			//判断是否由对象生成界面
			public boolean isViewFromObject(View arg0, Object arg1) {
				// TODO Auto-generated method stub
				return arg0 == arg1;
			}
			//使从ViewGroup中移出当前View
			public void destroyItem(View arg0, int arg1, Object arg2) {
				((ViewPager) arg0).removeView(pageview.get(arg1));
			}

			//返回一个对象，这个对象表明了PagerAdapter适配器选择哪个对象放在当前的ViewPager中
			public Object instantiateItem(View arg0, int arg1) {
				((ViewPager)arg0).addView(pageview.get(arg1));
				return pageview.get(arg1);
			}
		};
		//绑定适配器
		viewPager.setAdapter(mPagerAdapter);
		viewPager.setCurrentItem(1);
		viewPager.addOnPageChangeListener(new MyOnPageChangeListener());
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123 && resultCode == 2) {
            Message nsg=new Message();
            nsg.what = 2;nsg.obj = data.getStringExtra("res");
            handler.handleMessage(nsg);
		}
    }

	public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {

		@Override
		public void onPageSelected(int arg0) {
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
		}

		@Override
		public void onPageScrollStateChanged(int arg0) {
		}
	}
}
