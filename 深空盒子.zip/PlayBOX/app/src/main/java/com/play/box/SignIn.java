package com.play.box;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import bms.helper.app.CrashHandler;
import chineseframe.文件;
import com.play.common.Config;
import com.play.common.SignInCommon;
import java.io.IOException;
import android.support.v7.widget.CardView;

public class SignIn extends AppCompatActivity {
	CrashHandler crashHandler;
	SignIn act=this;
	Handler handler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(msg.what==0){
				//Toast.makeText(getCon,"",Toast.LENGTH_SHORT).show();
				//Toast.makeText(getContext(),"网络连接失败",Toast.LENGTH_SHORT).show();
				Toast.makeText(getApplication(), (String)msg.obj, Toast.LENGTH_SHORT).show();
				if(((String)msg.obj).indexOf("欢迎")!=-1){
					try {
						new 文件(Config.File.BASE + Config.File.USERDATA).写入内容(SignInCommon.toStringx());
					} catch (IOException e) {}
                    Intent in=new Intent();
                    in.putExtra("res",(String)msg.obj);
                    setResult(2,in);
					finish();
				}
			}
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		crashHandler = CrashHandler.getInstance();
		crashHandler.init(getApplicationContext());
		setContentView(R.layout.sign_in);
		addtouch();
        getSupportActionBar().hide();
        CardView cd=findViewById(R.id.signinCardView1);
        cd.setRadius(40);
        cd.setContentPadding(0, 0, 0, 0);
        cd.setCardElevation(15);
        
	}

	private void addtouch() {
		((View)findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					finish();
				}
			});
        ((Button)findViewById(R.id.signinButton2)).setOnClickListener(new View.OnClickListener() {
                @Override
				public void onClick(View view) {
                    String x = "https://bbs.aurora-sky.top/member.php?mod=joinAurora&mobile=2";  // 网址
                    Uri webdress = Uri.parse(x);  // 解析网址
                    Intent intent = new Intent(Intent.ACTION_VIEW, webdress); // 创建绑定
                    startActivity(intent); 
                    
                    }
                    
            });
		((Button)findViewById(R.id.signinButton1)).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					String User=((EditText)act.findViewById(R.id.signinEditText1)).getText().toString();
					String Pass=((EditText)act.findViewById(R.id.signinEditText2)).getText().toString();
					SignInCommon.SetMessage(User,Pass);
					SignInCommon.SetFun(new SignInCommon.Function(){
							@Override
							public void OnReturn(String result) {
								Message msg=new Message();
								msg.what=0;
								msg.obj=result;
								handler.sendMessage(msg);
							}
					});
					SignInCommon.Sign();
				}
			});
	}
}
