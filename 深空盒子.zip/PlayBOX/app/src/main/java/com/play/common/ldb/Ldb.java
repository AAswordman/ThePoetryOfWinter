package com.play.common.ldb;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;

import com.play.common.LOG;
import com.litl.leveldb.DB;
import com.litl.leveldb.Iterator;

public class Ldb {
    private DB db;
    private static final Charset CHARSET = Charset.forName("UTF-8");
    
    private DB.Snapshot snapshot;
    public Ldb(File f){
        db=new DB(f);
        db.open();
        upDateSnapshot();
    }
    public byte[] get(String key){
        return db.get(key.getBytes(CHARSET));
    }
    public byte[] get(byte[] key){
        return db.get(key);
    }
    public void LOGALL(){
        Iterator it = db.iterator(snapshot);
        for (it.seekToFirst();it.isValid();it.next()) {
            String key = byteArrToHex(it.getKey());
            String value = new String(it.getValue(),CHARSET);
            LOG.print("ldb","key: " +key+ " value: " + value);
        }
    }
    public void LOGALL2(){
        Iterator it = db.iterator(snapshot);
        for (it.seekToFirst();it.isValid();it.next()) {
            String key = byteArrToHex(it.getKey());
            String value = byteArrToHex(it.getValue());
            LOG.print("ldb","key: " +key+ " value: " + value);
            key = byteArrToHex(it.getKey());
            value = new String(it.getValue(),CHARSET);
            LOG.print("ldb","key: " +key+ " value: " + value);
            /*
            while(true){
                it.next();
                if(Math.random()<0.03||!it.isValid()){
                    break;
                }
            }
            */
        }
    }
    public void upDateSnapshot(){
        snapshot = db.getSnapshot();
    }
    public void close(){
        db.close();
    }
    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();

    public static String byteArrToHex(byte... bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
    
    
}
