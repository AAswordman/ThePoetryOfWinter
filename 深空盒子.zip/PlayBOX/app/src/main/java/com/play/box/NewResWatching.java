//
// Decompiled by FernFlower - 1818ms
//
package com.play.box;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import bms.helper.android.ViewCenterUtils;
import bms.helper.android.v7.RecyclerAdapter;
import bms.helper.http.PreloadingGet;
import bms.helper.http.SendMain;
import bms.helper.http.UrlStringFactory;
import bms.helper.lang.Booleanx;
import bms.helper.lang.Stringx;
import com.play.android.MyImageView;
import com.play.box.activity.MostActivityUse;
import com.play.common.Config;
import com.play.common.Config.Http;
import java.util.Collection;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import android.app.ActivityOptions;
import bms.helper.android.PairBuilder;

public class NewResWatching extends MostActivityUse {
    NewResWatching act = this;
    RecyclerAdapter adp;
    JSONObject json = new JSONObject();
    final Booleanx nextload = new Booleanx(false);
    Integer[] page = new Integer[]{new Integer(1),1};
    int lastUpdate=0;
    final Booleanx isSearching=new Booleanx(false);

    private void InitView() {
        (new SendMain(Http.Client, Http.Context, this.getIntent().getStringExtra("url"), (JSONObject)null, new SendMain.Function(){
                @Override
                public void OnReturn(String result) {
                }

                @Override
                public void MainThread(Message msg) {
                }
            })).getUseCookie();
    }

    private void LoadPost(String var1) {
        (new SendMain(var1, (JSONObject)null, new SendMain.Function(){

                @Override
                public void OnReturn(String result) {
                    ProcessPost(result);
                }

                @Override
                public void MainThread(Message msg) {
                }
            })).getUseCookie();
    }
    private void LoadPost2(String var1) {
        (new SendMain(var1, (JSONObject)null, new SendMain.Function(){

                @Override
                public void OnReturn(String result) {
                    ProcessPost2(result);
                }

                @Override
                public void MainThread(Message msg) {
                }
            })).getUseCookie();
    }

    private void Preloading(String var1) {
        PreloadingGet.get(Http.Client, Http.Context, var1, (JSONObject)null, 15000);
    }

    private void ProcessPost(String var1) {
        Iterator var8 = ((Collection)Jsoup.parse(var1.replace("<![CDATA[", "").replace("]]>", "")).getElementsByClass("comiis_mmlist bg_f b_t b_b mt10 comiis_list_readimgs")).iterator();

        label106:
        while (var8.hasNext()) {
            Element var9 = (Element)var8.next();
            String var5 = "";
            String var6 = "";
            String var7 = "";
            Iterator var12 = ((Collection)var9.getElementsByClass("top_user")).iterator();

            Element var4;
            while (var12.hasNext()) {
                var4 = (Element)var12.next();
                var4.text();
                var4.attr("href");
            }

            for (var12 = ((Collection)var9.getElementsByClass("list_body")).iterator(); var12.hasNext(); var6 = ((Element)var12.next()).text()) {
            }

            var12 = ((Collection)var9.getElementsByClass("mmlist_li_time b_b comiis_tm")).iterator();

            while (var12.hasNext()) {
                ((Element)var12.next()).text();
            }

            Iterator var14 = ((Collection)var9.getElementsByClass("mmlist_li_box kmleft cl")).iterator();

            Iterator var11;
            Iterator var18;
            while (var14.hasNext()) {
                Element var10 = (Element)var14.next();
                var11 = ((Collection)var10.getElementsByTag("h2")).iterator();

                for (var1 = var5; var11.hasNext(); var1 = ((Element)var11.next()).text()) {
                }

                var18 = ((Collection)var10.getElementsByTag("a")).iterator();

                while (true) {
                    var5 = var1;
                    if (!var18.hasNext()) {
                        break;
                    }

                    var7 = ((Element)var18.next()).attr("href");
                }
            }

            var1 = "";
            int var2 = 0;
            var18 = ((Collection)var9.getElementsByClass("comiis_pyqlist_img")).iterator();

            while (true) {
                int var3;
                String var15;
                while (var18.hasNext()) {
                    var11 = ((Collection)((Element)var18.next()).getElementsByTag("img")).iterator();
                    var3 = var2;
                    var15 = var1;

                    while (true) {
                        var1 = var15;
                        var2 = var3;
                        if (!var11.hasNext()) {
                            break;
                        }

                        Element var13 = (Element)var11.next();
                        if (var3 >= 1) {
                            var1 = var15;
                            var2 = var3;
                            break;
                        }

                        ++var3;
                        var15 = "https://bbs.aurora-sky.top" + "/" + var13.attr("comiis_loadimages");
                    }
                }

                Iterator var17 = ((Collection)var9.getElementsByClass("comiis_pyqlist_imgs")).iterator();
                var3 = var2;
                var15 = var1;

                while (true) {
                    while (var17.hasNext()) {
                        var18 = ((Collection)((Element)var17.next()).getElementsByTag("img")).iterator();
                        var2 = var3;
                        var1 = var15;

                        while (true) {
                            var15 = var1;
                            var3 = var2;
                            if (!var18.hasNext()) {
                                break;
                            }

                            var4 = (Element)var18.next();
                            if (var2 >= 1) {
                                var15 = var1;
                                var3 = var2;
                                break;
                            }

                            ++var2;
                            var1 = "https://bbs.aurora-sky.top" + "/" + var4.attr("comiis_loadimages");
                        }
                    }

                    var6 = var9.getElementsByClass("kmview f_d").get(0).getElementsByTag("a").get(0).ownText();

                    this.json.optJSONArray("image").put(var15);
                    String[] var16 = var5.split("\\$");
                    this.json.optJSONArray("type").put(var16[1]);
                    this.json.optJSONArray("title").put(var16[0]);
                    this.json.optJSONArray("des").put(var6);
                    this.json.optJSONArray("url").put(var7);
                    continue label106;
                }
            }
        }

        this.nextload.x = false;
        this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if (page[0] == 1) {
                        final RecyclerView recyclerView = (RecyclerView)findViewById(R.id.act_watching_res_recyclerView);
                        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)act));
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setAdapter(adp);
                        //((SimpleItemAnimator)recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
                        closeRecyclerViewAnim((RecyclerView)findViewById(R.id.act_watching_res_recyclerView));
                        lastUpdate = adp.getItemCount();
                        page[0] = new Integer(page[0] + 1);
                        Reload(page[0] + 1);
                    } else {
                        adp.notifyItemRangeChanged(lastUpdate - 1, adp.getItemCount() - lastUpdate + 1);
                        lastUpdate = adp.getItemCount();
                        final Integer[] page2 = page;
                        page2[0] = new Integer(page2[0] + 1);
                        Reload(page[0] + 1);
                    }
                }
            });
    }

    private void closeRecyclerViewAnim(RecyclerView rc){
        rc.getItemAnimator().setAddDuration(0);
        rc.getItemAnimator().setChangeDuration(0);
        rc.getItemAnimator().setMoveDuration(0);
        rc.getItemAnimator().setRemoveDuration(0);
        ((SimpleItemAnimator)rc.getItemAnimator()).setSupportsChangeAnimations(false);
    }
    
    
    private void ProcessPost2(String var1) {
        Iterator var8 = ((Collection)Jsoup.parse(var1.replace("<![CDATA[", "").replace("]]>", "")).getElementsByClass("forumlist_li comiis_znalist bg_f b_t b_b comiis_list_readimgs")).iterator();

        label108:
        while (var8.hasNext()) {
            Element var9 = (Element)var8.next();
            String var5 = "";
            String var6 = "";
            String var7 = "";
            Iterator var4 = ((Collection)var9.getElementsByClass("top_user")).iterator();

            Element var12;
            while (var4.hasNext()) {
                var12 = (Element)var4.next();
                var12.text();
                var12.attr("href");
            }

            Iterator var13;
            for (var13 = ((Collection)var9.getElementsByClass("list_body cl")).iterator(); var13.hasNext(); var6 = ((Element)var13.next()).text()) {
            }

            var13 = ((Collection)var9.getElementsByClass("forumlist_li_time")).iterator();

            while (var13.hasNext()) {
                ((Element)var13.next()).text();
            }

            var4 = ((Collection)var9.getElementsByClass("mmlist_li_box cl")).iterator();

            Iterator var11;
            Iterator var18;
            while (var4.hasNext()) {
                Element var10 = (Element)var4.next();
                var11 = ((Collection)var10.getElementsByTag("h2")).iterator();

                for (var1 = var5; var11.hasNext(); var1 = ((Element)var11.next()).text()) {
                }

                var18 = ((Collection)var10.getElementsByTag("a")).iterator();

                while (true) {
                    var5 = var1;
                    if (!var18.hasNext()) {
                        break;
                    }

                    var7 = ((Element)var18.next()).attr("href");
                }
            }

            var1 = "";
            int var2 = 0;
            var18 = ((Collection)var9.getElementsByClass("comiis_pyqlist_img")).iterator();

            while (true) {
                int var3;
                String var14;
                while (var18.hasNext()) {
                    var11 = ((Collection)((Element)var18.next()).getElementsByTag("img")).iterator();
                    var3 = var2;
                    var14 = var1;

                    while (true) {
                        var1 = var14;
                        var2 = var3;
                        if (!var11.hasNext()) {
                            break;
                        }

                        var12 = (Element)var11.next();
                        if (var3 >= 1) {
                            var1 = var14;
                            var2 = var3;
                            break;
                        }

                        ++var3;
                        var14 = "https://bbs.aurora-sky.top" + "/" + var12.attr("comiis_loadimages");
                    }
                }

                Iterator var17 = ((Collection)var9.getElementsByClass("comiis_pyqlist_imgs")).iterator();
                var3 = var2;
                var14 = var1;

                while (true) {
                    while (var17.hasNext()) {
                        var18 = ((Collection)((Element)var17.next()).getElementsByTag("img")).iterator();
                        var2 = var3;
                        var1 = var14;

                        while (true) {
                            var14 = var1;
                            var3 = var2;
                            if (!var18.hasNext()) {
                                break;
                            }

                            Element var16 = (Element)var18.next();
                            if (var2 >= 1) {
                                var14 = var1;
                                var3 = var2;
                                break;
                            }

                            ++var2;
                            var1 = Config.MAIN_URL + "/" + var16.attr("comiis_loadimages");
                        }
                    }

                    //LOG.print("测试", var5);

                    String str=var9.getElementsByClass("comiis_znalist_bottom b_t cl").get(0).text();
                    Pattern r = Pattern.compile("([0-9]*)阅读");
                    Matcher m = r.matcher(str);
                    if (m.find()) {
                        var6 = m.group(1);
                    }
                    //LOG.print("匹配",str);
                    if (var5.indexOf("$") != -1) {
                        this.json.optJSONArray("image").put(var14);
                        //LOG.print("测试2", var5);
                        String[] var15 = var5.split("\\$");
                        this.json.optJSONArray("type").put(var15[1]);
                        this.json.optJSONArray("title").put(var15[0]);
                        this.json.optJSONArray("des").put(var6);
                        this.json.optJSONArray("url").put(var7);
                    }
                    continue label108;
                }
            }
        }

        this.nextload.x = false;
        this.runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    if (page[1] == 1) {
                        final RecyclerView recyclerView = (RecyclerView)findViewById(R.id.act_watching_res_recyclerView);
                        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)act));
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setAdapter(adp);
                        closeRecyclerViewAnim((RecyclerView)findViewById(R.id.act_watching_res_recyclerView));
                        page[1] = new Integer(page[1] + 1);
                        Reload(page[1] + 1);
                        lastUpdate = adp.getItemCount();
                    } else {
                        adp.notifyItemRangeChanged(lastUpdate - 1, adp.getItemCount() - lastUpdate + 1);
                        lastUpdate = adp.getItemCount();
                        final Integer[] page2 = page;
                        page2[1] = new Integer(page2[1] + 1);
                        Reload(page[1] + 1);
                    }
                }
            });
    }

    private void Reload(int var1) {
        if (!isSearching.x) {
            String var3 = this.getIntent().getStringExtra("url");
            UrlStringFactory var2 = new UrlStringFactory(var3);
            if (var3.indexOf("forum-") != -1) {
                var3 = var2.Pattern("forum-", "-");
                this.Preloading("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay" + "&fid=" + var3 + "&page=" + var1 + "&inajax=1" + var2.Pattern(var3 + "-", ".html"));
            } else {
                this.Preloading("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay" + "&fid=" + var2.GetParameterInt("fid") + "&page=" + var1 + "&inajax=1");
            }
        } else {
            this.Preloading(new UrlStringFactory(Config.Forum.SearchPage).SetParameter("page", page[1] + "").toString());
        }
    }

    private void initJson() {
        try {
            this.json.put("url", (Object)new JSONArray());
            this.json.put("type", (Object)new JSONArray());
            this.json.put("des", (Object)new JSONArray());
            this.json.put("title", (Object)new JSONArray());
            this.json.put("image", (Object)new JSONArray());
        } catch (JSONException ex) {}
    }
    @Override
    protected void onCreate(Bundle var1) {
        super.onCreate(var1);
        this.setContentView(R.layout.act_watching_res_list);
        this.setActionBarLayout(R.layout.ActionBarSearch);
        
        LinearLayout ll=findViewById(R.id.act_watching_res_listLinearLayout);
        ViewCenterUtils.setActivityStartAnim(this, ll, getIntent());
        closeRecyclerViewAnim((RecyclerView)findViewById(R.id.act_watching_res_recyclerView));
        super.actionBarview.findViewById(R.id.back).setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1) {
                    finish();
                }
            });
        this.SetTitleFree("资源");
        this.initJson();
        this.adp = new RecyclerAdapter(){
            @Override
            public int getItemCount() {
                return json.optJSONArray("title").length();
            }

            @Override
            public void onBindViewHolder(final RecyclerAdapter.ViewHolder recyclerAdapter$ViewHolder, final int n) {
                final View v = recyclerAdapter$ViewHolder.v;
                
                if (json.optJSONArray("type").optString(n).indexOf("*活动") != -1) {
                    ((TextView)v.findViewById(R.id.type)).setTextColor(Color.parseColor("#FF0000"));
                    ((TextView)v.findViewById(R.id.type)).setText((CharSequence)json.optJSONArray("type").optString(n).replaceFirst("\\*",""));
                }else{
                    ((TextView)v.findViewById(R.id.type)).setText((CharSequence)json.optJSONArray("type").optString(n));
                }
                ((TextView)v.findViewById(R.id.title)).setText((CharSequence)json.optJSONArray("title").optString(n));
                ((TextView)v.findViewById(R.id.des)).setText((CharSequence)json.optJSONArray("des").optString(n) + "℃");
                ((MyImageView)v.findViewById(R.id.image)).setImageURL(json.optJSONArray("image").optString(n));
                final CardView cardView = (CardView)v.findViewById(R.id.act_watching_res_itardView);
                final Animation loadAnimation = AnimationUtils.loadAnimation((Context)act, R.anim.item_anim_during);
                loadAnimation.setFillAfter(true);
                cardView.startAnimation(loadAnimation);
                cardView.setRadius((float)30);
                cardView.setContentPadding(10, 10, 10, 10);
                cardView.setCardElevation((float)2);
                v.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View p1) {
                            Intent in =new Intent(act, NewResDownload.class);
                            in.putExtra("url", new StringBuffer().append(new StringBuffer().append("https://bbs.aurora-sky.top").append("/").toString()).append(json.optJSONArray("url").optString(n)).toString());
                            startActivity(in,ActivityOptions.makeSceneTransitionAnimation(act,
                                                                                          PairBuilder.get(v.findViewById(R.id.act_watching_res_itardView)),
                                                                                          PairBuilder.get(v.findViewById(R.id.title)),
                                                                                          PairBuilder.get(v.findViewById(R.id.image))
                                                                                          ).toBundle());
                        }
                    });
            }

            @Override
            public RecyclerAdapter.ViewHolder onCreateViewHolder(final ViewGroup viewGroup, final int n) {
                return new RecyclerAdapter.ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.act_watching_res_item, viewGroup, false));
            }
        };
        super.actionBarview.findViewById(R.id.ActionBarSearchEditText1).setVisibility(8);
        super.actionBarview.findViewById(R.id.ActionBarSearchImageView1).setOnClickListener(new View.OnClickListener(){
                int Model=0;
                @Override
                public void onClick(View p1) {
                    if (this.Model == 0) {
                        ++this.Model;
                        findViewById(R.id.ActionBarSearchEditText1).setVisibility(0);
                        SetTitleFree("");
                    } else if (this.Model == 1) {
                        this.Model = 0;
                        findViewById(R.id.ActionBarSearchEditText1).setVisibility(8);
                        SetTitleFree("资源");
                        new SendMain(Config.Http.Client, Config.Http.Context, Config.Forum.Search_Cookie, (JSONObject)null, new SendMain.Function(){
                                @Override
                                public void OnReturn(String s) {
                                    Stringx var3 = new Stringx("");
                                    Iterator var7 = ((Collection)Jsoup.parse(s).select("[name=formhash]")).iterator();

                                    while (var7.hasNext()) {
                                        var3.set(((Element)var7.next()).attr("value"));
                                    }

                                    try {

                                        new SendMain(Http.Client, Http.Context, Config.Forum.Search, 
                                            new JSONObject()
                                            .put("formhash", var3.x)
                                            .put("srchtxt", ((EditText)findViewById(R.id.ActionBarSearchEditText1)).getText().toString())
                                            .put("searchsubmit", "yes"), new SendMain.Function(){

                                                @Override
                                                public void OnReturn(String resul) {
                                                    initJson();
                                                    page[0] = 1;
                                                    page[1] = 1;
                                                    isSearching.set(true);
                                                    ProcessPost2(resul);
                                                }

                                                @Override
                                                public void MainThread(Message msg) {
                                                }
                                            }).postUseCookie();

                                    } catch (JSONException ex) {}
                                }



                                @Override
                                public void MainThread(Message msg) {
                                }
                            }).getUseCookie();
                    }
                }
            });
        this.LoadPost(this.getIntent().getStringExtra("url"));
        this.findViewById(R.id.act_watching_res_recyclerView).setOnTouchListener(new View.OnTouchListener(){

                @Override
                public boolean onTouch(View var1, MotionEvent var2) {
                    int var3 = var2.getAction();
                    if (var3 != 0 && var3 != 1 && var3 == 2 && ForumList.isVisBottom((RecyclerView)findViewById(R.id.act_watching_res_recyclerView)) && !nextload.x) {


                        nextload.set(true);
                        if (!isSearching.x) {
                            String var5 =getIntent().getStringExtra("url");
                            UrlStringFactory var4 = new UrlStringFactory(var5);
                            if (var5.indexOf("forum-") != -1) {
                                var5 = var4.Pattern("forum-", "-");
                                LoadPost("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay" + "&fid=" + var5 + "&page=" + page[0] + "&inajax=1" + var4.Pattern(var5 + "-", ".html"));
                            } else {
                                LoadPost("https://bbs.aurora-sky.top/forum.php?mod=forumdisplay" + "&fid=" + var4.GetParameterInt("fid") + "&page=" + page[0] + "&inajax=1");
                            }
                        } else {
                            LoadPost2(new UrlStringFactory(Config.Forum.SearchPage).SetParameter("page", page[1] + "").toString());
                        }
                    }
                    return false;
                }
            });
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu var1) {
        return super.onPrepareOptionsMenu(var1);
    }
}


