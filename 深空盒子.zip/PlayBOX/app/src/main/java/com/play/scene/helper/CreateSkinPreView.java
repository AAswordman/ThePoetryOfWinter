package com.play.scene.helper;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import bms.helper.encryption.Base64Helper;
import bms.helper.io.AssetsUtil;
import chineseframe.文件;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import com.play.scene.SkinPreView;
import com.play.common.LOG;

public class CreateSkinPreView {
    final static String Basepath="scene/";
    private static void initWebView(WebView webView) {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setLoadWithOverviewMode(true);
    }
    private static void LoadRes(WebView webView, String model, Bitmap bg, Bitmap sk) {
        JSONObject skin=new JSONObject();
        try {
            skin.put("path", "data:image/png;base64," + Base64Helper.getDiskBitmap2Base64(
                         Bitmap.createScaledBitmap(sk, sk.getWidth() * 4, sk.getHeight() * 4, false)));
            skin.put("data", new JSONObject(model));
        } catch (JSONException e) {}
        webView.loadUrl("javascript:(function(){ loadGeo(" + skin + ");})()");
        JSONObject background=new JSONObject();
        try {
            background.put("path", "data:image/png;base64," + Base64Helper.getDiskBitmap2Base64(
                               Bitmap.createScaledBitmap(bg, bg.getWidth() * 2, bg.getHeight() * 2, false)));
        } catch (JSONException e) {}
        webView.loadUrl("javascript:(function(){ loadBackground(" + background + ");})()");
        //LOG.print("执行","javascript:(function(){ loadGeo("+skin+");})()");
        webView.loadUrl("javascript:(function(){ updateCarema();})()");
    }
    public static void create(final Activity act, final WebView webView, final String modelp, final String skinp) {
        new Thread(new Runnable(){
                @Override
                public void run() {
                    act.runOnUiThread(new Runnable(){
                            @Override
                            public void run() {
                                initWebView(webView);
                                webView.setWebViewClient(new WebViewClient() {
                                        @Override
                                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                            return false;
                                        }
                                        @Override
                                        public void onPageFinished(WebView view, String url) {

                                            String model="";
                                            if (modelp.equals("def")) {
                                                model = AssetsUtil.getFromAssets(act, Basepath + "geo/g.json");
                                            } else if (modelp.equals("defx")) {
                                                model = AssetsUtil.getFromAssets(act, Basepath + "geo/gx.json");
                                            } else {
                                                try {
                                                    model = new 文件(modelp).获取内容();
                                                } catch (IOException e) {}
                                            }
                                            Bitmap bg=AssetsUtil.getImageFromAssetsFile(act, Basepath + "texture/grass.png");
                                            Bitmap sk=BitmapFactory.decodeFile(skinp);

                                            LoadRes(webView, model, bg, sk);
                                            
                                        }

                                    });
                                // 格式规定为:file:////android_asset/文件名.html
                                webView.loadUrl("file:android_asset/scene/index.html");
                                //webView.setWebViewClient(new WebChromeClient(){});
                            }
                        });
                }
            }).start();
    }
    public static void create(final Activity act, final WebView webView, final String modelp, final Bitmap sk) {
        initWebView(webView);
        webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return false;
                }
                @Override
                public void onPageFinished(WebView view, String url) {
                    String model="";
                    //LOG.print("mod",modelp);
                    if (modelp.equals("def")) {
                        model = AssetsUtil.getFromAssets(act, Basepath + "geo/g.json");
                    } else if (modelp.equals("defx")) {
                        model = AssetsUtil.getFromAssets(act, Basepath + "geo/gx.json");
                    } else {
                        try {
                            model = new 文件(modelp).获取内容();
                        } catch (IOException e) {}
                    }
                    //LOG.print("mod",model);
                    Bitmap bg=AssetsUtil.getImageFromAssetsFile(act, Basepath + "texture/grass.png");

                    LoadRes(webView, model, bg, sk);
                }

            });
        // 格式规定为:file:////android_asset/文件名.html
        webView.loadUrl("file:android_asset/scene/index.html");
        //LOG.print("mod","加载完毕");
        //webView.setWebViewClient(new WebChromeClient(){});
    }
}
