package com.play.box.core.flt;

public class Position {
    public Integer[] pos = new Integer[3];
    public String position;
    public String tag;

    public Position(float var1, float var2, float var3) {
        this.tag = "";
        this.pos[0] = new Integer(Math.round(var1));
        this.pos[1] = new Integer(Math.round(var2));
        this.pos[2] = new Integer(Math.round(var3));
        this.position = this.pos[0] + " " + this.pos[1] + " " + this.pos[2];
    }

    public Position(int var1, int var2, int var3) {
        this.tag = "";
        this.pos[0] = new Integer(var1);
        this.pos[1] = new Integer(var2);
        this.pos[2] = new Integer(var3);
        this.position = var1 + " " + var2 + " " + var3;
    }

    public Position(String var1, float var2, float var3, float var4) {
        this.tag = var1;
        this.pos[0] = new Integer(Math.round(var2));
        this.pos[1] = new Integer(Math.round(var3));
        this.pos[2] = new Integer(Math.round(var4));
        this.position = this.pos[0] + " " + this.pos[1] + " " + this.pos[2];
    }

    public Position(String var1, String var2) {
        this.tag = var1;
        this.position = var2;
        int var4 = 0;
        String[] var5 = var2.split(" ");

        for (int var3 = 0; var3 < var5.length; ++var3) {
            var2 = var5[var3];
            this.pos[var4] =Integer.parseInt(var2);
            ++var4;
        }

    }
}
