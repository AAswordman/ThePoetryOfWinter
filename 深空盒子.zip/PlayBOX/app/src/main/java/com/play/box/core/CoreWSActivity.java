package com.play.box.core;

import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import bms.helper.app.CrashHandler;
import com.play.box.MainActivity;
import com.play.box.R;
import android.content.Intent;
import android.os.Build;
import com.play.box.core.flt.FloatingService;

public class CoreWSActivity extends AppCompatActivity {
    CrashHandler crashHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
        setContentView(R.layout.act_watching_res_list);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "当前无权限，请授权", Toast.LENGTH_SHORT);
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 0);
            } else {
                InitFloat();
            }
        } else {
            InitFloat();
        }



        finish();



	}

    private void InitFloat() {
        Intent in=new Intent(this, FloatingService.class);
        startService(in);
        FloatingService.intent = in;

        try {
            Intent settintIntent = getPackageManager().
                getLaunchIntentForPackage("com.mojang.minecraftpe");
            startActivity(settintIntent);
        } catch (Exception e) {
            Toast.makeText(getApplication(), "没有检测到安装游戏，请手动打开", Toast.LENGTH_SHORT).show();
        }
    }
}
