
export default interface ExLoreManager {
	getLore(): string[];
	setLore(lore: string[]):void;
}