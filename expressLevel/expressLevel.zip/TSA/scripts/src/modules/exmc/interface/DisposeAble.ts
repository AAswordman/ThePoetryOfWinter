export default interface DisposeAble {
    dispose(): void;
}