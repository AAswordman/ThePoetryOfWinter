export default class ExEntityComponentId {
    public static readonly health = "minecraft:health";
    public static readonly inventory = "minecraft:inventory";
}