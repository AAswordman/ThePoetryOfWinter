import { world } from '@minecraft/server';
