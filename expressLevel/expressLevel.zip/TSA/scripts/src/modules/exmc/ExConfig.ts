export default class ExConfig {
    gameVersion = "1.9.20";
    addonVersion = "1.6.42x";
    debug = false;
    watchDog = false;
}